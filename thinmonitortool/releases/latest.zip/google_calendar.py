#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Google Calendar API連携モジュール
"""

import os
import ssl
import pickle
from datetime import datetime, timedelta, timezone
from pathlib import Path

# SSL証明書問題の対策（Windows環境）
import certifi
os.environ['SSL_CERT_FILE'] = certifi.where()
os.environ['REQUESTS_CA_BUNDLE'] = certifi.where()

# SSL検証を無効化（開発環境用）
ssl._create_default_https_context = ssl._create_unverified_context

import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

import requests
from requests.adapters import HTTPAdapter

# SSL検証をスキップするアダプター
class SSLAdapter(HTTPAdapter):
    def init_poolmanager(self, *args, **kwargs):
        kwargs['ssl_context'] = ssl._create_unverified_context()
        return super().init_poolmanager(*args, **kwargs)

# requestsのデフォルトセッションにパッチ
old_request = requests.Session.request
def patched_request(self, *args, **kwargs):
    kwargs['verify'] = False
    return old_request(self, *args, **kwargs)
requests.Session.request = patched_request

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow, Flow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

# Google Calendar APIのスコープ（読み取り専用）
SCOPES = ['https://www.googleapis.com/auth/calendar.readonly']

# 認証情報ファイルのパス
CREDENTIALS_FILE = 'credentials.json'
TOKEN_FILE = 'token.pickle'

class GoogleCalendarService:
    """Google Calendar APIサービスクラス"""

    def __init__(self):
        self._service = None
        self._credentials = None

    def needs_authentication(self):
        """認証が必要かどうかを確認"""
        if not os.path.exists(TOKEN_FILE):
            return True

        try:
            with open(TOKEN_FILE, 'rb') as token:
                creds = pickle.load(token)
            if creds and creds.valid:
                return False
            if creds and creds.expired and creds.refresh_token:
                # リフレッシュ可能
                return False
        except Exception:
            pass

        return True

    def clear_credentials(self):
        """保存された認証情報をクリア（再認証用）"""
        if os.path.exists(TOKEN_FILE):
            os.remove(TOKEN_FILE)
            print(f"Google Calendar: {TOKEN_FILE} を削除しました")

        self._credentials = None
        self._service = None

    def authenticate(self):
        """OAuth2認証を実行"""
        creds = None

        # 保存済みトークンがあれば読み込み
        if os.path.exists(TOKEN_FILE):
            with open(TOKEN_FILE, 'rb') as token:
                creds = pickle.load(token)

        # 有効な認証情報がない場合
        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                # トークンをリフレッシュ
                creds.refresh(Request())
            else:
                # 新規認証
                if not os.path.exists(CREDENTIALS_FILE):
                    raise FileNotFoundError(
                        f"認証情報ファイル '{CREDENTIALS_FILE}' が見つかりません。\n"
                        "Google Cloud Consoleから OAuth 2.0 クライアントIDを作成し、\n"
                        "credentials.json としてダウンロードしてください。"
                    )
                flow = InstalledAppFlow.from_client_secrets_file(
                    CREDENTIALS_FILE, SCOPES
                )
                creds = flow.run_local_server(port=0)

            # トークンを保存
            with open(TOKEN_FILE, 'wb') as token:
                pickle.dump(creds, token)

        self._credentials = creds
        self._service = build('calendar', 'v3', credentials=creds)
        return True

    def get_today_events(self, max_results=10):
        """今日の予定を取得"""
        return self.get_events(days=1, max_results=max_results)

    def get_calendars(self):
        """アクセス可能なカレンダー一覧を取得"""
        if not self._service:
            return []

        try:
            calendar_list = self._service.calendarList().list().execute()
            calendars = calendar_list.get('items', [])
            print(f"利用可能なカレンダー: {len(calendars)}件")
            for cal in calendars:
                print(f"  - {cal.get('summary')} (ID: {cal.get('id')[:30]}...)")
            return calendars
        except HttpError as error:
            print(f'Calendar list error: {error}')
            return []

    def get_events(self, days=2, max_results=500):
        """指定日数分の予定を全カレンダーから取得"""
        if not self._service:
            raise RuntimeError("認証されていません。authenticate()を先に呼び出してください。")

        try:
            # 今日の開始から指定日数分の終了まで
            now = datetime.now()
            start_of_day = datetime(now.year, now.month, now.day, 0, 0, 0)
            # days=2なら今日と明日（今日 + 1日後の23:59:59まで）
            end_of_period = start_of_day + timedelta(days=days) - timedelta(seconds=1)

            time_min = start_of_day.isoformat() + '+09:00'
            time_max = end_of_period.isoformat() + '+09:00'

            print(f"Google Calendar: {time_min} から {time_max} までの予定を取得")

            # 全カレンダーを取得
            calendars = self.get_calendars()
            all_events = []

            for calendar in calendars:
                cal_id = calendar.get('id')
                cal_name = calendar.get('summary', cal_id[:20])
                cal_color = calendar.get('backgroundColor', '#4285f4')

                try:
                    # ページネーションで全件取得
                    page_token = None
                    cal_events = []
                    page_count = 0
                    while True:
                        events_result = self._service.events().list(
                            calendarId=cal_id,
                            timeMin=time_min,
                            timeMax=time_max,
                            maxResults=250,
                            singleEvents=True,
                            orderBy='startTime',
                            pageToken=page_token
                        ).execute()

                        items = events_result.get('items', [])
                        cal_events.extend(items)
                        page_count += 1

                        page_token = events_result.get('nextPageToken')
                        if not page_token or page_count >= 10:  # 最大10ページ
                            break

                    print(f"  {cal_name}: {len(cal_events)}件 ({page_count}ページ)")
                    # カレンダーの色をデフォルトとして設定
                    for event in cal_events:
                        if 'colorId' not in event:
                            event['_calendar_color'] = cal_color
                    all_events.extend(cal_events)
                except HttpError as e:
                    print(f"カレンダー {cal_id} の取得エラー: {e}")
                    continue

            # 開始時刻でソート
            all_events.sort(key=lambda x: x['start'].get('dateTime', x['start'].get('date', '')))

            return self._format_events(all_events, include_date=True)

        except HttpError as error:
            print(f'Google Calendar API error: {error}')
            return []

    def _format_events(self, events, include_date=False):
        """イベントをアプリ用フォーマットに変換"""
        formatted = []
        now = datetime.now()
        today = now.date()
        tomorrow = today + timedelta(days=1)

        # Googleカレンダーの色IDとカラーコードのマッピング
        color_map = {
            '1': '#7986cb',   # ラベンダー
            '2': '#33b679',   # セージ
            '3': '#8e24aa',   # グレープ
            '4': '#e67c73',   # フラミンゴ
            '5': '#f6bf26',   # バナナ
            '6': '#f4511e',   # タンジェリン
            '7': '#039be5',   # ピーコック
            '8': '#616161',   # グラファイト
            '9': '#3f51b5',   # ブルーベリー
            '10': '#0b8043',  # バジル
            '11': '#d50000',  # トマト
        }

        for event in events:
            start = event['start'].get('dateTime', event['start'].get('date'))
            end = event['end'].get('dateTime', event['end'].get('date'))

            # 時刻を整形
            if 'T' in start:
                # 時刻指定あり
                start_dt = datetime.fromisoformat(start.replace('Z', '+00:00'))
                end_dt = datetime.fromisoformat(end.replace('Z', '+00:00'))

                # JSTに変換
                jst = timezone(timedelta(hours=9))
                start_jst = start_dt.astimezone(jst)
                end_jst = end_dt.astimezone(jst)

                # 過去の予定（終了時刻が現在より前）はスキップ
                # タイムゾーン対応のため、naive datetimeに変換して比較
                end_naive = end_jst.replace(tzinfo=None)
                if end_naive < now:
                    continue

                time_str = f"{start_jst.strftime('%H:%M')} - {end_jst.strftime('%H:%M')}"
                event_date = start_jst.date()
            else:
                # 終日イベント
                # Google Calendarの終日イベントは end が「翌日」を指す
                # 例: 12/22の終日イベント → start='2024-12-22', end='2024-12-23'
                event_date = datetime.strptime(start, '%Y-%m-%d').date()
                end_date = datetime.strptime(end, '%Y-%m-%d').date()

                # 終了日が今日以前なら過去のイベント（スキップ）
                if end_date <= today:
                    continue
                time_str = "終日"

            # 日付ラベルを追加（今日は表示しない、明日以降のみ）
            if include_date:
                if event_date == today:
                    date_label = ""  # 今日は表示しない
                elif event_date == tomorrow:
                    date_label = "明日"
                else:
                    date_label = event_date.strftime('%m/%d')
            else:
                date_label = ""

            # 色を取得（イベント色 > カレンダー色 > デフォルト）
            color_id = event.get('colorId')
            if color_id:
                color = color_map.get(color_id, '#4285f4')
            else:
                color = event.get('_calendar_color', '#4285f4')

            formatted.append({
                'title': event.get('summary', '(タイトルなし)'),
                'time': time_str,
                'date': event_date,
                'date_label': date_label,
                'color': color,
                'location': event.get('location', ''),
                'description': event.get('description', '')
            })

        return formatted

    def is_authenticated(self):
        """認証済みかどうかを確認"""
        return self._service is not None


# グローバルインスタンス
_calendar_service = None


def get_calendar_service():
    """Google Calendarサービスのシングルトンインスタンスを取得"""
    global _calendar_service
    if _calendar_service is None:
        _calendar_service = GoogleCalendarService()
    return _calendar_service
