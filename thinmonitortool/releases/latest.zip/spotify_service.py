#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Spotify API連携モジュール
"""

import os
import json
from pathlib import Path

import spotipy
from spotipy.oauth2 import SpotifyOAuth

# 認証情報ファイルのパス
CREDENTIALS_FILE = 'spotify_credentials.json'
TOKEN_CACHE = '.spotify_token_cache'

# Spotify APIのスコープ
SCOPES = [
    'user-read-playback-state',
    'user-modify-playback-state',
    'user-read-currently-playing',
    'playlist-read-private',
    'playlist-read-collaborative',
    'user-library-read',
    'user-library-modify',
]


class SpotifyService:
    """Spotify APIサービスクラス"""

    def __init__(self):
        self._spotify = None
        self._is_authenticated = False

    def needs_authentication(self):
        """認証が必要かどうかを確認"""
        if not os.path.exists(CREDENTIALS_FILE):
            return True

        if not os.path.exists(TOKEN_CACHE):
            return True

        # キャッシュファイルが存在する場合、有効性をチェック
        try:
            with open(CREDENTIALS_FILE, 'r') as f:
                creds = json.load(f)

            client_id = creds.get('client_id')
            client_secret = creds.get('client_secret')
            redirect_uri = creds.get('redirect_uri', 'http://localhost:8888/callback')

            if not client_id or not client_secret:
                return True

            auth_manager = SpotifyOAuth(
                client_id=client_id,
                client_secret=client_secret,
                redirect_uri=redirect_uri,
                scope=' '.join(SCOPES),
                cache_path=TOKEN_CACHE,
                open_browser=False
            )

            token_info = auth_manager.get_cached_token()
            if token_info:
                return False  # 有効なトークンがある

        except Exception:
            pass

        return True

    def clear_credentials(self):
        """保存された認証情報をクリア（再認証用）"""
        if os.path.exists(TOKEN_CACHE):
            os.remove(TOKEN_CACHE)
            print(f"Spotify: {TOKEN_CACHE} を削除しました")

        self._spotify = None
        self._is_authenticated = False

    def authenticate(self):
        """OAuth2認証を実行"""
        if not os.path.exists(CREDENTIALS_FILE):
            raise FileNotFoundError(
                f"認証情報ファイル '{CREDENTIALS_FILE}' が見つかりません。\n"
                "Spotify Developer Dashboardからアプリを作成し、\n"
                "spotify_credentials.json として保存してください。\n"
                "形式: {\"client_id\": \"...\", \"client_secret\": \"...\", \"redirect_uri\": \"http://localhost:8888/callback\"}"
            )

        with open(CREDENTIALS_FILE, 'r') as f:
            creds = json.load(f)

        client_id = creds.get('client_id')
        client_secret = creds.get('client_secret')
        redirect_uri = creds.get('redirect_uri', 'http://localhost:8888/callback')

        if not client_id or not client_secret:
            raise ValueError("client_id と client_secret が必要です")

        auth_manager = SpotifyOAuth(
            client_id=client_id,
            client_secret=client_secret,
            redirect_uri=redirect_uri,
            scope=' '.join(SCOPES),
            cache_path=TOKEN_CACHE,
            open_browser=True
        )

        self._spotify = spotipy.Spotify(auth_manager=auth_manager)
        self._is_authenticated = True
        print("Spotify: 認証成功")
        return True

    def is_authenticated(self):
        """認証済みかどうかを確認"""
        return self._is_authenticated and self._spotify is not None

    def get_current_playback(self):
        """現在の再生状態を取得"""
        if not self._spotify:
            return None

        try:
            playback = self._spotify.current_playback()
            if not playback:
                return None

            track = playback.get('item')
            if not track:
                return None

            # アルバムアート取得（最大サイズ）
            album_images = track.get('album', {}).get('images', [])
            album_art_url = album_images[0]['url'] if album_images else None

            return {
                'is_playing': playback.get('is_playing', False),
                'track_id': track.get('id', ''),
                'track_name': track.get('name', ''),
                'artist_name': ', '.join(a['name'] for a in track.get('artists', [])),
                'album_name': track.get('album', {}).get('name', ''),
                'album_art_url': album_art_url,
                'duration_ms': track.get('duration_ms', 0),
                'progress_ms': playback.get('progress_ms', 0),
                'volume_percent': playback.get('device', {}).get('volume_percent', 50),
                'shuffle_state': playback.get('shuffle_state', False),
                'repeat_state': playback.get('repeat_state', 'off'),  # off, track, context
                'device_name': playback.get('device', {}).get('name', ''),
            }
        except Exception as e:
            print(f"Spotify playback error: {e}")
            return None

    def play(self):
        """再生開始"""
        if not self._spotify:
            return False
        try:
            self._spotify.start_playback()
            return True
        except Exception as e:
            # アクティブデバイスがない場合、raspotifyデバイスを指定して再生
            if "No active device" in str(e) or "404" in str(e):
                device_id = self._get_raspotify_device_id()
                if device_id:
                    try:
                        self._spotify.start_playback(device_id=device_id)
                        return True
                    except Exception as e2:
                        print(f"Spotify play error (with device): {e2}")
            print(f"Spotify play error: {e}")
            return False

    def pause(self):
        """一時停止"""
        if not self._spotify:
            return False
        try:
            self._spotify.pause_playback()
            return True
        except Exception as e:
            print(f"Spotify pause error: {e}")
            return False

    def toggle_playback(self):
        """再生/一時停止を切り替え"""
        playback = self.get_current_playback()
        if playback and playback['is_playing']:
            return self.pause()
        else:
            return self.play()

    def next_track(self):
        """次の曲へ"""
        if not self._spotify:
            return False
        try:
            self._spotify.next_track()
            return True
        except Exception as e:
            print(f"Spotify next error: {e}")
            return False

    def previous_track(self):
        """前の曲へ"""
        if not self._spotify:
            return False
        try:
            self._spotify.previous_track()
            return True
        except Exception as e:
            print(f"Spotify previous error: {e}")
            return False

    def seek(self, position_ms):
        """指定位置にシーク"""
        if not self._spotify:
            return False
        try:
            self._spotify.seek_track(position_ms)
            return True
        except Exception as e:
            print(f"Spotify seek error: {e}")
            return False

    def set_volume(self, volume_percent):
        """音量設定 (0-100)"""
        if not self._spotify:
            return False
        try:
            volume_percent = max(0, min(100, int(volume_percent)))
            self._spotify.volume(volume_percent)
            return True
        except Exception as e:
            print(f"Spotify volume error: {e}")
            return False

    def set_shuffle(self, state):
        """シャッフル設定"""
        if not self._spotify:
            return False
        try:
            self._spotify.shuffle(state)
            return True
        except Exception as e:
            print(f"Spotify shuffle error: {e}")
            return False

    def toggle_shuffle(self):
        """シャッフル切り替え"""
        playback = self.get_current_playback()
        if playback:
            return self.set_shuffle(not playback['shuffle_state'])
        return False

    def set_repeat(self, state):
        """リピート設定 (off, track, context)"""
        if not self._spotify:
            return False
        try:
            self._spotify.repeat(state)
            return True
        except Exception as e:
            print(f"Spotify repeat error: {e}")
            return False

    def cycle_repeat(self):
        """リピートモードを循環 (off -> context -> track -> off)"""
        playback = self.get_current_playback()
        if not playback:
            return False

        current = playback['repeat_state']
        next_state = {
            'off': 'context',
            'context': 'track',
            'track': 'off'
        }.get(current, 'off')

        return self.set_repeat(next_state)

    def get_devices(self):
        """利用可能なデバイス一覧を取得"""
        if not self._spotify:
            return []
        try:
            result = self._spotify.devices()
            return result.get('devices', [])
        except Exception as e:
            print(f"Spotify devices error: {e}")
            return []

    def transfer_playback(self, device_id, force_play=False):
        """再生を指定デバイスに転送"""
        if not self._spotify:
            return False
        try:
            self._spotify.transfer_playback(device_id, force_play=force_play)
            return True
        except Exception as e:
            print(f"Spotify transfer error: {e}")
            return False

    def transfer_to_raspotify(self, force_play=False):
        """再生をraspotifyデバイスに転送"""
        devices = self.get_devices()
        for device in devices:
            if 'raspotify' in device.get('name', '').lower():
                return self.transfer_playback(device['id'], force_play)
        print("Spotify: raspotifyデバイスが見つかりません")
        return False

    def _get_raspotify_device_id(self):
        """raspotifyデバイスのIDを取得"""
        devices = self.get_devices()
        for device in devices:
            if 'raspotify' in device.get('name', '').lower():
                return device['id']
        return None

    def _ensure_active_device(self):
        """アクティブなデバイスを確保（なければraspotifyをアクティブ化）"""
        try:
            playback = self._spotify.current_playback()
            if playback and playback.get('device'):
                return playback['device']['id']
        except:
            pass

        # アクティブデバイスがない場合、raspotifyをアクティブ化
        device_id = self._get_raspotify_device_id()
        if device_id:
            try:
                self._spotify.transfer_playback(device_id, force_play=False)
                import time
                time.sleep(0.5)
                return device_id
            except Exception as e:
                print(f"Spotify: デバイスアクティブ化失敗: {e}", flush=True)
        return None

    def get_recently_played(self, limit=5):
        """最近再生したトラックを取得"""
        if not self._spotify:
            return []
        try:
            result = self._spotify.current_user_recently_played(limit=limit)
            tracks = []
            for item in result.get('items', []):
                track = item.get('track', {})
                if track.get('id'):
                    tracks.append({
                        'id': track['id'],
                        'name': track.get('name', ''),
                        'artist': track.get('artists', [{}])[0].get('name', '')
                    })
            return tracks
        except Exception as e:
            print(f"Spotify recently played error: {e}")
            return []

    def get_recommendations(self, seed_tracks=None, seed_artists=None, limit=30):
        """レコメンドトラックを取得"""
        if not self._spotify:
            return []
        try:
            # シードトラックまたはアーティストが必要
            kwargs = {'limit': limit}
            if seed_tracks:
                kwargs['seed_tracks'] = seed_tracks[:5]  # 最大5つ
            if seed_artists:
                kwargs['seed_artists'] = seed_artists[:5]

            if not seed_tracks and not seed_artists:
                return []

            result = self._spotify.recommendations(**kwargs)
            tracks = []
            for track in result.get('tracks', []):
                tracks.append({
                    'id': track['id'],
                    'uri': track['uri'],
                    'name': track.get('name', ''),
                    'artist': track.get('artists', [{}])[0].get('name', '')
                })
            return tracks
        except Exception as e:
            print(f"Spotify recommendations error: {e}")
            return []

    # Daily Mix プレイリストID（ユーザー固有）
    DAILY_MIX_IDS = [
        '37i9dQZF1E38OdWt3ej4JT',  # Daily Mix 1
        '37i9dQZF1E35MyPCiGEsfD',  # Daily Mix 2
        '37i9dQZF1E36Is0AOM2AFP',  # Daily Mix 3
        '37i9dQZF1E35JXOzGbLfZp',  # Daily Mix 4
        '37i9dQZF1E37QQ3I7JCXsh',  # Daily Mix 5
        '37i9dQZF1E39Ko4nHcdGFH',  # Daily Mix 6
    ]
    CHILL_MIX_ID = '37i9dQZF1EVHGWrwldPRtj'
    UPBEAT_MIX_ID = '37i9dQZF1EVJHK7Q1TBABQ'

    def play_random_playlist(self):
        """Daily Mixからランダムにシャッフル再生（最初の曲もランダム）"""
        if not self._spotify:
            return False
        try:
            import random
            import time

            # Daily MixのIDからランダムに選択
            playlist_id = random.choice(self.DAILY_MIX_IDS)
            mix_num = self.DAILY_MIX_IDS.index(playlist_id) + 1
            uri = f'spotify:playlist:{playlist_id}'
            print(f"Spotify: Daily Mix {mix_num} を再生", flush=True)

            # プレイリストの曲数を取得してランダムオフセット
            try:
                playlist = self._spotify.playlist(playlist_id, fields='tracks.total')
                total = playlist.get('tracks', {}).get('total', 50)
                offset = random.randint(0, max(0, total - 1))
            except:
                offset = random.randint(0, 49)

            # raspotifyデバイスIDを取得
            device_id = self._get_raspotify_device_id()
            if not device_id:
                print("Spotify: raspotifyデバイスが見つかりません", flush=True)
                return False

            # 再生開始（device_idを明示的に指定）
            self._spotify.start_playback(device_id=device_id, context_uri=uri, offset={'position': offset})
            time.sleep(0.3)
            # シャッフルON
            try:
                self._spotify.shuffle(True, device_id=device_id)
            except:
                pass
            print(f"Spotify: Daily Mix {mix_num} 再生開始 (offset={offset})", flush=True)
            return True
        except Exception as e:
            print(f"Spotify Daily Mix error: {e}", flush=True)
            return False

    def play_chill_mix(self):
        """Chill Mixをシャッフル再生（最初の曲もランダム）"""
        if not self._spotify:
            return False
        try:
            import random
            import time
            uri = f'spotify:playlist:{self.CHILL_MIX_ID}'
            print("Spotify: Chill Mix を再生", flush=True)

            # プレイリストの曲数を取得してランダムオフセット
            try:
                playlist = self._spotify.playlist(self.CHILL_MIX_ID, fields='tracks.total')
                total = playlist.get('tracks', {}).get('total', 50)
                offset = random.randint(0, max(0, total - 1))
            except:
                offset = random.randint(0, 49)

            device_id = self._get_raspotify_device_id()
            if not device_id:
                print("Spotify: raspotifyデバイスが見つかりません", flush=True)
                return False

            self._spotify.start_playback(device_id=device_id, context_uri=uri, offset={'position': offset})
            time.sleep(0.3)
            try:
                self._spotify.shuffle(True, device_id=device_id)
            except:
                pass
            print(f"Spotify: Chill Mix 再生開始 (offset={offset})", flush=True)
            return True
        except Exception as e:
            print(f"Spotify Chill Mix error: {e}", flush=True)
            return False

    def play_upbeat_mix(self):
        """Upbeat Mixをシャッフル再生（最初の曲もランダム）"""
        if not self._spotify:
            return False
        try:
            import random
            import time
            uri = f'spotify:playlist:{self.UPBEAT_MIX_ID}'
            print("Spotify: Upbeat Mix を再生", flush=True)

            # プレイリストの曲数を取得してランダムオフセット
            try:
                playlist = self._spotify.playlist(self.UPBEAT_MIX_ID, fields='tracks.total')
                total = playlist.get('tracks', {}).get('total', 50)
                offset = random.randint(0, max(0, total - 1))
            except:
                offset = random.randint(0, 49)

            device_id = self._get_raspotify_device_id()
            if not device_id:
                print("Spotify: raspotifyデバイスが見つかりません", flush=True)
                return False

            self._spotify.start_playback(device_id=device_id, context_uri=uri, offset={'position': offset})
            time.sleep(0.3)
            try:
                self._spotify.shuffle(True, device_id=device_id)
            except:
                pass
            print(f"Spotify: Upbeat Mix 再生開始 (offset={offset})", flush=True)
            return True
        except Exception as e:
            print(f"Spotify Upbeat Mix error: {e}", flush=True)
            return False

    def is_current_track_saved(self, track_id=None):
        """現在の曲がお気に入りに登録されているか確認"""
        if not self._spotify:
            return False
        try:
            if not track_id:
                current = self._spotify.current_playback()
                if not current or not current.get('item'):
                    return False
                track_id = current['item']['id']
            result = self._spotify.current_user_saved_tracks_contains([track_id])
            return result[0] if result else False
        except Exception as e:
            return False

    def add_current_to_favorites(self):
        """現在再生中の曲をお気に入りに追加"""
        if not self._spotify:
            return False
        try:
            current = self._spotify.current_playback()
            if not current or not current.get('item'):
                print("Spotify: 再生中の曲がありません", flush=True)
                return False

            track_id = current['item']['id']
            track_name = current['item'].get('name', '')
            self._spotify.current_user_saved_tracks_add([track_id])
            print(f"Spotify: ♥ {track_name} をお気に入りに追加", flush=True)
            return True
        except Exception as e:
            print(f"Spotify add favorite error: {e}", flush=True)
            return False

    def remove_current_from_favorites(self):
        """現在再生中の曲をお気に入りから削除"""
        if not self._spotify:
            return False
        try:
            current = self._spotify.current_playback()
            if not current or not current.get('item'):
                print("Spotify: 再生中の曲がありません", flush=True)
                return False

            track_id = current['item']['id']
            track_name = current['item'].get('name', '')
            self._spotify.current_user_saved_tracks_delete([track_id])
            print(f"Spotify: {track_name} をお気に入りから削除", flush=True)
            return True
        except Exception as e:
            print(f"Spotify remove favorite error: {e}", flush=True)
            return False

    def play_favorites(self):
        """お気に入り曲をシャッフル再生"""
        if not self._spotify:
            return False
        try:
            import random
            import time

            # お気に入り曲を取得
            saved = self._spotify.current_user_saved_tracks(limit=50)
            tracks = saved.get('items', [])

            if not tracks:
                print("Spotify: お気に入り曲がありません", flush=True)
                return False

            random.shuffle(tracks)
            uris = [t['track']['uri'] for t in tracks]
            print(f"Spotify: お気に入り {len(uris)}曲 を再生", flush=True)

            device_id = self._get_raspotify_device_id()
            if not device_id:
                print("Spotify: raspotifyデバイスが見つかりません", flush=True)
                return False

            self._spotify.start_playback(device_id=device_id, uris=uris)
            time.sleep(0.3)
            try:
                self._spotify.shuffle(True, device_id=device_id)
            except:
                pass
            print("Spotify: お気に入り再生開始", flush=True)
            return True
        except Exception as e:
            print(f"Spotify favorites error: {e}", flush=True)
            return False


# グローバルインスタンス
_spotify_service = None


def get_spotify_service():
    """Spotifyサービスのシングルトンインスタンスを取得"""
    global _spotify_service
    if _spotify_service is None:
        _spotify_service = SpotifyService()
    return _spotify_service
