#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
別端末での認証セットアップスクリプト

このスクリプトをPC等で実行し、生成されたトークンファイルを
Raspberry Piにコピーして使用します。

使用方法:
    python auth_setup.py [google|spotify|all]
"""

import os
import sys
import json
import pickle

def setup_google_auth():
    """Google Calendar認証のセットアップ"""
    print("\n=== Google Calendar 認証セットアップ ===\n")

    CREDENTIALS_FILE = 'credentials.json'
    TOKEN_FILE = 'token.pickle'
    SCOPES = ['https://www.googleapis.com/auth/calendar.readonly']

    if not os.path.exists(CREDENTIALS_FILE):
        print(f"エラー: {CREDENTIALS_FILE} が見つかりません。")
        print("Google Cloud ConsoleからOAuth 2.0クライアントIDをダウンロードしてください。")
        print("https://console.cloud.google.com/apis/credentials")
        return False

    try:
        from google_auth_oauthlib.flow import InstalledAppFlow

        flow = InstalledAppFlow.from_client_secrets_file(CREDENTIALS_FILE, SCOPES)
        creds = flow.run_local_server(port=0)

        with open(TOKEN_FILE, 'wb') as token:
            pickle.dump(creds, token)

        print(f"\n認証成功! {TOKEN_FILE} が生成されました。")
        print(f"このファイルをRaspberry Piにコピーしてください。")
        return True

    except ImportError:
        print("エラー: 必要なライブラリがインストールされていません。")
        print("pip install google-auth-oauthlib google-api-python-client")
        return False
    except Exception as e:
        print(f"エラー: {e}")
        return False


def setup_spotify_auth():
    """Spotify認証のセットアップ"""
    print("\n=== Spotify 認証セットアップ ===\n")

    CREDENTIALS_FILE = 'spotify_credentials.json'
    TOKEN_CACHE = '.spotify_token_cache'
    SCOPES = [
        'user-read-playback-state',
        'user-modify-playback-state',
        'user-read-currently-playing',
        'playlist-read-private',
        'playlist-read-collaborative',
        'user-library-read',
        'user-library-modify',
    ]

    if not os.path.exists(CREDENTIALS_FILE):
        print(f"エラー: {CREDENTIALS_FILE} が見つかりません。")
        print("Spotify Developer Dashboardでアプリを作成し、以下の形式で保存してください:")
        print('{"client_id": "...", "client_secret": "...", "redirect_uri": "http://127.0.0.1:8888/callback"}')
        print("https://developer.spotify.com/dashboard")
        return False

    try:
        import spotipy
        from spotipy.oauth2 import SpotifyOAuth

        with open(CREDENTIALS_FILE, 'r') as f:
            creds = json.load(f)

        client_id = creds.get('client_id')
        client_secret = creds.get('client_secret')
        redirect_uri = creds.get('redirect_uri', 'http://127.0.0.1:8888/callback')

        if not client_id or not client_secret:
            print("エラー: client_id と client_secret が必要です。")
            return False

        auth_manager = SpotifyOAuth(
            client_id=client_id,
            client_secret=client_secret,
            redirect_uri=redirect_uri,
            scope=' '.join(SCOPES),
            cache_path=TOKEN_CACHE,
            open_browser=True
        )

        # トークン取得（ブラウザが開く）
        sp = spotipy.Spotify(auth_manager=auth_manager)
        user = sp.current_user()

        print(f"\n認証成功! ユーザー: {user.get('display_name', user.get('id'))}")
        print(f"{TOKEN_CACHE} が生成されました。")
        print(f"このファイルをRaspberry Piにコピーしてください。")
        return True

    except ImportError:
        print("エラー: 必要なライブラリがインストールされていません。")
        print("pip install spotipy")
        return False
    except Exception as e:
        print(f"エラー: {e}")
        return False


def main():
    print("=" * 50)
    print("ThinMonitorTool 認証セットアップ")
    print("=" * 50)

    if len(sys.argv) > 1:
        target = sys.argv[1].lower()
    else:
        print("\n使用方法: python auth_setup.py [google|spotify|all]")
        print("\n対象を選択してください:")
        print("  1. Google Calendar のみ")
        print("  2. Spotify のみ")
        print("  3. 両方")

        choice = input("\n選択 (1/2/3): ").strip()
        target = {'1': 'google', '2': 'spotify', '3': 'all'}.get(choice, 'all')

    results = []

    if target in ['google', 'all']:
        results.append(('Google Calendar', setup_google_auth()))

    if target in ['spotify', 'all']:
        results.append(('Spotify', setup_spotify_auth()))

    print("\n" + "=" * 50)
    print("セットアップ結果")
    print("=" * 50)

    for name, success in results:
        status = "成功" if success else "失敗"
        print(f"  {name}: {status}")

    print("\n--- Raspberry Piへコピーするファイル ---")
    print("  credentials.json        (Google API設定)")
    print("  token.pickle            (Google認証トークン)")
    print("  spotify_credentials.json (Spotify API設定)")
    print("  .spotify_token_cache    (Spotify認証トークン)")
    print()


if __name__ == '__main__':
    main()
