# ThinMonitorTool

Raspberry Pi用のモニターツール。Googleカレンダーとspotify連携機能付き。

## 起動方法

```bash
./start.sh
```

## 必要な設定ファイル

- `credentials.json` - Google Calendar API認証情報
- `spotify_credentials.json` - Spotify API認証情報

## 認証セットアップ

Raspberry Piはブラウザ認証が難しいため、**別端末（PC等）で認証を行い、トークンファイルをコピー**する方法を推奨します。

### 手順

#### 1. API認証情報の準備

**Google Calendar:**
1. [Google Cloud Console](https://console.cloud.google.com/apis/credentials) にアクセス
2. OAuth 2.0 クライアントIDを作成（デスクトップアプリ）
3. JSONをダウンロードし `credentials.json` として保存

**Spotify:**
1. [Spotify Developer Dashboard](https://developer.spotify.com/dashboard) にアクセス
2. アプリを作成
3. 以下の形式で `spotify_credentials.json` を作成:
```json
{
  "client_id": "あなたのClient ID",
  "client_secret": "あなたのClient Secret",
  "redirect_uri": "http://localhost:8888/callback"
}
```

#### 2. Windows PCで認証を実行

1. [auth_setup.exe をダウンロード](https://raw.githubusercontent.com/tafuji-jn/release/main/thinmonitortool/auth_setup.exe)
2. `credentials.json` と `spotify_credentials.json` を同じフォルダに配置
3. `auth_setup.exe` を実行（ブラウザが開いて認証）

#### 3. Raspberry Piにファイルをコピー

認証完了後、以下のファイルをRaspberry Piにコピー：

| ファイル | 内容 |
|----------|------|
| `credentials.json` | Google API設定 |
| `token.pickle` | Google認証トークン |
| `spotify_credentials.json` | Spotify API設定 |
| `.spotify_token_cache` | Spotify認証トークン |

```bash
# 例: scpでコピー
scp credentials.json token.pickle spotify_credentials.json .spotify_token_cache pi@raspberrypi:~/thinmonitortool/
```
