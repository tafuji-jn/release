# -*- coding: utf-8 -*-
"""Spotifyプレイヤーウィジェット"""

import threading
from pathlib import Path

from PyQt5.QtWidgets import (
    QFrame, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QSlider, QGraphicsOpacityEffect
)
from PyQt5.QtCore import Qt, QTimer, QSize, QPropertyAnimation, QEasingCurve
from PyQt5.QtGui import QPainter, QColor, QPixmap, QFont, QIcon

from .common import load_transparent_icon

class TouchFriendlySlider(QSlider):
    """タッチ操作しやすいスライダー（見た目は小さいまま、タッチ領域は広い）"""

    def __init__(self, orientation=Qt.Horizontal, parent=None):
        super().__init__(orientation, parent)
        # 高さを広げてタッチ領域を確保（見た目はスタイルシートで制御）
        self.setFixedHeight(30)

    def mousePressEvent(self, event):
        """クリック位置に直接ジャンプ"""
        if event.button() == Qt.LeftButton:
            self._set_value_from_pos(event.pos())
            self.sliderPressed.emit()
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        """ドラッグ中も値を更新"""
        if event.buttons() & Qt.LeftButton:
            self._set_value_from_pos(event.pos())
        super().mouseMoveEvent(event)

    def _set_value_from_pos(self, pos):
        """位置から値を計算してセット"""
        if self.orientation() == Qt.Horizontal:
            ratio = pos.x() / self.width()
        else:
            ratio = 1.0 - (pos.y() / self.height())
        ratio = max(0.0, min(1.0, ratio))
        value = self.minimum() + ratio * (self.maximum() - self.minimum())
        self.setValue(int(value))


class SpotifyWidget(QFrame):
    """Spotifyプレイヤーウィジェット"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("spotifyWidget")
        self._border_radius = 12
        self._spotify_service = None
        self._is_authenticated = False
        self._current_playback = None
        self._album_art_pixmap = None
        self._album_art_url = None
        self._is_seeking = False
        self._is_volume_changing = False
        self.setup_ui()
        self.setup_spotify()
        self.setup_timers()

    def paintEvent(self, event):
        """カスタム描画で背景にアルバムアートを表示"""
        from PyQt5.QtGui import QPainterPath, QBrush, QLinearGradient
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing, True)
        painter.setRenderHint(QPainter.SmoothPixmapTransform, True)

        # 角丸パスを作成
        path = QPainterPath()
        path.addRoundedRect(0, 0, self.width(), self.height(),
                           self._border_radius, self._border_radius)
        painter.setClipPath(path)

        # 背景色（アルバムアートがない場合）
        painter.fillPath(path, QBrush(QColor(30, 30, 30)))

        # アルバムアートを背景として描画（しっかり見せる）
        if self._album_art_pixmap and not self._album_art_pixmap.isNull():
            scaled = self._album_art_pixmap.scaled(
                self.width(), self.height(),
                Qt.KeepAspectRatioByExpanding,
                Qt.SmoothTransformation
            )
            x = (self.width() - scaled.width()) // 2
            y = (self.height() - scaled.height()) // 2
            painter.drawPixmap(x, y, scaled)

        # 暗めオーバーレイ（テキスト視認性のため）
        gradient = QLinearGradient(0, 0, 0, self.height())
        gradient.setColorAt(0, QColor(0, 0, 0, 120))
        gradient.setColorAt(0.5, QColor(0, 0, 0, 100))
        gradient.setColorAt(1, QColor(0, 0, 0, 140))
        painter.fillPath(path, QBrush(gradient))

    def setup_ui(self):
        """UIの初期化"""
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(15, 10, 15, 12)
        main_layout.setSpacing(0)

        # アイコンパス（親ディレクトリのiconフォルダを参照）
        icon_dir = Path(__file__).parent.parent / "icon"

        # 上部: Spotifyロゴ + 再生ボタン
        top_row = QHBoxLayout()
        top_row.setSpacing(10)

        top_row.addStretch()

        # 右上: 再生ボタン
        self.play_btn = QPushButton()
        self.play_btn.setFixedSize(44, 44)
        self.play_btn.setCursor(Qt.PointingHandCursor)
        self.play_btn.setStyleSheet("QPushButton { background: transparent; border: none; }")
        self._play_icon = load_transparent_icon(icon_dir / "play.svg", 36, 36)
        self._pause_icon = load_transparent_icon(icon_dir / "stop.svg", 36, 36)
        self.play_btn.setIcon(QIcon(self._pause_icon))
        self.play_btn.setIconSize(QSize(36, 36))
        self.play_btn.clicked.connect(self._on_play_clicked)
        top_row.addWidget(self.play_btn)

        main_layout.addLayout(top_row)

        # 中央: 曲情報（左寄せ）
        main_layout.addStretch()

        self.track_label = QLabel("再生中の曲なし")
        self.track_label.setObjectName("spotifyTrackTitle")
        self.track_label.setStyleSheet("""
            color: rgba(255, 255, 255, 0.95);
            font-size: 18px;
            font-weight: bold;
            font-family: 'Hiragino Sans', 'Meiryo', 'Yu Gothic UI', sans-serif;
            background: transparent;
        """)
        main_layout.addWidget(self.track_label)

        self.artist_label = QLabel("")
        self.artist_label.setObjectName("spotifyArtistName")
        self.artist_label.setStyleSheet("""
            color: rgba(255, 255, 255, 0.6);
            font-size: 13px;
            font-family: 'Hiragino Sans', 'Meiryo', 'Yu Gothic UI', sans-serif;
            background: transparent;
        """)
        main_layout.addWidget(self.artist_label)

        main_layout.addSpacing(10)

        # 下部: コントロール
        bottom_row = QHBoxLayout()
        bottom_row.setSpacing(12)

        # 前の曲
        prev_pixmap = load_transparent_icon(icon_dir / "back.svg", 24, 24)
        self.prev_btn = QLabel()
        self.prev_btn.setFixedSize(32, 32)
        self.prev_btn.setAlignment(Qt.AlignCenter)
        self.prev_btn.setCursor(Qt.PointingHandCursor)
        self.prev_btn.setPixmap(prev_pixmap)
        self.prev_btn.mousePressEvent = lambda e: self._on_prev_clicked()
        bottom_row.addWidget(self.prev_btn)

        # シークバー
        self.seek_slider = QSlider(Qt.Horizontal)
        self.seek_slider.setObjectName("spotifySeekSlider")
        self.seek_slider.setRange(0, 1000)
        self.seek_slider.setValue(0)
        self.seek_slider.sliderPressed.connect(self._on_seek_pressed)
        self.seek_slider.sliderReleased.connect(self._on_seek_released)
        bottom_row.addWidget(self.seek_slider, 1)

        # 次の曲
        next_pixmap = load_transparent_icon(icon_dir / "next.svg", 24, 24)
        self.next_btn = QLabel()
        self.next_btn.setFixedSize(32, 32)
        self.next_btn.setAlignment(Qt.AlignCenter)
        self.next_btn.setCursor(Qt.PointingHandCursor)
        self.next_btn.setPixmap(next_pixmap)
        self.next_btn.mousePressEvent = lambda e: self._on_next_clicked()
        bottom_row.addWidget(self.next_btn)

        # シャッフル（ONは半透明白、OFFはグレー）
        self._shuffle_on_icon = load_transparent_icon(icon_dir / "shuffle.svg", 24, 24, color=QColor(255, 255, 255))
        self._shuffle_off_icon = load_transparent_icon(icon_dir / "shuffle.svg", 24, 24, color=QColor(120, 120, 120))
        self.shuffle_btn = QLabel()
        self.shuffle_btn.setFixedSize(32, 32)
        self.shuffle_btn.setAlignment(Qt.AlignCenter)
        self.shuffle_btn.setCursor(Qt.PointingHandCursor)
        self.shuffle_btn.setPixmap(self._shuffle_off_icon)
        self.shuffle_btn.mousePressEvent = lambda e: self._on_shuffle_clicked()
        bottom_row.addWidget(self.shuffle_btn)

        bottom_row.addSpacing(10)

        # 音量アイコン
        volume_icon = QLabel()
        volume_icon.setPixmap(load_transparent_icon(icon_dir / "volume.svg", 20, 20))
        bottom_row.addWidget(volume_icon)

        # 音量スライダー（タッチ操作しやすいカスタムスライダー）
        self.volume_slider = TouchFriendlySlider(Qt.Horizontal)
        self.volume_slider.setObjectName("spotifyVolumeSlider")
        self.volume_slider.setRange(0, 100)
        self.volume_slider.setValue(50)
        self.volume_slider.setFixedWidth(60)
        self.volume_slider.sliderReleased.connect(self._on_volume_released)
        self.volume_slider.valueChanged.connect(self._on_volume_changed)
        bottom_row.addWidget(self.volume_slider)

        main_layout.addLayout(bottom_row)

        # Mix選択ボタン行
        mix_row = QHBoxLayout()
        mix_row.setSpacing(8)
        mix_row.setContentsMargins(0, 2, 0, 0)

        mix_btn_style = """
            QPushButton {
                background: rgba(255,255,255,0.5);
                border: none;
                border-radius: 17px;
                color: white;
                font-size: 11px;
                padding-top: 1px;
            }
            QPushButton:pressed {
                background: rgba(255,255,255,0.7);
            }
        """

        # 🎲 Daily Mix
        self.daily_mix_btn = QPushButton()
        self.daily_mix_btn.setFixedSize(34, 34)
        self.daily_mix_btn.setStyleSheet(mix_btn_style)
        self.daily_mix_btn.setCursor(Qt.PointingHandCursor)
        self.daily_mix_btn.setIcon(QIcon(load_transparent_icon(icon_dir / "dailymix.png", 48, 48)))
        self.daily_mix_btn.setIconSize(QSize(48, 48))
        self.daily_mix_btn.clicked.connect(self._on_daily_mix_clicked)
        mix_row.addWidget(self.daily_mix_btn)

        # 😌 Chill Mix
        self.chill_mix_btn = QPushButton()
        self.chill_mix_btn.setFixedSize(34, 34)
        self.chill_mix_btn.setStyleSheet(mix_btn_style)
        self.chill_mix_btn.setCursor(Qt.PointingHandCursor)
        self.chill_mix_btn.setIcon(QIcon(load_transparent_icon(icon_dir / "chill.png", 48, 48)))
        self.chill_mix_btn.setIconSize(QSize(48, 48))
        self.chill_mix_btn.clicked.connect(self._on_chill_mix_clicked)
        mix_row.addWidget(self.chill_mix_btn)

        # ⚡ Upbeat Mix
        self.upbeat_mix_btn = QPushButton()
        self.upbeat_mix_btn.setFixedSize(34, 34)
        self.upbeat_mix_btn.setStyleSheet(mix_btn_style)
        self.upbeat_mix_btn.setCursor(Qt.PointingHandCursor)
        self.upbeat_mix_btn.setIcon(QIcon(load_transparent_icon(icon_dir / "up.png", 52, 52)))
        self.upbeat_mix_btn.setIconSize(QSize(52, 52))
        self.upbeat_mix_btn.clicked.connect(self._on_upbeat_mix_clicked)
        mix_row.addWidget(self.upbeat_mix_btn)

        mix_row.addStretch()

        # ♥ お気に入りに追加（白ハート / ピンク塗りつぶし）
        self._heart_normal_icon = QIcon(load_transparent_icon(icon_dir / "heart.svg", 28, 28))
        self._heart_saved_icon = QIcon(load_transparent_icon(icon_dir / "heart.svg", 28, 28, fill_color=QColor(255, 130, 170, 220), fill_inner=True))
        self.add_fav_btn = QPushButton()
        self.add_fav_btn.setFixedSize(34, 34)
        self.add_fav_btn.setStyleSheet("QPushButton { background: transparent; border: none; }")
        self.add_fav_btn.setCursor(Qt.PointingHandCursor)
        self.add_fav_btn.setIcon(self._heart_normal_icon)
        self.add_fav_btn.setIconSize(QSize(28, 28))
        self.add_fav_btn.clicked.connect(self._on_add_favorite_clicked)
        mix_row.addWidget(self.add_fav_btn)

        # ♥ お気に入り再生（半透明ハート + 縁取り三角）
        heart_pixmap = load_transparent_icon(icon_dir / "heart.svg", 32, 32)
        combined_pixmap = QPixmap(32, 32)
        combined_pixmap.fill(Qt.transparent)
        painter = QPainter(combined_pixmap)
        painter.setOpacity(0.5)  # ハートを半透明に
        painter.drawPixmap(0, 0, heart_pixmap)
        painter.setOpacity(1.0)
        painter.setFont(QFont("sans-serif", 10, QFont.Bold))
        # グレーの縁取り
        painter.setPen(QColor(140, 140, 140))
        for dx, dy in [(-1,0), (1,0), (0,-1), (0,1)]:
            painter.drawText(17 + dx, 27 + dy, "▶")
        # 半透明の白
        painter.setPen(QColor(255, 255, 255, 200))
        painter.drawText(17, 27, "▶")
        painter.end()
        self.play_fav_btn = QPushButton()
        self.play_fav_btn.setFixedSize(34, 34)
        self.play_fav_btn.setStyleSheet("QPushButton { background: transparent; border: none; }")
        self.play_fav_btn.setCursor(Qt.PointingHandCursor)
        self.play_fav_btn.setIcon(QIcon(combined_pixmap))
        self.play_fav_btn.setIconSize(QSize(32, 32))
        self.play_fav_btn.clicked.connect(self._on_play_favorites_clicked)
        mix_row.addWidget(self.play_fav_btn)

        main_layout.addLayout(mix_row)

        # トースト通知ラベル（フェードイン・アウト）
        self._toast_label = QLabel(self)
        self._toast_label.setStyleSheet("""
            QLabel {
                background: rgba(30, 215, 96, 0.9);
                color: white;
                font-size: 13px;
                font-weight: bold;
                padding: 8px 16px;
                border-radius: 16px;
            }
        """)
        self._toast_label.setAlignment(Qt.AlignCenter)
        self._toast_label.hide()
        self._toast_opacity = QGraphicsOpacityEffect(self._toast_label)
        self._toast_label.setGraphicsEffect(self._toast_opacity)

        # 非表示のダミー（リピート機能は残すがUIには出さない）
        self.repeat_btn = QPushButton()
        self.repeat_btn.hide()

        # 非表示のダミー（時間ラベルは削除）
        self.progress_label = QLabel()
        self.duration_label = QLabel()

    def setup_spotify(self):
        """Spotifyサービスの初期化"""
        try:
            from spotify_service import get_spotify_service
            self._spotify_service = get_spotify_service()
            # バックグラウンドで認証
            threading.Thread(target=self._authenticate, daemon=True).start()
        except ImportError as e:
            print(f"Spotify service import error: {e}")

    def _authenticate(self):
        """認証を実行"""
        if not self._spotify_service:
            return
        try:
            self._spotify_service.authenticate()
            self._is_authenticated = True
            self._fetch_playback()
        except Exception as e:
            print(f"Spotify auth error: {e}")

    def setup_timers(self):
        """タイマーの設定"""
        # 再生状態更新（5秒ごと）
        self._playback_timer = QTimer(self)
        self._playback_timer.timeout.connect(self._fetch_playback)
        self._playback_timer.start(5000)

        # シークバー更新（1秒ごと）
        self._progress_timer = QTimer(self)
        self._progress_timer.timeout.connect(self._update_progress)
        self._progress_timer.start(1000)

    def _fetch_playback(self):
        """再生状態を取得"""
        if not self._is_authenticated or not self._spotify_service:
            return

        def fetch():
            playback = self._spotify_service.get_current_playback()
            if playback:
                self._current_playback = playback
                # UIはメインスレッドで更新
                QTimer.singleShot(0, self._update_ui)

        threading.Thread(target=fetch, daemon=True).start()

    def _update_ui(self):
        """UIを更新"""
        if not self._current_playback:
            return

        pb = self._current_playback

        # トラック情報
        self.track_label.setText(pb['track_name'] or "再生中の曲なし")
        self.artist_label.setText(pb['artist_name'] or "")

        # 再生/一時停止ボタン
        self.play_btn.setIcon(QIcon(self._pause_icon if pb['is_playing'] else self._play_icon))

        # 時間表示
        duration_ms = pb['duration_ms']
        self.duration_label.setText(self._format_time(duration_ms))

        # シャッフル状態
        self.shuffle_btn.setPixmap(self._shuffle_on_icon if pb['shuffle_state'] else self._shuffle_off_icon)

        # リピート状態
        repeat_state = pb['repeat_state']
        if repeat_state == 'off':
            repeat_style = "color: rgba(255,255,255,0.5);"
            repeat_text = "🔁"
        elif repeat_state == 'context':
            repeat_style = "color: rgba(255,255,255,1.0);"
            repeat_text = "🔁"
        else:  # track
            repeat_style = "color: rgba(255,255,255,1.0);"
            repeat_text = "🔂"
        self.repeat_btn.setText(repeat_text)
        self.repeat_btn.setStyleSheet(f"background: transparent; border: none; font-size: 14px; {repeat_style}")

        # 音量
        if not self._is_volume_changing:
            self.volume_slider.setValue(pb['volume_percent'])

        # アルバムアート更新
        if pb['album_art_url'] and pb['album_art_url'] != self._album_art_url:
            self._album_art_url = pb['album_art_url']
            self._load_album_art(pb['album_art_url'])

        # お気に入り状態更新
        track_id = pb.get('track_id')
        if track_id and self._spotify_service:
            is_saved = self._spotify_service.is_current_track_saved(track_id)
            self.add_fav_btn.setIcon(self._heart_saved_icon if is_saved else self._heart_normal_icon)

    def _update_progress(self):
        """シークバーの進行を更新"""
        if not self._current_playback or self._is_seeking:
            return

        pb = self._current_playback
        if pb['is_playing']:
            # 再生中は進行を推定
            pb['progress_ms'] = min(pb['progress_ms'] + 1000, pb['duration_ms'])

        progress_ms = pb['progress_ms']
        duration_ms = pb['duration_ms']

        self.progress_label.setText(self._format_time(progress_ms))

        if duration_ms > 0:
            position = int(progress_ms * 1000 / duration_ms)
            self.seek_slider.setValue(position)

    def _format_time(self, ms):
        """ミリ秒を mm:ss 形式に変換"""
        seconds = ms // 1000
        minutes = seconds // 60
        seconds = seconds % 60
        return f"{minutes}:{seconds:02d}"

    def _load_album_art(self, url):
        """アルバムアートを読み込み"""
        def load():
            try:
                import urllib.request
                from PyQt5.QtGui import QPixmap
                from PyQt5.QtCore import QByteArray

                request = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
                with urllib.request.urlopen(request, timeout=10) as response:
                    data = response.read()

                pixmap = QPixmap()
                pixmap.loadFromData(QByteArray(data))

                if not pixmap.isNull():
                    self._album_art_pixmap = pixmap
                    QTimer.singleShot(0, self._update_album_art_ui)
            except Exception as e:
                print(f"Album art load error: {e}")

        threading.Thread(target=load, daemon=True).start()

    def _update_album_art_ui(self):
        """アルバムアートUIを更新（背景のみ）"""
        self.update()  # 背景を再描画

    # コントロールイベント
    def _on_play_clicked(self):
        """通常の再生/一時停止切り替え"""
        if self._spotify_service:
            threading.Thread(target=self._spotify_service.toggle_playback, daemon=True).start()
            # UIを即時更新
            if self._current_playback:
                self._current_playback['is_playing'] = not self._current_playback['is_playing']
                self.play_btn.setIcon(QIcon(self._pause_icon if self._current_playback['is_playing'] else self._play_icon))

    def _on_prev_clicked(self):
        if self._spotify_service:
            threading.Thread(target=self._spotify_service.previous_track, daemon=True).start()
            QTimer.singleShot(500, self._fetch_playback)

    def _on_next_clicked(self):
        if self._spotify_service:
            threading.Thread(target=self._spotify_service.next_track, daemon=True).start()
            QTimer.singleShot(500, self._fetch_playback)

    def _on_shuffle_clicked(self):
        if self._spotify_service:
            threading.Thread(target=self._spotify_service.toggle_shuffle, daemon=True).start()
            if self._current_playback:
                self._current_playback['shuffle_state'] = not self._current_playback['shuffle_state']
                self._update_ui()

    def _on_repeat_clicked(self):
        if self._spotify_service:
            threading.Thread(target=self._spotify_service.cycle_repeat, daemon=True).start()
            if self._current_playback:
                current = self._current_playback['repeat_state']
                next_state = {'off': 'context', 'context': 'track', 'track': 'off'}.get(current, 'off')
                self._current_playback['repeat_state'] = next_state
                self._update_ui()

    def _on_daily_mix_clicked(self):
        """Daily Mix再生"""
        if self._spotify_service:
            self.track_label.setText("🎲 Daily Mix...")
            self.shuffle_btn.setPixmap(self._shuffle_on_icon)  # シャッフルON
            if self._current_playback:
                self._current_playback['shuffle_state'] = True
            threading.Thread(target=self._spotify_service.play_random_playlist, daemon=True).start()
            QTimer.singleShot(3000, self._fetch_playback)

    def _on_chill_mix_clicked(self):
        """Chill Mix再生"""
        if self._spotify_service:
            self.track_label.setText("😌 Chill Mix...")
            self.shuffle_btn.setPixmap(self._shuffle_on_icon)  # シャッフルON
            if self._current_playback:
                self._current_playback['shuffle_state'] = True
            threading.Thread(target=self._spotify_service.play_chill_mix, daemon=True).start()
            QTimer.singleShot(3000, self._fetch_playback)

    def _on_upbeat_mix_clicked(self):
        """Upbeat Mix再生"""
        if self._spotify_service:
            self.track_label.setText("⚡ Upbeat Mix...")
            self.shuffle_btn.setPixmap(self._shuffle_on_icon)  # シャッフルON
            if self._current_playback:
                self._current_playback['shuffle_state'] = True
            threading.Thread(target=self._spotify_service.play_upbeat_mix, daemon=True).start()
            QTimer.singleShot(3000, self._fetch_playback)

    def _on_add_favorite_clicked(self):
        """現在の曲をお気に入りに追加/削除（トグル）"""
        if not self._spotify_service:
            return

        # 現在のアイコン状態から判断（UIスレッドで即座に）
        current_icon = self.add_fav_btn.icon()
        is_saved = (current_icon.cacheKey() == self._heart_saved_icon.cacheKey())

        if is_saved:
            # 削除
            self._show_toast("お気に入りから削除しました")
            self.add_fav_btn.setIcon(self._heart_normal_icon)
            threading.Thread(target=self._spotify_service.remove_current_from_favorites, daemon=True).start()
        else:
            # 追加
            self._show_toast("お気に入りに追加しました")
            self.add_fav_btn.setIcon(self._heart_saved_icon)
            threading.Thread(target=self._spotify_service.add_current_to_favorites, daemon=True).start()

    def _show_toast(self, message):
        """おしゃれなトースト通知を表示"""
        self._toast_label.setText(message)
        self._toast_label.adjustSize()
        # 中央に配置
        x = (self.width() - self._toast_label.width()) // 2
        y = self.height() - self._toast_label.height() - 20
        self._toast_label.move(x, y)
        self._toast_label.show()
        self._toast_opacity.setOpacity(1.0)

        # フェードアウトアニメーション
        self._fade_anim = QPropertyAnimation(self._toast_opacity, b"opacity")
        self._fade_anim.setDuration(1500)
        self._fade_anim.setStartValue(1.0)
        self._fade_anim.setEndValue(0.0)
        self._fade_anim.setEasingCurve(QEasingCurve.InQuad)
        self._fade_anim.finished.connect(self._toast_label.hide)
        QTimer.singleShot(1000, self._fade_anim.start)

    def _on_play_favorites_clicked(self):
        """お気に入り再生"""
        if self._spotify_service:
            self.track_label.setText("♥ お気に入り...")
            self.shuffle_btn.setPixmap(self._shuffle_on_icon)  # シャッフルON
            if self._current_playback:
                self._current_playback['shuffle_state'] = True
            threading.Thread(target=self._spotify_service.play_favorites, daemon=True).start()
            QTimer.singleShot(3000, self._fetch_playback)

    def _on_seek_pressed(self):
        self._is_seeking = True

    def _on_seek_released(self):
        self._is_seeking = False
        if self._spotify_service and self._current_playback:
            duration_ms = self._current_playback['duration_ms']
            position = self.seek_slider.value()
            seek_ms = int(position * duration_ms / 1000)
            self._current_playback['progress_ms'] = seek_ms
            threading.Thread(target=lambda: self._spotify_service.seek(seek_ms), daemon=True).start()

    def _on_volume_pressed(self):
        self._is_volume_changing = True

    def _on_volume_changed(self, value):
        """音量スライダーの値が変わった時（フラグ設定）"""
        self._is_volume_changing = True

    def _on_volume_released(self):
        self._is_volume_changing = False
        if self._spotify_service:
            volume = self.volume_slider.value()
            threading.Thread(target=lambda: self._spotify_service.set_volume(volume), daemon=True).start()


