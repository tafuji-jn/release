# -*- coding: utf-8 -*-
"""スライドメニューウィジェット"""

from PyQt5.QtWidgets import QFrame, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QWidget
from PyQt5.QtCore import Qt, QPoint, QPropertyAnimation, QEasingCurve, pyqtSignal


class SlideMenu(QFrame):
    """左からスライドインするメニュー"""

    themeChanged = pyqtSignal(str)  # 'light' or 'dark'
    rebootRequested = pyqtSignal()  # 端末再起動リクエスト
    googleAuthRequested = pyqtSignal()  # Google再認証リクエスト
    spotifyAuthRequested = pyqtSignal()  # Spotify再認証リクエスト
    bluetoothDeviceChanged = pyqtSignal(str)  # Bluetooth接続先変更
    updateCheckRequested = pyqtSignal()  # アプリ更新チェックリクエスト

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("slideMenu")
        self._is_visible = False
        self._menu_width = 250
        self.setup_ui()

    def setup_ui(self):
        """UIの初期化"""
        self.setFixedWidth(self._menu_width)
        self.setStyleSheet("""
            #slideMenu {
                background-color: rgba(30, 30, 30, 0.95);
                border-right: 1px solid #444;
            }
            #menuTitle {
                color: #ffffff;
                font-size: 18px;
                font-weight: bold;
                padding: 15px;
            }
            #menuItem {
                color: #ffffff;
                font-size: 14px;
                padding: 12px 20px;
                border: none;
                text-align: left;
            }
            #menuItem:hover {
                background-color: rgba(255, 255, 255, 0.1);
            }
            #menuItem:pressed {
                background-color: rgba(255, 255, 255, 0.2);
            }
            #menuItemActive {
                color: #ffffff;
                font-size: 14px;
                padding: 12px 20px;
                border: none;
                text-align: left;
                background-color: rgba(233, 69, 96, 0.8);
            }
            #sectionLabel {
                color: #888888;
                font-size: 12px;
                padding: 15px 20px 5px 20px;
            }
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # タイトル
        title = QLabel("設定")
        title.setObjectName("menuTitle")
        layout.addWidget(title)

        # セクション: テーマ
        theme_label = QLabel("カレンダーテーマ")
        theme_label.setObjectName("sectionLabel")
        layout.addWidget(theme_label)

        # ライトテーマボタン
        self.light_btn = QPushButton("☀️  ライト（白基調）")
        self.light_btn.setObjectName("menuItemActive")
        self.light_btn.clicked.connect(lambda: self._on_theme_selected('light'))
        layout.addWidget(self.light_btn)

        # ダークテーマボタン
        self.dark_btn = QPushButton("🌙  ダーク（黒基調）")
        self.dark_btn.setObjectName("menuItem")
        self.dark_btn.clicked.connect(lambda: self._on_theme_selected('dark'))
        layout.addWidget(self.dark_btn)

        # セクション: アカウント連携
        account_label = QLabel("アカウント連携")
        account_label.setObjectName("sectionLabel")
        layout.addWidget(account_label)

        # Google認証ボタン
        self.google_auth_btn = QPushButton("📅  Google カレンダー認証")
        self.google_auth_btn.setObjectName("menuItem")
        self.google_auth_btn.clicked.connect(self._on_google_auth_clicked)
        layout.addWidget(self.google_auth_btn)

        # Spotify認証ボタン
        self.spotify_auth_btn = QPushButton("🎵  Spotify 認証")
        self.spotify_auth_btn.setObjectName("menuItem")
        self.spotify_auth_btn.clicked.connect(self._on_spotify_auth_clicked)
        layout.addWidget(self.spotify_auth_btn)

        layout.addStretch()

        # セクション: システム
        system_label = QLabel("システム")
        system_label.setObjectName("sectionLabel")
        layout.addWidget(system_label)

        # アプリ更新チェックボタン
        self.update_check_btn = QPushButton("🔄  アプリ更新チェック")
        self.update_check_btn.setObjectName("menuItem")
        self.update_check_btn.clicked.connect(self._on_update_check_clicked)
        layout.addWidget(self.update_check_btn)

        # 端末再起動ボタン
        self.reboot_btn = QPushButton("🔄  端末を再起動")
        self.reboot_btn.setObjectName("menuItem")
        self.reboot_btn.setStyleSheet("""
            QPushButton {
                color: #ff6b6b;
                font-size: 14px;
                padding: 12px 20px;
                border: none;
                text-align: left;
                background: transparent;
            }
            QPushButton:hover {
                background-color: rgba(255, 107, 107, 0.2);
            }
            QPushButton:pressed {
                background-color: rgba(255, 107, 107, 0.3);
            }
        """)
        self.reboot_btn.clicked.connect(self._on_reboot_clicked)
        layout.addWidget(self.reboot_btn)

        # 端末シャットダウンボタン
        self.shutdown_btn = QPushButton("⏻  端末をシャットダウン")
        self.shutdown_btn.setObjectName("menuItem")
        self.shutdown_btn.setStyleSheet("""
            QPushButton {
                color: #ff6b6b;
                font-size: 14px;
                padding: 12px 20px;
                border: none;
                text-align: left;
                background: transparent;
            }
            QPushButton:hover {
                background-color: rgba(255, 107, 107, 0.2);
            }
            QPushButton:pressed {
                background-color: rgba(255, 107, 107, 0.3);
            }
        """)
        self.shutdown_btn.clicked.connect(self._on_shutdown_clicked)
        layout.addWidget(self.shutdown_btn)

        # 閉じるヒント
        hint = QLabel("← スワイプで閉じる")
        hint.setObjectName("sectionLabel")
        hint.setAlignment(Qt.AlignCenter)
        layout.addWidget(hint)

        # 初期状態: 画面外に配置
        self.move(-self._menu_width, 0)

    def _on_theme_selected(self, theme):
        """テーマ選択時"""
        self._update_button_states(theme)
        self.themeChanged.emit(theme)

    def _on_reboot_clicked(self):
        """再起動ボタンクリック時"""
        from PyQt5.QtWidgets import QMessageBox
        msg = QMessageBox()
        msg.setWindowTitle("端末再起動")
        msg.setText("端末を再起動しますか？")
        msg.setIcon(QMessageBox.Warning)
        msg.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        msg.setDefaultButton(QMessageBox.No)
        msg.button(QMessageBox.Yes).setText("再起動")
        msg.button(QMessageBox.No).setText("キャンセル")
        msg.setStyleSheet("""
            QMessageBox {
                background-color: #2a2a2a;
            }
            QMessageBox QLabel {
                color: #ffffff;
                font-size: 14px;
            }
            QPushButton {
                background-color: #444;
                color: #fff;
                border: none;
                border-radius: 4px;
                padding: 8px 20px;
                font-size: 14px;
                min-width: 80px;
            }
            QPushButton:hover {
                background-color: #555;
            }
        """)

        if msg.exec_() == QMessageBox.Yes:
            import subprocess
            subprocess.run(['sudo', 'reboot'])

    def _on_shutdown_clicked(self):
        """シャットダウンボタンクリック時"""
        from PyQt5.QtWidgets import QMessageBox
        msg = QMessageBox()
        msg.setWindowTitle("端末シャットダウン")
        msg.setText("端末をシャットダウンしますか？")
        msg.setIcon(QMessageBox.Warning)
        msg.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        msg.setDefaultButton(QMessageBox.No)
        msg.button(QMessageBox.Yes).setText("シャットダウン")
        msg.button(QMessageBox.No).setText("キャンセル")
        msg.setStyleSheet("""
            QMessageBox {
                background-color: #2a2a2a;
            }
            QMessageBox QLabel {
                color: #ffffff;
                font-size: 14px;
            }
            QPushButton {
                background-color: #444;
                color: #fff;
                border: none;
                border-radius: 4px;
                padding: 8px 20px;
                font-size: 14px;
                min-width: 80px;
            }
            QPushButton:hover {
                background-color: #555;
            }
        """)

        if msg.exec_() == QMessageBox.Yes:
            import subprocess
            subprocess.run(['sudo', 'shutdown', '-h', 'now'])

    def set_current_theme(self, theme):
        """現在のテーマ状態を設定（シグナルなし）"""
        self._update_button_states(theme)

    def _update_button_states(self, theme):
        """ボタンの選択状態を更新"""
        if theme == 'light':
            self.light_btn.setObjectName("menuItemActive")
            self.dark_btn.setObjectName("menuItem")
        else:
            self.light_btn.setObjectName("menuItem")
            self.dark_btn.setObjectName("menuItemActive")
        # スタイル再適用
        self.light_btn.setStyle(self.light_btn.style())
        self.dark_btn.setStyle(self.dark_btn.style())

    def show_menu(self):
        """メニューを表示"""
        if self._is_visible:
            return
        self._is_visible = True
        self.show()
        self.raise_()

        self._anim = QPropertyAnimation(self, b"pos")
        self._anim.setDuration(200)
        self._anim.setStartValue(QPoint(-self._menu_width, 0))
        self._anim.setEndValue(QPoint(0, 0))
        self._anim.setEasingCurve(QEasingCurve.OutCubic)
        self._anim.start()

    def hide_menu(self):
        """メニューを非表示"""
        if not self._is_visible:
            return
        self._is_visible = False

        self._anim = QPropertyAnimation(self, b"pos")
        self._anim.setDuration(200)
        self._anim.setStartValue(self.pos())
        self._anim.setEndValue(QPoint(-self._menu_width, 0))
        self._anim.setEasingCurve(QEasingCurve.InCubic)
        self._anim.finished.connect(self.hide)
        self._anim.start()

    def is_menu_visible(self):
        return self._is_visible

    def _on_google_auth_clicked(self):
        """Google認証ボタンクリック時"""
        self.googleAuthRequested.emit()

    def _on_spotify_auth_clicked(self):
        """Spotify認証ボタンクリック時"""
        self.spotifyAuthRequested.emit()

    def _on_update_check_clicked(self):
        """更新チェックボタンクリック時"""
        self.updateCheckRequested.emit()

    def refresh_bt_devices(self):
        """Bluetoothデバイス一覧を更新（互換性のため）"""
        pass

    def update_auth_status(self, service, is_authenticated):
        """認証ステータスを更新してボタンの表示を変更"""
        if service == 'google':
            if is_authenticated:
                self.google_auth_btn.setText("📅  Google カレンダー (認証済)")
                self.google_auth_btn.setStyleSheet("""
                    QPushButton {
                        color: #4caf50;
                        font-size: 14px;
                        padding: 12px 20px;
                        border: none;
                        text-align: left;
                        background: transparent;
                    }
                    QPushButton:hover {
                        background-color: rgba(76, 175, 80, 0.2);
                    }
                """)
            else:
                self.google_auth_btn.setText("📅  Google カレンダー認証")
                self.google_auth_btn.setStyleSheet("")
                self.google_auth_btn.setObjectName("menuItem")
                self.google_auth_btn.setStyle(self.google_auth_btn.style())

        elif service == 'spotify':
            if is_authenticated:
                self.spotify_auth_btn.setText("🎵  Spotify (認証済)")
                self.spotify_auth_btn.setStyleSheet("""
                    QPushButton {
                        color: #4caf50;
                        font-size: 14px;
                        padding: 12px 20px;
                        border: none;
                        text-align: left;
                        background: transparent;
                    }
                    QPushButton:hover {
                        background-color: rgba(76, 175, 80, 0.2);
                    }
                """)
            else:
                self.spotify_auth_btn.setText("🎵  Spotify 認証")
                self.spotify_auth_btn.setStyleSheet("")
                self.spotify_auth_btn.setObjectName("menuItem")
                self.spotify_auth_btn.setStyle(self.spotify_auth_btn.style())
