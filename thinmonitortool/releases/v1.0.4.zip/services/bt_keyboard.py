# -*- coding: utf-8 -*-
"""
Bluetooth Keyboard Service
D-Bus Profile APIを使用したHIDキーボード実装
"""

import os
import sys
import dbus
import dbus.service
import dbus.mainloop.glib
import socket
import threading
import time

# HID キーコードマッピング
HID_KEYCODES = {
    # ファンクションキー
    'F1': 0x3A, 'F2': 0x3B, 'F3': 0x3C, 'F4': 0x3D,
    'F5': 0x3E, 'F6': 0x3F, 'F7': 0x40, 'F8': 0x41,
    'F9': 0x42, 'F10': 0x43, 'F11': 0x44, 'F12': 0x45,
    'F13': 0x68, 'F14': 0x69, 'F15': 0x6A, 'F16': 0x6B,
    'F17': 0x6C, 'F18': 0x6D, 'F19': 0x6E, 'F20': 0x6F,
    'F21': 0x70, 'F22': 0x71, 'F23': 0x72, 'F24': 0x73,

    # 修飾キー（ビットマスク）
    'CTRL': 0x01, 'SHIFT': 0x02, 'ALT': 0x04, 'GUI': 0x08, 'WIN': 0x08,
    'LCTRL': 0x01, 'LSHIFT': 0x02, 'LALT': 0x04, 'LGUI': 0x08, 'LWIN': 0x08,
    'RCTRL': 0x10, 'RSHIFT': 0x20, 'RALT': 0x40, 'RGUI': 0x80, 'RWIN': 0x80,

    # 基本キー
    'ENTER': 0x28, 'RETURN': 0x28, 'ESC': 0x29, 'ESCAPE': 0x29,
    'BACKSPACE': 0x2A, 'BS': 0x2A, 'TAB': 0x2B, 'SPACE': 0x2C,

    # 記号キー
    'MINUS': 0x2D, 'EQUAL': 0x2E, 'LBRACKET': 0x2F, 'RBRACKET': 0x30,
    'BACKSLASH': 0x31, 'SEMICOLON': 0x33, 'QUOTE': 0x34, 'APOSTROPHE': 0x34,
    'GRAVE': 0x35, 'BACKQUOTE': 0x35, 'TILDE': 0x35,
    'COMMA': 0x36, 'PERIOD': 0x37, 'DOT': 0x37, 'SLASH': 0x38,

    # Windows OEM キー名エイリアス（DeckConfigurator互換）
    'OEM_AUTO': 0x35,      # 半角/全角
    'OEM_MINUS': 0x2D,     # -
    'OEM_7': 0x2E,         # ^ (JIS)
    'OEM_5': 0x89,         # ¥ (JIS)
    'OEM_3': 0x2F,         # @ (JIS) → [ 位置
    'OEM_4': 0x2F,         # [
    'OEM_PLUS': 0x33,      # ; (JIS)
    'OEM_1': 0x34,         # : (JIS) → ' 位置
    'OEM_6': 0x30,         # ]
    'OEM_COMMA': 0x36,     # ,
    'OEM_PERIOD': 0x37,    # .
    'OEM_2': 0x38,         # /
    'OEM_102': 0x87,       # \ (JIS、ろキー位置)
    'OEM_CONVERT': 0x8B,   # 無変換
    'CONVERT': 0x8A,       # 変換
    'OEM_COPY': 0x88,      # カタカナ/ひらがな
    'CAPITAL': 0x39,       # CapsLock
    'PAGE_UP': 0x4B,       # PageUp
    'PAGE_DOWN': 0x4E,     # PageDown
    'APPS': 0x65,          # アプリケーションキー

    # ロック・特殊キー
    'CAPSLOCK': 0x39, 'CAPS': 0x39,
    'PRINTSCREEN': 0x46, 'PRTSC': 0x46, 'SYSRQ': 0x46,
    'SCROLLLOCK': 0x47, 'PAUSE': 0x48, 'BREAK': 0x48,

    # ナビゲーションキー
    'INSERT': 0x49, 'INS': 0x49,
    'HOME': 0x4A, 'PAGEUP': 0x4B, 'PGUP': 0x4B,
    'DELETE': 0x4C, 'DEL': 0x4C,
    'END': 0x4D, 'PAGEDOWN': 0x4E, 'PGDN': 0x4E,
    'RIGHT': 0x4F, 'LEFT': 0x50, 'DOWN': 0x51, 'UP': 0x52,

    # テンキー
    'NUMLOCK': 0x53, 'NUMPAD_DIVIDE': 0x54, 'NUMPAD_MULTIPLY': 0x55,
    'NUMPAD_MINUS': 0x56, 'NUMPAD_PLUS': 0x57, 'NUMPAD_ENTER': 0x58,
    'NUMPAD_1': 0x59, 'NUMPAD_2': 0x5A, 'NUMPAD_3': 0x5B,
    'NUMPAD_4': 0x5C, 'NUMPAD_5': 0x5D, 'NUMPAD_6': 0x5E,
    'NUMPAD_7': 0x5F, 'NUMPAD_8': 0x60, 'NUMPAD_9': 0x61,
    'NUMPAD_0': 0x62, 'NUMPAD_DOT': 0x63, 'NUMPAD_EQUAL': 0x67,

    # アプリケーションキー
    'APP': 0x65, 'MENU': 0x65, 'CONTEXTMENU': 0x65,

    # 日本語キーボード専用キー
    'ZENKAKU_HANKAKU': 0x35,     # 半角/全角（多くの環境でGraveと同じ）
    'HANKAKU': 0x35, 'ZENKAKU': 0x35,
    'HENKAN': 0x8A,              # 変換
    'MUHENKAN': 0x8B,            # 無変換
    'KATAKANA': 0x88,            # カタカナ/ひらがな
    'HIRAGANA': 0x88,
    'KANA': 0x88,
    'RO': 0x87,                  # ろ（バックスラッシュの位置）
    'YEN': 0x89,                 # ¥（円マーク）

    # 言語切り替えキー
    'LANG1': 0x90,               # かな/英数（Mac）/ Hangul（韓国語）
    'LANG2': 0x91,               # 英数（Mac）/ Hanja（韓国語）
    'LANG3': 0x92,               # カタカナ
    'LANG4': 0x93,               # ひらがな
    'LANG5': 0x94,               # 全角/半角

    # IME制御（エイリアス）
    'IME': 0x35,                 # IME切り替え（環境依存）
    'IME_ON': 0x8A,              # 変換キーでIME ON
    'IME_OFF': 0x8B,             # 無変換キーでIME OFF

    # メディアキー（Consumer Control - 別レポートが必要だが一応定義）
    'MUTE': 0x7F, 'VOLUMEUP': 0x80, 'VOLUMEDOWN': 0x81,

    # アルファベット（小文字）
    'a': 0x04, 'b': 0x05, 'c': 0x06, 'd': 0x07, 'e': 0x08,
    'f': 0x09, 'g': 0x0A, 'h': 0x0B, 'i': 0x0C, 'j': 0x0D,
    'k': 0x0E, 'l': 0x0F, 'm': 0x10, 'n': 0x11, 'o': 0x12,
    'p': 0x13, 'q': 0x14, 'r': 0x15, 's': 0x16, 't': 0x17,
    'u': 0x18, 'v': 0x19, 'w': 0x1A, 'x': 0x1B, 'y': 0x1C, 'z': 0x1D,

    # アルファベット（大文字）
    'A': 0x04, 'B': 0x05, 'C': 0x06, 'D': 0x07, 'E': 0x08,
    'F': 0x09, 'G': 0x0A, 'H': 0x0B, 'I': 0x0C, 'J': 0x0D,
    'K': 0x0E, 'L': 0x0F, 'M': 0x10, 'N': 0x11, 'O': 0x12,
    'P': 0x13, 'Q': 0x14, 'R': 0x15, 'S': 0x16, 'T': 0x17,
    'U': 0x18, 'V': 0x19, 'W': 0x1A, 'X': 0x1B, 'Y': 0x1C, 'Z': 0x1D,

    # 数字
    '1': 0x1E, '2': 0x1F, '3': 0x20, '4': 0x21, '5': 0x22,
    '6': 0x23, '7': 0x24, '8': 0x25, '9': 0x26, '0': 0x27,
}

MODIFIER_KEYS = {'CTRL', 'SHIFT', 'ALT', 'GUI', 'WIN', 'LCTRL', 'LSHIFT', 'LALT', 'LGUI', 'LWIN', 'RCTRL', 'RSHIFT', 'RALT', 'RGUI', 'RWIN'}

P_CTRL = 17
P_INTR = 19


class BluetoothKeyboardService:
    """Bluetooth HID Keyboard Service"""

    def __init__(self):
        self._control_sock = None
        self._interrupt_sock = None
        self._control_client = None
        self._interrupt_client = None
        self._target_address = None
        self._is_connected = False
        self._running = False
        self._connection_thread = None

    def start(self, target_address=None):
        """サービスを開始"""
        if self._running:
            return True

        self._target_address = target_address
        self._running = True

        if target_address:
            # クライアントモード: ターゲットに接続
            self._connection_thread = threading.Thread(target=self._connect_to_target, daemon=True)
        else:
            # サーバーモード: 接続を待機
            self._connection_thread = threading.Thread(target=self._listen_for_connections, daemon=True)

        self._connection_thread.start()
        return True

    def stop(self):
        """サービスを停止"""
        self._running = False
        self._close_sockets()

    def _close_sockets(self):
        for sock in [self._control_client, self._interrupt_client, self._control_sock, self._interrupt_sock]:
            if sock:
                try:
                    sock.close()
                except:
                    pass
        self._control_client = None
        self._interrupt_client = None
        self._is_connected = False

    def _connect_to_target(self):
        """ターゲットデバイスに接続（クライアントモード・自動再接続）"""
        retry_delay = 5  # 再試行間隔（秒）

        while self._running:
            print(f"BT Keyboard: Connecting to {self._target_address}...")

            try:
                # Control channel
                self._control_sock = socket.socket(socket.AF_BLUETOOTH, socket.SOCK_SEQPACKET, socket.BTPROTO_L2CAP)
                self._control_sock.settimeout(10.0)
                self._control_sock.connect((self._target_address, P_CTRL))
                print("BT Keyboard: Control channel connected")

                # Interrupt channel
                self._interrupt_sock = socket.socket(socket.AF_BLUETOOTH, socket.SOCK_SEQPACKET, socket.BTPROTO_L2CAP)
                self._interrupt_sock.settimeout(10.0)
                self._interrupt_sock.connect((self._target_address, P_INTR))
                print("BT Keyboard: Interrupt channel connected")

                self._control_client = self._control_sock
                self._interrupt_client = self._interrupt_sock
                self._is_connected = True
                print("BT Keyboard: Connected!")

                # 接続維持（切断検知）
                while self._running and self._is_connected:
                    try:
                        # ソケットの接続状態をチェック
                        self._interrupt_sock.getpeername()
                        time.sleep(1)
                    except (OSError, socket.error) as e:
                        print(f"BT Keyboard: Connection lost - {e}")
                        self._is_connected = False
                        self._close_sockets()
                        break

            except Exception as e:
                if self._running:
                    print(f"BT Keyboard: Connection error - {e}, retrying in {retry_delay}s...")
                self._is_connected = False
                self._close_sockets()

            # 再接続前に待機
            if self._running and not self._is_connected:
                time.sleep(retry_delay)

    def _listen_for_connections(self):
        """接続を待機（サーバーモード）"""
        try:
            self._control_sock = socket.socket(socket.AF_BLUETOOTH, socket.SOCK_SEQPACKET, socket.BTPROTO_L2CAP)
            self._control_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self._control_sock.bind((socket.BDADDR_ANY, P_CTRL))
            self._control_sock.listen(1)

            self._interrupt_sock = socket.socket(socket.AF_BLUETOOTH, socket.SOCK_SEQPACKET, socket.BTPROTO_L2CAP)
            self._interrupt_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self._interrupt_sock.bind((socket.BDADDR_ANY, P_INTR))
            self._interrupt_sock.listen(1)

            print("BT Keyboard: Waiting for connections...")

            while self._running:
                try:
                    self._control_sock.settimeout(1.0)
                    self._control_client, ctrl_addr = self._control_sock.accept()
                    print(f"BT Keyboard: Control connected from {ctrl_addr}")

                    self._interrupt_sock.settimeout(5.0)
                    self._interrupt_client, intr_addr = self._interrupt_sock.accept()
                    print(f"BT Keyboard: Interrupt connected from {intr_addr}")

                    self._is_connected = True
                    print("BT Keyboard: Fully connected!")

                    while self._running and self._is_connected:
                        time.sleep(1)

                except socket.timeout:
                    continue
                except Exception as e:
                    print(f"BT Keyboard: Error - {e}")
                    self._close_sockets()
                    time.sleep(1)

        except Exception as e:
            print(f"BT Keyboard: Socket error - {e}")

    def is_connected(self):
        return self._is_connected

    def send_key(self, key_string):
        """キーを送信（STRING:xxx形式で文字列、MACRO:xxx形式で連続アクション対応）"""
        if not self._is_connected or not self._interrupt_client:
            print(f"BT Keyboard: Not connected (key={key_string})")
            return False

        # STRING:xxx 形式なら文字列送信
        if key_string.upper().startswith("STRING:"):
            return self.send_string(key_string[7:])

        # MACRO:xxx 形式なら連続アクション
        if key_string.upper().startswith("MACRO:"):
            return self.send_macro(key_string[6:])

        try:
            modifier, keycode = self._parse_key_string(key_string)

            # Key press
            report = bytes([0xA1, 0x01, modifier, 0x00, keycode, 0x00, 0x00, 0x00, 0x00, 0x00])
            self._interrupt_client.send(report)

            time.sleep(0.05)  # Small delay

            # Key release
            release = bytes([0xA1, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00])
            self._interrupt_client.send(release)

            print(f"BT Keyboard: Sent {key_string}")
            return True

        except Exception as e:
            print(f"BT Keyboard: Send error - {e}")
            self._is_connected = False
            return False

    def send_string(self, text):
        """文字列を順番に送信"""
        if not self._is_connected or not self._interrupt_client:
            print(f"BT Keyboard: Not connected (text={text})")
            return False

        try:
            for char in text:
                modifier, keycode = self._char_to_keycode(char)
                if keycode == 0:
                    continue  # 未対応文字はスキップ

                # Key press
                report = bytes([0xA1, 0x01, modifier, 0x00, keycode, 0x00, 0x00, 0x00, 0x00, 0x00])
                self._interrupt_client.send(report)

                time.sleep(0.03)

                # Key release
                release = bytes([0xA1, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00])
                self._interrupt_client.send(release)

                time.sleep(0.02)

            print(f"BT Keyboard: Sent string '{text}'")
            return True

        except Exception as e:
            print(f"BT Keyboard: Send string error - {e}")
            self._is_connected = False
            return False

    def send_macro(self, macro_string):
        """マクロ（複数キー操作）を順次実行

        形式: CTRL+C,WAIT:500,GUI+R,WAIT:200,STRING:notepad,ENTER
        - キー操作: CTRL+V, ALT+F4, GUI+R など
        - WAIT:ミリ秒: 指定時間待機
        - STRING:文字列: 文字列入力
        """
        if not self._is_connected or not self._interrupt_client:
            print(f"BT Keyboard: Not connected (macro)")
            return False

        try:
            actions = [a.strip() for a in macro_string.split(',')]

            for action in actions:
                if not action:
                    continue

                # WAIT:ミリ秒
                if action.upper().startswith("WAIT:"):
                    wait_ms = int(action[5:])
                    time.sleep(wait_ms / 1000.0)
                    continue

                # STRING:文字列
                if action.upper().startswith("STRING:"):
                    self.send_string(action[7:])
                    time.sleep(0.05)
                    continue

                # 通常のキー操作
                modifier, keycode = self._parse_key_string(action)
                if keycode == 0:
                    continue

                # Key press
                report = bytes([0xA1, 0x01, modifier, 0x00, keycode, 0x00, 0x00, 0x00, 0x00, 0x00])
                self._interrupt_client.send(report)
                time.sleep(0.05)

                # Key release
                release = bytes([0xA1, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00])
                self._interrupt_client.send(release)
                time.sleep(0.1)  # アクション間の待機

            print(f"BT Keyboard: Macro executed")
            return True

        except Exception as e:
            print(f"BT Keyboard: Macro error - {e}")
            self._is_connected = False
            return False

    def _char_to_keycode(self, char):
        """文字をキーコードに変換（Shiftが必要な場合は修飾子も返す）"""
        # 小文字
        if 'a' <= char <= 'z':
            return 0, HID_KEYCODES.get(char, 0)
        # 大文字（Shift必要）
        if 'A' <= char <= 'Z':
            return 0x02, HID_KEYCODES.get(char.lower(), 0)  # SHIFT
        # 数字
        if '0' <= char <= '9':
            return 0, HID_KEYCODES.get(char, 0)
        # スペース
        if char == ' ':
            return 0, 0x2C
        # 改行
        if char == '\n':
            return 0, 0x28  # ENTER
        # その他の記号（US配列）
        symbols = {
            '-': (0, 0x2D), '=': (0, 0x2E), '[': (0, 0x2F), ']': (0, 0x30),
            '\\': (0, 0x31), ';': (0, 0x33), "'": (0, 0x34), '`': (0, 0x35),
            ',': (0, 0x36), '.': (0, 0x37), '/': (0, 0x38),
            # Shift + 記号
            '!': (0x02, 0x1E), '@': (0x02, 0x1F), '#': (0x02, 0x20),
            '$': (0x02, 0x21), '%': (0x02, 0x22), '^': (0x02, 0x23),
            '&': (0x02, 0x24), '*': (0x02, 0x25), '(': (0x02, 0x26),
            ')': (0x02, 0x27), '_': (0x02, 0x2D), '+': (0x02, 0x2E),
            '{': (0x02, 0x2F), '}': (0x02, 0x30), '|': (0x02, 0x31),
            ':': (0x02, 0x33), '"': (0x02, 0x34), '~': (0x02, 0x35),
            '<': (0x02, 0x36), '>': (0x02, 0x37), '?': (0x02, 0x38),
        }
        return symbols.get(char, (0, 0))

    def _parse_key_string(self, key_string):
        parts = key_string.upper().split('+')
        modifier = 0
        keycode = 0

        for part in parts:
            part = part.strip()
            if part in MODIFIER_KEYS:
                modifier |= HID_KEYCODES.get(part, 0)
            else:
                keycode = HID_KEYCODES.get(part, 0) or HID_KEYCODES.get(part.lower(), 0)

        return modifier, keycode


# Singleton
_keyboard_service = None

def get_keyboard_service():
    global _keyboard_service
    if _keyboard_service is None:
        _keyboard_service = BluetoothKeyboardService()
    return _keyboard_service


if __name__ == "__main__":
    import sys
    target = sys.argv[1] if len(sys.argv) > 1 else None

    service = get_keyboard_service()
    service.start(target)

    print("BT Keyboard Service running. Press Ctrl+C to exit.")
    try:
        while True:
            time.sleep(1)
            if service.is_connected():
                print("Connected! Type 'test' to send test key")
    except KeyboardInterrupt:
        service.stop()
        print("\nStopped")
