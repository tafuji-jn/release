#!/bin/bash
cd "$(dirname "$0")"
./audio-switch.sh
source venv/bin/activate
python main.py
