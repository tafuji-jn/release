# -*- coding: utf-8 -*-
"""Bluetooth Manager - 接続デバイス管理"""

import os
import json
from pathlib import Path

_instance = None

class BTManager:
    """Bluetoothデバイス管理クラス"""

    def __init__(self):
        self._config_path = Path(__file__).parent.parent / ".bt_config.json"
        self._config = self._load_config()

    def _load_config(self) -> dict:
        """設定ファイルを読み込む"""
        if self._config_path.exists():
            try:
                with open(self._config_path, 'r') as f:
                    return json.load(f)
            except (json.JSONDecodeError, IOError):
                pass
        return {}

    def _save_config(self):
        """設定ファイルを保存"""
        try:
            with open(self._config_path, 'w') as f:
                json.dump(self._config, f, indent=2)
        except IOError as e:
            print(f"BT設定保存エラー: {e}")

    def get_last_device(self) -> str | None:
        """最後に接続したデバイスのアドレスを取得"""
        return self._config.get("last_device")

    def set_last_device(self, address: str):
        """最後に接続したデバイスのアドレスを保存"""
        self._config["last_device"] = address
        self._save_config()

    def clear_last_device(self):
        """保存されたデバイスアドレスをクリア"""
        if "last_device" in self._config:
            del self._config["last_device"]
            self._save_config()


def get_bt_manager() -> BTManager:
    """シングルトンインスタンスを取得"""
    global _instance
    if _instance is None:
        _instance = BTManager()
    return _instance
