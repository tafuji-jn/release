# ThinMonitorTool

Raspberry Pi用のモニターツール。Googleカレンダーとspotify連携機能付き。

## 起動方法

```bash
./start.sh
```

## 必要な設定ファイル

- `credentials.json` - Google Calendar API認証情報
- `spotify_credentials.json` - Spotify API認証情報

## 認証セットアップ

Raspberry Piはブラウザ認証が難しいため、**別端末（PC等）で認証を行い、トークンファイルをコピー**する方法を推奨します。

### 手順

#### 1. API認証情報の準備

**Google Calendar:**
1. [Google Cloud Console](https://console.cloud.google.com/apis/credentials) にアクセス
2. OAuth 2.0 クライアントIDを作成（デスクトップアプリ）
3. JSONをダウンロードし `credentials.json` として保存

**Spotify:**
1. [Spotify Developer Dashboard](https://developer.spotify.com/dashboard) にアクセス
2. アプリを作成
3. 以下の形式で `spotify_credentials.json` を作成:
```json
{
  "client_id": "あなたのClient ID",
  "client_secret": "あなたのClient Secret",
  "redirect_uri": "http://localhost:8888/callback"
}
```

#### 2. 別端末で認証を実行

PC等で認証セットアップスクリプトを実行します：

```bash
# 必要なライブラリをインストール
pip install google-auth-oauthlib google-api-python-client spotipy

# 認証を実行（ブラウザが開きます）
python auth_setup.py all
```

または個別に実行：
```bash
python auth_setup.py google   # Google Calendarのみ
python auth_setup.py spotify  # Spotifyのみ
```

#### 3. Raspberry Piにファイルをコピー

認証完了後、以下のファイルをRaspberry Piにコピー：

| ファイル | 内容 |
|----------|------|
| `credentials.json` | Google API設定 |
| `token.pickle` | Google認証トークン |
| `spotify_credentials.json` | Spotify API設定 |
| `.spotify_token_cache` | Spotify認証トークン |

```bash
# 例: scpでコピー
scp credentials.json token.pickle spotify_credentials.json .spotify_token_cache pi@raspberrypi:~/thinmonitortool/
```
