# -*- coding: utf-8 -*-
"""QRコード認証ダイアログ"""

from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QFrame, QApplication
)
from PyQt5.QtCore import Qt, QTimer, pyqtSignal, QThread
from PyQt5.QtGui import QPixmap, QImage
from io import BytesIO
import threading
import socket
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

try:
    import qrcode
    HAS_QRCODE = True
except ImportError:
    HAS_QRCODE = False


class CallbackHandler(BaseHTTPRequestHandler):
    """OAuth コールバック受信用ハンドラ"""

    callback_code = None
    callback_error = None

    def do_GET(self):
        """GETリクエスト処理"""
        parsed = urlparse(self.path)
        params = parse_qs(parsed.query)

        if 'code' in params:
            CallbackHandler.callback_code = params['code'][0]
            self.send_response(200)
            self.send_header('Content-type', 'text/html; charset=utf-8')
            self.end_headers()
            html = '''
            <html><head><meta charset="utf-8"></head>
            <body style="background:#1e1e1e;color:#fff;font-family:sans-serif;text-align:center;padding-top:100px;">
            <h1 style="color:#4caf50;">✓ 認証成功</h1>
            <p>このページを閉じてアプリに戻ってください</p>
            </body></html>
            '''
            self.wfile.write(html.encode('utf-8'))
        elif 'error' in params:
            CallbackHandler.callback_error = params.get('error_description', params['error'])[0]
            self.send_response(200)
            self.send_header('Content-type', 'text/html; charset=utf-8')
            self.end_headers()
            html = f'''
            <html><head><meta charset="utf-8"></head>
            <body style="background:#1e1e1e;color:#fff;font-family:sans-serif;text-align:center;padding-top:100px;">
            <h1 style="color:#ff6b6b;">✗ 認証エラー</h1>
            <p>{CallbackHandler.callback_error}</p>
            </body></html>
            '''
            self.wfile.write(html.encode('utf-8'))
        else:
            self.send_response(404)
            self.end_headers()

    def log_message(self, format, *args):
        """ログ出力を抑制"""
        pass


class QRAuthDialog(QDialog):
    """QRコードを使用したOAuth認証ダイアログ"""

    authCompleted = pyqtSignal(str)  # 認証コード入力完了
    authCancelled = pyqtSignal()     # キャンセル
    _callbackReceived = pyqtSignal(str)  # 内部: コールバック受信

    # 認証モード
    MODE_CODE = 'code'       # 認証コード入力（Google用）
    MODE_URL = 'url'         # リダイレクトURL入力
    MODE_CALLBACK = 'callback'  # コールバック自動受信（Spotify用）

    def __init__(self, parent=None, service_name="サービス", mode=MODE_CODE, callback_port=8888):
        super().__init__(parent)
        self.service_name = service_name
        self._auth_url = None
        self._mode = mode
        self._callback_port = callback_port
        self._http_server = None
        self._server_thread = None
        self._poll_timer = None
        self.setup_ui()

        # コールバック受信シグナル接続
        self._callbackReceived.connect(self._on_callback_received)

    def setup_ui(self):
        """UIの初期化"""
        self.setWindowTitle(f"{self.service_name} 認証")
        self.setFixedSize(360, 480)
        self.setWindowFlags(Qt.Dialog | Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, False)

        self.setStyleSheet("""
            QDialog {
                background-color: #1e1e1e;
                border: 2px solid #444;
                border-radius: 12px;
            }
            #titleLabel {
                color: #ffffff;
                font-size: 16px;
                font-weight: bold;
                padding: 5px;
            }
            #instructionLabel {
                color: #cccccc;
                font-size: 12px;
                padding: 5px;
                line-height: 1.4;
            }
            #qrFrame {
                background-color: #ffffff;
                border-radius: 10px;
                padding: 10px;
            }
            #codeInput {
                background-color: #2a2a2a;
                color: #ffffff;
                border: 2px solid #444;
                border-radius: 8px;
                padding: 12px;
                font-size: 18px;
                font-family: monospace;
            }
            #codeInput:focus {
                border-color: #e94560;
            }
            #submitBtn {
                background-color: #e94560;
                color: #ffffff;
                border: none;
                border-radius: 6px;
                padding: 8px 16px;
                font-size: 14px;
                font-weight: bold;
            }
            #submitBtn:hover {
                background-color: #d63850;
            }
            #submitBtn:pressed {
                background-color: #c42a40;
            }
            #submitBtn:disabled {
                background-color: #555;
                color: #888;
            }
            #cancelBtn {
                background-color: #444;
                color: #ffffff;
                border: none;
                border-radius: 6px;
                padding: 8px 16px;
                font-size: 14px;
            }
            #cancelBtn:hover {
                background-color: #555;
            }
            #statusLabel {
                color: #888;
                font-size: 12px;
                padding: 5px;
            }
            #errorLabel {
                color: #ff6b6b;
                font-size: 12px;
                padding: 5px;
            }
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(15, 10, 15, 10)
        layout.setSpacing(8)

        # タイトル
        title = QLabel(f"{self.service_name} 認証")
        title.setObjectName("titleLabel")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        # 説明文（モードによって変更）
        if self._mode == self.MODE_CALLBACK:
            instruction_text = (
                "1. スマートフォンで下のQRコードをスキャン\n"
                "2. ブラウザでログインして許可\n"
                "3. 自動的に認証が完了します"
            )
        elif self._mode == self.MODE_URL:
            instruction_text = (
                "1. スマートフォンで下のQRコードをスキャン\n"
                "2. ブラウザでログインして許可\n"
                "3. リダイレクトされたURLをコピーして入力"
            )
        else:
            instruction_text = (
                "1. スマートフォンで下のQRコードをスキャン\n"
                "2. ブラウザでログインして許可\n"
                "3. 表示された認証コードを入力"
            )

        self._instruction_label = QLabel(instruction_text)
        self._instruction_label.setObjectName("instructionLabel")
        self._instruction_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self._instruction_label)

        # QRコード表示エリア
        qr_frame = QFrame()
        qr_frame.setObjectName("qrFrame")
        qr_frame.setFixedSize(200, 200)
        qr_layout = QVBoxLayout(qr_frame)
        qr_layout.setContentsMargins(5, 5, 5, 5)

        self.qr_label = QLabel()
        self.qr_label.setAlignment(Qt.AlignCenter)
        self.qr_label.setFixedSize(190, 190)
        self.qr_label.setText("QRコード生成中...")
        self.qr_label.setStyleSheet("color: #666; font-size: 14px;")
        qr_layout.addWidget(self.qr_label)

        # QRフレームを中央配置
        qr_container = QHBoxLayout()
        qr_container.addStretch()
        qr_container.addWidget(qr_frame)
        qr_container.addStretch()
        layout.addLayout(qr_container)

        # 認証コード/URL入力欄（モードによって変更）
        # MODE_CALLBACKでは入力欄を非表示
        self._input_container = QFrame()
        input_layout = QVBoxLayout(self._input_container)
        input_layout.setContentsMargins(0, 0, 0, 0)

        if self._mode == self.MODE_URL:
            code_label = QLabel("リダイレクトURL:")
            placeholder = "http://localhost:8888/callback?code=..."
        else:
            code_label = QLabel("認証コード:")
            placeholder = "認証コードを入力..."

        code_label.setStyleSheet("color: #ccc; font-size: 14px;")
        input_layout.addWidget(code_label)

        self.code_input = QLineEdit()
        self.code_input.setObjectName("codeInput")
        self.code_input.setPlaceholderText(placeholder)
        self.code_input.returnPressed.connect(self._on_submit)
        input_layout.addWidget(self.code_input)

        if self._mode == self.MODE_CALLBACK:
            self._input_container.hide()

        layout.addWidget(self._input_container)

        # ステータス/エラー表示
        self.status_label = QLabel("")
        self.status_label.setObjectName("statusLabel")
        self.status_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.status_label)

        # ボタンエリア
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(15)

        self.cancel_btn = QPushButton("キャンセル")
        self.cancel_btn.setObjectName("cancelBtn")
        self.cancel_btn.clicked.connect(self._on_cancel)
        btn_layout.addWidget(self.cancel_btn)

        self.submit_btn = QPushButton("認証")
        self.submit_btn.setObjectName("submitBtn")
        self.submit_btn.setEnabled(False)
        self.submit_btn.clicked.connect(self._on_submit)
        if self._mode != self.MODE_CALLBACK:
            btn_layout.addWidget(self.submit_btn)

        layout.addLayout(btn_layout)

        # 入力欄の変更を監視
        self.code_input.textChanged.connect(self._on_code_changed)

    def set_instruction(self, text):
        """説明文を変更"""
        self._instruction_label.setText(text)

    def set_auth_url(self, url):
        """認証URLを設定してQRコードを生成"""
        self._auth_url = url

        # MODE_CALLBACKの場合、コールバックサーバーを起動
        if self._mode == self.MODE_CALLBACK:
            self._start_callback_server()

        if not HAS_QRCODE:
            self.qr_label.setText("qrcodeライブラリが\nインストールされていません\n\npip install qrcode[pil]")
            self._show_url_fallback(url)
            return

        try:
            # QRコード生成
            qr = qrcode.QRCode(
                version=1,
                error_correction=qrcode.constants.ERROR_CORRECT_L,
                box_size=8,
                border=2,
            )
            qr.add_data(url)
            qr.make(fit=True)

            img = qr.make_image(fill_color="black", back_color="white")

            # PIL ImageをQPixmapに変換
            buffer = BytesIO()
            img.save(buffer, format='PNG')
            buffer.seek(0)

            pixmap = QPixmap()
            pixmap.loadFromData(buffer.getvalue())
            scaled = pixmap.scaled(190, 190, Qt.KeepAspectRatio, Qt.SmoothTransformation)

            self.qr_label.setPixmap(scaled)

            if self._mode == self.MODE_CALLBACK:
                self.status_label.setText("認証待機中... スマホでQRをスキャン")
            else:
                self.status_label.setText("QRコードをスキャンしてください")
            self.status_label.setObjectName("statusLabel")
            self.status_label.setStyle(self.status_label.style())

        except Exception as e:
            self.qr_label.setText(f"QRコード生成エラー:\n{str(e)}")
            self._show_url_fallback(url)

    def _show_url_fallback(self, url):
        """QRコードが使えない場合のフォールバック表示"""
        # URLを短縮表示
        short_url = url[:50] + "..." if len(url) > 50 else url
        self.status_label.setText(f"URL: {short_url}")

    def _on_code_changed(self, text):
        """認証コード入力時"""
        self.submit_btn.setEnabled(len(text.strip()) > 0)

    def _on_submit(self):
        """認証ボタンクリック"""
        code = self.code_input.text().strip()
        if code:
            self.status_label.setText("認証中...")
            self.submit_btn.setEnabled(False)
            self.code_input.setEnabled(False)
            self.authCompleted.emit(code)

    def _on_cancel(self):
        """キャンセルボタンクリック"""
        self.authCancelled.emit()
        self.reject()

    def show_error(self, message):
        """エラーメッセージを表示"""
        self.status_label.setText(message)
        self.status_label.setObjectName("errorLabel")
        self.status_label.setStyle(self.status_label.style())
        self.submit_btn.setEnabled(True)
        self.code_input.setEnabled(True)
        self.code_input.clear()
        self.code_input.setFocus()

    def show_success(self, message="認証成功！"):
        """成功メッセージを表示して閉じる"""
        self._stop_callback_server()
        self.status_label.setText(message)
        self.status_label.setStyleSheet("color: #4caf50; font-size: 14px; font-weight: bold;")
        QTimer.singleShot(1500, self.accept)

    def get_auth_code(self):
        """入力された認証コードを取得"""
        return self.code_input.text().strip()

    def _start_callback_server(self):
        """コールバック受信用HTTPサーバーを起動"""
        CallbackHandler.callback_code = None
        CallbackHandler.callback_error = None

        def run_server():
            try:
                self._http_server = HTTPServer(('0.0.0.0', self._callback_port), CallbackHandler)
                self._http_server.timeout = 1
                while self._http_server:
                    self._http_server.handle_request()
            except Exception as e:
                print(f"Callback server error: {e}")

        self._server_thread = threading.Thread(target=run_server, daemon=True)
        self._server_thread.start()

        # コールバック受信をポーリング
        self._poll_timer = QTimer(self)
        self._poll_timer.timeout.connect(self._poll_callback)
        self._poll_timer.start(500)

        print(f"Callback server started on port {self._callback_port}")

    def _stop_callback_server(self):
        """コールバック受信用HTTPサーバーを停止"""
        if self._poll_timer:
            self._poll_timer.stop()
            self._poll_timer = None

        if self._http_server:
            try:
                self._http_server.shutdown()
            except:
                pass
            self._http_server = None

        self._server_thread = None

    def _poll_callback(self):
        """コールバック受信をチェック"""
        if CallbackHandler.callback_code:
            code = CallbackHandler.callback_code
            CallbackHandler.callback_code = None
            self._callbackReceived.emit(code)
        elif CallbackHandler.callback_error:
            error = CallbackHandler.callback_error
            CallbackHandler.callback_error = None
            self.show_error(f"認証エラー: {error}")

    def _on_callback_received(self, code):
        """コールバック受信時の処理"""
        self._stop_callback_server()
        self.status_label.setText("認証コード受信... 処理中")
        self.authCompleted.emit(code)

    def reject(self):
        """ダイアログを閉じる時にサーバーを停止"""
        self._stop_callback_server()
        super().reject()

    def accept(self):
        """ダイアログを閉じる時にサーバーを停止"""
        self._stop_callback_server()
        super().accept()


class AuthStatusDialog(QDialog):
    """認証ステータス表示用のシンプルなダイアログ"""

    def __init__(self, parent=None, message="処理中..."):
        super().__init__(parent)
        self.setWindowTitle("認証")
        self.setFixedSize(300, 100)
        self.setWindowFlags(Qt.Dialog | Qt.FramelessWindowHint)

        self.setStyleSheet("""
            QDialog {
                background-color: #1e1e1e;
                border: 2px solid #444;
                border-radius: 8px;
            }
            QLabel {
                color: #ffffff;
                font-size: 14px;
            }
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)

        self.message_label = QLabel(message)
        self.message_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.message_label)

    def set_message(self, message):
        """メッセージを更新"""
        self.message_label.setText(message)
        QApplication.processEvents()
