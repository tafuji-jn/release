#!/bin/bash
# Bluetooth接続時はBluetooth、それ以外はHDMIに自動切り替え

HDMI_SINK="alsa_output.platform-fef00700.hdmi.hdmi-stereo.2"

# Bluetoothオーディオシンクを検索
BT_SINK=$(pactl list sinks short | grep -i bluez | awk '{print $2}' | head -1)

if [ -n "$BT_SINK" ]; then
    pactl set-default-sink "$BT_SINK"
    echo "Bluetooth: $BT_SINK"
else
    pactl set-default-sink "$HDMI_SINK"
    echo "HDMI"
fi
