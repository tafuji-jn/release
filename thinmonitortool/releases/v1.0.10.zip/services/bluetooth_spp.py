# -*- coding: utf-8 -*-
"""
Bluetooth SPP (Serial Port Profile) サーバー
Windows側アプリからdeck_config.jsonの設定を送受信する
"""

import json
import socket
import subprocess
import threading
import os
from pathlib import Path

# Bluetooth定数
RFCOMM_CHANNEL = 4  # SPP用チャンネル


def get_bluetooth_address():
    """Bluetoothアダプタのアドレスを取得"""
    try:
        result = subprocess.run(
            ['hciconfig', 'hci0'],
            capture_output=True, text=True, timeout=5
        )
        for line in result.stdout.split('\n'):
            if 'BD Address:' in line:
                # "BD Address: E4:5F:01:1E:3B:9D  ACL MTU: ..." から抽出
                parts = line.split()
                idx = parts.index('Address:') + 1
                return parts[idx]
    except Exception as e:
        print(f"Bluetooth SPP: アドレス取得エラー - {e}")
    return None


def cleanup_spp_services():
    """既存のSPPサービスを全て削除"""
    try:
        result = subprocess.run(
            ['sudo', 'sdptool', 'browse', 'local'],
            capture_output=True, text=True, timeout=10
        )
        # Serial PortサービスのRecHandleを全て抽出して削除
        # 形式: Service Name: Serial Port の後に Service RecHandle: 0x... が来る
        import re
        handles_to_delete = []
        is_serial_port = False
        for line in result.stdout.split('\n'):
            if 'Service Name: Serial Port' in line:
                is_serial_port = True
            elif 'Service Name:' in line:
                is_serial_port = False
            elif 'Service RecHandle:' in line and is_serial_port:
                match = re.search(r'0x[0-9a-fA-F]+', line)
                if match:
                    handles_to_delete.append(match.group(0))
                is_serial_port = False

        # 収集したハンドルを全て削除
        for handle in handles_to_delete:
            subprocess.run(
                ['sudo', 'sdptool', 'del', handle],
                capture_output=True, timeout=5
            )
    except Exception as e:
        print(f"Bluetooth SPP: SDPクリーンアップエラー - {e}")


def register_spp_service(channel):
    """SDPにSPPサービスを登録（重複防止）"""
    try:
        # 既存のSPPサービスを削除
        cleanup_spp_services()

        # 新規登録
        subprocess.run(
            ['sudo', 'sdptool', 'add', f'--channel={channel}', 'SP'],
            capture_output=True, timeout=5
        )
        print(f"Bluetooth SPP: SDPサービス登録完了 (channel={channel})")
        return True
    except Exception as e:
        print(f"Bluetooth SPP: SDP登録エラー - {e}")
        return False

# 設定ファイルパス
CONFIG_PATH = Path(__file__).parent.parent / "deck_config.json"


class BluetoothSPPServer:
    """Bluetooth SPPサーバー（設定送受信用）"""

    def __init__(self, on_config_updated=None):
        """
        Args:
            on_config_updated: 設定更新時のコールバック関数
        """
        self._server_sock = None
        self._client_sock = None
        self._running = False
        self._thread = None
        self._on_config_updated = on_config_updated

    def start(self):
        """SPPサーバーを開始"""
        if self._running:
            return

        self._running = True
        self._thread = threading.Thread(target=self._server_loop, daemon=True)
        self._thread.start()
        print("Bluetooth SPP: サーバー開始")

    def stop(self):
        """SPPサーバーを停止"""
        self._running = False
        if self._client_sock:
            try:
                self._client_sock.close()
            except:
                pass
        if self._server_sock:
            try:
                self._server_sock.close()
            except:
                pass
        print("Bluetooth SPP: サーバー停止")

    def _server_loop(self):
        """サーバーメインループ（自動再接続対応）"""
        import time
        retry_delay = 5  # 再試行間隔（秒）

        while self._running:
            try:
                # Bluetoothアダプタのアドレスを取得
                bt_addr = get_bluetooth_address()
                if not bt_addr:
                    print("Bluetooth SPP: アダプタが見つかりません、再試行します...")
                    time.sleep(retry_delay)
                    continue

                # RFCOMMソケットを作成
                self._server_sock = socket.socket(
                    socket.AF_BLUETOOTH, socket.SOCK_STREAM, socket.BTPROTO_RFCOMM
                )
                self._server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

                # Bluetoothアダプタでリッスン
                self._server_sock.bind((bt_addr, RFCOMM_CHANNEL))
                self._server_sock.listen(1)
                self._server_sock.settimeout(1.0)  # タイムアウト設定

                # SDPサービスを再登録
                register_spp_service(RFCOMM_CHANNEL)

                print(f"Bluetooth SPP: {bt_addr} チャンネル {RFCOMM_CHANNEL} で待機中...")

                while self._running:
                    try:
                        client_sock, client_info = self._server_sock.accept()
                        print(f"Bluetooth SPP: 接続 - {client_info[0]}")
                        self._handle_client(client_sock)
                    except socket.timeout:
                        continue
                    except OSError as e:
                        # ソケットエラー時は外側ループでリトライ
                        if self._running:
                            print(f"Bluetooth SPP: ソケットエラー - {e}、再初期化します...")
                        break
                    except Exception as e:
                        if self._running:
                            print(f"Bluetooth SPP: 接続エラー - {e}")

            except Exception as e:
                if self._running:
                    print(f"Bluetooth SPP: サーバーエラー - {e}、{retry_delay}秒後に再試行...")
            finally:
                if self._server_sock:
                    try:
                        self._server_sock.close()
                    except:
                        pass
                    self._server_sock = None

            # 再試行前に少し待機
            if self._running:
                time.sleep(retry_delay)

    def _handle_client(self, client_sock):
        """クライアント接続を処理"""
        self._client_sock = client_sock
        client_sock.settimeout(30.0)
        buffer = ""

        try:
            while self._running:
                try:
                    data = client_sock.recv(4096)
                    if not data:
                        break

                    buffer += data.decode('utf-8')

                    # 改行区切りでコマンドを処理
                    while '\n' in buffer:
                        line, buffer = buffer.split('\n', 1)
                        if line.strip():
                            response = self._process_command(line.strip())
                            client_sock.send((response + '\n').encode('utf-8'))

                except socket.timeout:
                    continue
                except Exception as e:
                    print(f"Bluetooth SPP: 受信エラー - {e}")
                    break

        finally:
            client_sock.close()
            self._client_sock = None
            print("Bluetooth SPP: 切断")

    def _process_command(self, cmd_str):
        """コマンドを処理して応答を返す"""
        try:
            # UTF-8 BOMを除去
            cmd_str = cmd_str.lstrip('\ufeff')
            cmd = json.loads(cmd_str)
            action = cmd.get('cmd', '')

            if action == 'get_config':
                return self._cmd_get_config()
            elif action == 'set_config':
                return self._cmd_set_config(cmd.get('config', {}))
            elif action == 'reload':
                return self._cmd_reload()
            elif action == 'ping':
                return json.dumps({"status": "ok", "message": "pong"})
            else:
                return json.dumps({"status": "error", "message": f"Unknown command: {action}"})

        except json.JSONDecodeError as e:
            return json.dumps({"status": "error", "message": f"Invalid JSON: {e}"})
        except Exception as e:
            return json.dumps({"status": "error", "message": str(e)})

    def _cmd_get_config(self):
        """設定を取得"""
        try:
            if CONFIG_PATH.exists():
                with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                return json.dumps({"status": "ok", "config": config})
            else:
                return json.dumps({"status": "error", "message": "Config file not found"})
        except Exception as e:
            return json.dumps({"status": "error", "message": str(e)})

    def _cmd_set_config(self, config):
        """設定を保存"""
        try:
            # バリデーション
            if 'pages' not in config:
                return json.dumps({"status": "error", "message": "Missing 'pages' field"})

            # 保存
            with open(CONFIG_PATH, 'w', encoding='utf-8') as f:
                json.dump(config, f, ensure_ascii=False, indent=2)

            print(f"Bluetooth SPP: 設定を保存しました")
            return json.dumps({"status": "ok"})

        except Exception as e:
            return json.dumps({"status": "error", "message": str(e)})

    def _cmd_reload(self):
        """設定再読み込みをトリガー"""
        try:
            if self._on_config_updated:
                self._on_config_updated()
            return json.dumps({"status": "ok"})
        except Exception as e:
            return json.dumps({"status": "error", "message": str(e)})


# シングルトンインスタンス
_spp_server = None


def get_spp_server(on_config_updated=None):
    """SPPサーバーのシングルトンを取得"""
    global _spp_server
    if _spp_server is None:
        _spp_server = BluetoothSPPServer(on_config_updated)
    return _spp_server
