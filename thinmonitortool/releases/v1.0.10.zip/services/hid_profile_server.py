#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""HID Profile Server - BlueZ D-Bus Profile for Bluetooth Keyboard"""

import dbus
import dbus.service
import dbus.mainloop.glib
from gi.repository import GLib
import os
import time

# Global variable to store the connection file descriptor
connection_fd = -1

class HIDProfile(dbus.service.Object):
    @dbus.service.method('org.bluez.Profile1', in_signature='', out_signature='')
    def Release(self):
        global connection_fd
        print('HID Profile: Released')
        connection_fd = -1

    @dbus.service.method('org.bluez.Profile1', in_signature='oha{sv}', out_signature='')
    def NewConnection(self, path, fd, properties):
        global connection_fd
        connection_fd = fd.take()
        print(f'HID Profile: NewConnection! fd={connection_fd}, path={path}')
        # Write fd to file for other processes to use
        with open('/tmp/hid_connection_fd', 'w') as f:
            f.write(str(connection_fd))

    @dbus.service.method('org.bluez.Profile1', in_signature='o', out_signature='')
    def RequestDisconnection(self, path):
        global connection_fd
        print(f'HID Profile: Disconnection requested for {path}')
        connection_fd = -1
        try:
            os.remove('/tmp/hid_connection_fd')
        except:
            pass


def main():
    dbus.mainloop.glib.DBusGMainLoop(set_as_default=True)

    bus = dbus.SystemBus()
    profile = HIDProfile(bus, '/org/bluez/hid')

    manager = dbus.Interface(
        bus.get_object('org.bluez', '/org/bluez'),
        'org.bluez.ProfileManager1'
    )

    # Unregister if exists
    try:
        manager.UnregisterProfile('/org/bluez/hid')
        print('HID Profile: Unregistered old profile')
    except:
        pass

    # SDP Record for HID Keyboard
    SDP = '''<?xml version="1.0" encoding="UTF-8"?>
<record>
<attribute id="0x0001"><sequence><uuid value="0x1124"/></sequence></attribute>
<attribute id="0x0004"><sequence><sequence><uuid value="0x0100"/><uint16 value="0x0011"/></sequence><sequence><uuid value="0x0011"/></sequence></sequence></attribute>
<attribute id="0x0005"><sequence><uuid value="0x1002"/></sequence></attribute>
<attribute id="0x0009"><sequence><sequence><uuid value="0x1124"/><uint16 value="0x0100"/></sequence></sequence></attribute>
<attribute id="0x000d"><sequence><sequence><sequence><uuid value="0x0100"/><uint16 value="0x0013"/></sequence><sequence><uuid value="0x0011"/></sequence></sequence></sequence></attribute>
<attribute id="0x0100"><text value="Pi Keyboard"/></attribute>
<attribute id="0x0101"><text value="Keyboard"/></attribute>
<attribute id="0x0200"><uint16 value="0x0100"/></attribute>
<attribute id="0x0201"><uint16 value="0x0111"/></attribute>
<attribute id="0x0202"><uint8 value="0x40"/></attribute>
<attribute id="0x0203"><uint8 value="0x00"/></attribute>
<attribute id="0x0204"><boolean value="true"/></attribute>
<attribute id="0x0205"><boolean value="true"/></attribute>
<attribute id="0x0206"><sequence><sequence><uint8 value="0x22"/><text encoding="hex" value="05010906a101850175019508050719e029e715002501810295017508810395057501050819012905910295017503910395067508150026ff000507190029ff8100c0"/></sequence></sequence></attribute>
</record>'''

    # Register profile
    opts = {
        'AutoConnect': dbus.Boolean(True),
        'Role': dbus.String('server'),
        'ServiceRecord': dbus.String(SDP),
    }

    try:
        manager.RegisterProfile('/org/bluez/hid', '00001124-0000-1000-8000-00805f9b34fb', opts)
        print('HID Profile: Registered successfully')
    except Exception as e:
        print(f'HID Profile: Registration error - {e}')
        return

    print('HID Profile Server running. Waiting for connections...')

    loop = GLib.MainLoop()
    try:
        loop.run()
    except KeyboardInterrupt:
        print('\nHID Profile: Shutting down')


if __name__ == '__main__':
    main()
