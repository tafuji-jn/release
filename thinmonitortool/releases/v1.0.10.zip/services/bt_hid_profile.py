# -*- coding: utf-8 -*-
"""
Bluetooth HID Profile Registration
BlueZ D-Bus APIを使用してHIDプロファイルを登録
"""

import dbus
import dbus.service
import dbus.mainloop.glib
from gi.repository import GLib
import threading

# HID SDP Record (Keyboard)
SDP_RECORD = """
<?xml version="1.0" encoding="UTF-8" ?>
<record>
    <attribute id="0x0001">
        <sequence>
            <uuid value="0x1124"/>
        </sequence>
    </attribute>
    <attribute id="0x0004">
        <sequence>
            <sequence>
                <uuid value="0x0100"/>
                <uint16 value="0x0011"/>
            </sequence>
            <sequence>
                <uuid value="0x0011"/>
            </sequence>
        </sequence>
    </attribute>
    <attribute id="0x0005">
        <sequence>
            <uuid value="0x1002"/>
        </sequence>
    </attribute>
    <attribute id="0x0006">
        <sequence>
            <uint16 value="0x656e"/>
            <uint16 value="0x006a"/>
            <uint16 value="0x0100"/>
        </sequence>
    </attribute>
    <attribute id="0x0009">
        <sequence>
            <sequence>
                <uuid value="0x1124"/>
                <uint16 value="0x0100"/>
            </sequence>
        </sequence>
    </attribute>
    <attribute id="0x000d">
        <sequence>
            <sequence>
                <sequence>
                    <uuid value="0x0100"/>
                    <uint16 value="0x0013"/>
                </sequence>
                <sequence>
                    <uuid value="0x0011"/>
                </sequence>
            </sequence>
        </sequence>
    </attribute>
    <attribute id="0x0100">
        <text value="ThinMonitor Keyboard"/>
    </attribute>
    <attribute id="0x0101">
        <text value="Bluetooth HID Keyboard"/>
    </attribute>
    <attribute id="0x0102">
        <text value="ThinMonitorPalet"/>
    </attribute>
    <attribute id="0x0200">
        <uint16 value="0x0100"/>
    </attribute>
    <attribute id="0x0201">
        <uint16 value="0x0111"/>
    </attribute>
    <attribute id="0x0202">
        <uint8 value="0x40"/>
    </attribute>
    <attribute id="0x0203">
        <uint8 value="0x00"/>
    </attribute>
    <attribute id="0x0204">
        <boolean value="true"/>
    </attribute>
    <attribute id="0x0205">
        <boolean value="true"/>
    </attribute>
    <attribute id="0x0206">
        <sequence>
            <sequence>
                <uint8 value="0x22"/>
                <text encoding="hex" value="05010906a101850175019508050719e029e715002501810295017508810395057501050819012905910295017503910395067508150026ff000507190029ff8100c0"/>
            </sequence>
        </sequence>
    </attribute>
    <attribute id="0x0207">
        <sequence>
            <sequence>
                <uint16 value="0x0409"/>
                <uint16 value="0x0100"/>
            </sequence>
        </sequence>
    </attribute>
    <attribute id="0x020b">
        <uint16 value="0x0100"/>
    </attribute>
    <attribute id="0x020c">
        <uint16 value="0x0c80"/>
    </attribute>
    <attribute id="0x020d">
        <boolean value="false"/>
    </attribute>
    <attribute id="0x020e">
        <boolean value="true"/>
    </attribute>
    <attribute id="0x020f">
        <uint16 value="0x0640"/>
    </attribute>
    <attribute id="0x0210">
        <uint16 value="0x0320"/>
    </attribute>
</record>
"""

HID_UUID = "00001124-0000-1000-8000-00805f9b34fb"
PROFILE_PATH = "/org/bluez/hid_profile"


class HIDProfile(dbus.service.Object):
    """BlueZ HID Profile"""

    @dbus.service.method("org.bluez.Profile1", in_signature="", out_signature="")
    def Release(self):
        print("HID Profile: Released")

    @dbus.service.method("org.bluez.Profile1", in_signature="oha{sv}", out_signature="")
    def NewConnection(self, path, fd, properties):
        print(f"HID Profile: New connection from {path}")
        # ファイルディスクリプタを保存して後で使用
        self.fd = fd.take()

    @dbus.service.method("org.bluez.Profile1", in_signature="o", out_signature="")
    def RequestDisconnection(self, path):
        print(f"HID Profile: Disconnect request from {path}")


def register_hid_profile():
    """HIDプロファイルをBlueZに登録"""
    dbus.mainloop.glib.DBusGMainLoop(set_as_default=True)

    bus = dbus.SystemBus()

    # Profile Managerを取得
    manager = dbus.Interface(
        bus.get_object("org.bluez", "/org/bluez"),
        "org.bluez.ProfileManager1"
    )

    # HIDプロファイルオブジェクトを作成
    profile = HIDProfile(bus, PROFILE_PATH)

    # プロファイルオプション
    opts = {
        "Name": "ThinMonitor Keyboard",
        "Role": "server",
        "RequireAuthentication": False,
        "RequireAuthorization": False,
        "ServiceRecord": SDP_RECORD,
    }

    try:
        manager.RegisterProfile(PROFILE_PATH, HID_UUID, opts)
        print("HID Profile: 登録完了")
        return True
    except dbus.exceptions.DBusException as e:
        print(f"HID Profile: 登録エラー - {e}")
        return False


def start_profile_service():
    """プロファイルサービスを別スレッドで開始"""
    def run():
        if register_hid_profile():
            loop = GLib.MainLoop()
            loop.run()

    thread = threading.Thread(target=run, daemon=True)
    thread.start()
    return thread


if __name__ == "__main__":
    if register_hid_profile():
        print("HID Profile: サービス開始")
        loop = GLib.MainLoop()
        try:
            loop.run()
        except KeyboardInterrupt:
            print("\nHID Profile: 終了")
