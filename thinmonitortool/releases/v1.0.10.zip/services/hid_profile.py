#!/usr/bin/env python3
"""D-Bus Profile APIを使ったHIDプロファイル実装（自動再接続対応）"""

import dbus
import dbus.service
import dbus.mainloop.glib
from gi.repository import GLib
import socket
import os
import time
import threading

# HIDレポートディスクリプタ（キーボード）
HID_REPORT_DESCRIPTOR = bytes([
    0x05, 0x01,  # Usage Page (Generic Desktop)
    0x09, 0x06,  # Usage (Keyboard)
    0xA1, 0x01,  # Collection (Application)
    0x85, 0x01,  # Report ID (1)
    0x05, 0x07,  # Usage Page (Key Codes)
    0x19, 0xE0,  # Usage Minimum (224)
    0x29, 0xE7,  # Usage Maximum (231)
    0x15, 0x00,  # Logical Minimum (0)
    0x25, 0x01,  # Logical Maximum (1)
    0x75, 0x01,  # Report Size (1)
    0x95, 0x08,  # Report Count (8)
    0x81, 0x02,  # Input (Data, Variable, Absolute)
    0x95, 0x01,  # Report Count (1)
    0x75, 0x08,  # Report Size (8)
    0x81, 0x01,  # Input (Constant)
    0x95, 0x06,  # Report Count (6)
    0x75, 0x08,  # Report Size (8)
    0x15, 0x00,  # Logical Minimum (0)
    0x25, 0xFF,  # Logical Maximum (255)
    0x05, 0x07,  # Usage Page (Key Codes)
    0x19, 0x00,  # Usage Minimum (0)
    0x29, 0xFF,  # Usage Maximum (255)
    0x81, 0x00,  # Input (Data, Array)
    0xC0         # End Collection
])

SDP_RECORD = '''<?xml version="1.0" encoding="UTF-8" ?>
<record>
  <attribute id="0x0001"><sequence><uuid value="0x1124"/></sequence></attribute>
  <attribute id="0x0004">
    <sequence>
      <sequence><uuid value="0x0100"/><uint16 value="0x0011"/></sequence>
      <sequence><uuid value="0x0011"/></sequence>
    </sequence>
  </attribute>
  <attribute id="0x0005"><sequence><uuid value="0x1002"/></sequence></attribute>
  <attribute id="0x0006">
    <sequence>
      <uint16 value="0x656e"/><uint16 value="0x006a"/><uint16 value="0x0100"/>
    </sequence>
  </attribute>
  <attribute id="0x0009">
    <sequence><sequence><uuid value="0x1124"/><uint16 value="0x0100"/></sequence></sequence>
  </attribute>
  <attribute id="0x000d">
    <sequence>
      <sequence>
        <sequence><uuid value="0x0100"/><uint16 value="0x0013"/></sequence>
        <sequence><uuid value="0x0011"/></sequence>
      </sequence>
    </sequence>
  </attribute>
  <attribute id="0x0100"><text value="Pi Keyboard"/></attribute>
  <attribute id="0x0101"><text value="Bluetooth Keyboard"/></attribute>
  <attribute id="0x0102"><text value="Raspberry Pi"/></attribute>
  <attribute id="0x0200"><uint16 value="0x0100"/></attribute>
  <attribute id="0x0201"><uint16 value="0x0111"/></attribute>
  <attribute id="0x0202"><uint8 value="0x40"/></attribute>
  <attribute id="0x0203"><uint8 value="0x00"/></attribute>
  <attribute id="0x0204"><boolean value="true"/></attribute>
  <attribute id="0x0205"><boolean value="true"/></attribute>
  <attribute id="0x0206">
    <sequence>
      <sequence>
        <uint8 value="0x22"/>
        <text encoding="hex" value="''' + HID_REPORT_DESCRIPTOR.hex() + '''"/>
      </sequence>
    </sequence>
  </attribute>
  <attribute id="0x0207">
    <sequence><sequence><uint16 value="0x0409"/><uint16 value="0x0100"/></sequence></sequence>
  </attribute>
  <attribute id="0x020b"><uint16 value="0x0100"/></attribute>
  <attribute id="0x020c"><uint16 value="0x0c80"/></attribute>
  <attribute id="0x020d"><boolean value="false"/></attribute>
  <attribute id="0x020e"><boolean value="true"/></attribute>
  <attribute id="0x020f"><uint16 value="0x0640"/></attribute>
  <attribute id="0x0210"><uint16 value="0x0020"/></attribute>
</record>'''


class HIDProfile(dbus.service.Object):
    def __init__(self, bus, path):
        super().__init__(bus, path)
        self._fd = None
        self._connected_device = None

    @dbus.service.method("org.bluez.Profile1", in_signature="oha{sv}", out_signature="")
    def NewConnection(self, path, fd, properties):
        self._fd = fd.take()
        self._connected_device = path
        print(f"HID Connected: {path} (fd={self._fd})", flush=True)

    @dbus.service.method("org.bluez.Profile1", in_signature="o", out_signature="")
    def RequestDisconnection(self, path):
        print(f"HID Disconnected: {path}", flush=True)
        if self._fd:
            try:
                os.close(self._fd)
            except:
                pass
        self._fd = None
        self._connected_device = None

    @dbus.service.method("org.bluez.Profile1", in_signature="", out_signature="")
    def Release(self):
        print("HID Profile Released", flush=True)


def register_profile(bus, profile, manager):
    """プロファイルを登録"""
    opts = {
        "Name": dbus.String("HID Keyboard"),
        "ServiceRecord": dbus.String(SDP_RECORD),
        "Role": dbus.String("server"),
        "RequireAuthentication": dbus.Boolean(False),
        "RequireAuthorization": dbus.Boolean(False),
    }

    try:
        manager.RegisterProfile("/org/bluez/hid", "00001124-0000-1000-8000-00805f9b34fb", opts)
        print("HID Profile registered", flush=True)
        return True
    except dbus.exceptions.DBusException as e:
        if "AlreadyExists" in str(e) or "already registered" in str(e).lower():
            print("HID Profile already registered", flush=True)
            return True
        print(f"Profile registration error: {e}", flush=True)
        return False


def monitor_bluetooth(bus):
    """Bluetoothアダプターの状態を監視して、必要に応じて再登録"""
    def properties_changed(interface, changed, invalidated, path=None):
        if interface == "org.bluez.Adapter1":
            if "Powered" in changed:
                powered = changed["Powered"]
                print(f"Bluetooth adapter powered: {powered}", flush=True)

    bus.add_signal_receiver(
        properties_changed,
        dbus_interface="org.freedesktop.DBus.Properties",
        signal_name="PropertiesChanged",
        path_keyword="path"
    )


def main():
    dbus.mainloop.glib.DBusGMainLoop(set_as_default=True)
    bus = dbus.SystemBus()

    profile = HIDProfile(bus, "/org/bluez/hid")
    manager = dbus.Interface(bus.get_object("org.bluez", "/org/bluez"), "org.bluez.ProfileManager1")

    # プロファイル登録（リトライあり）
    for attempt in range(3):
        if register_profile(bus, profile, manager):
            break
        print(f"Retrying profile registration ({attempt + 1}/3)...", flush=True)
        time.sleep(2)

    # Bluetooth状態監視
    monitor_bluetooth(bus)

    print("HID Profile waiting for connections...", flush=True)

    loop = GLib.MainLoop()
    try:
        loop.run()
    except KeyboardInterrupt:
        print("HID Profile stopping...", flush=True)


if __name__ == "__main__":
    main()
