# -*- coding: utf-8 -*-
"""
Bluetooth HID キーボードサービス
Raspberry PiをBluetoothキーボードとしてPCに接続し、キーを送信する
"""

import os
import sys
import dbus
import dbus.service
import dbus.mainloop.glib
import socket
import threading
import time

# HID キーコードマッピング (USB HID Usage Tables)
HID_KEYCODES = {
    # ファンクションキー
    'F1': 0x3A, 'F2': 0x3B, 'F3': 0x3C, 'F4': 0x3D,
    'F5': 0x3E, 'F6': 0x3F, 'F7': 0x40, 'F8': 0x41,
    'F9': 0x42, 'F10': 0x43, 'F11': 0x44, 'F12': 0x45,
    'F13': 0x68, 'F14': 0x69, 'F15': 0x6A, 'F16': 0x6B,
    'F17': 0x6C, 'F18': 0x6D, 'F19': 0x6E, 'F20': 0x6F,
    'F21': 0x70, 'F22': 0x71, 'F23': 0x72, 'F24': 0x73,

    # 修飾キー
    'CTRL': 0x01, 'SHIFT': 0x02, 'ALT': 0x04, 'GUI': 0x08,
    'LCTRL': 0x01, 'LSHIFT': 0x02, 'LALT': 0x04, 'LGUI': 0x08,
    'RCTRL': 0x10, 'RSHIFT': 0x20, 'RALT': 0x40, 'RGUI': 0x80,

    # 特殊キー
    'ENTER': 0x28, 'ESC': 0x29, 'BACKSPACE': 0x2A, 'TAB': 0x2B,
    'SPACE': 0x2C, 'CAPSLOCK': 0x39, 'PRINTSCREEN': 0x46,
    'SCROLLLOCK': 0x47, 'PAUSE': 0x48, 'INSERT': 0x49,
    'HOME': 0x4A, 'PAGEUP': 0x4B, 'DELETE': 0x4C, 'END': 0x4D,
    'PAGEDOWN': 0x4E, 'RIGHT': 0x4F, 'LEFT': 0x50, 'DOWN': 0x51, 'UP': 0x52,

    # アルファベット (大文字も対応)
    'A': 0x04, 'B': 0x05, 'C': 0x06, 'D': 0x07, 'E': 0x08,
    'F': 0x09, 'G': 0x0A, 'H': 0x0B, 'I': 0x0C, 'J': 0x0D,
    'K': 0x0E, 'L': 0x0F, 'M': 0x10, 'N': 0x11, 'O': 0x12,
    'P': 0x13, 'Q': 0x14, 'R': 0x15, 'S': 0x16, 'T': 0x17,
    'U': 0x18, 'V': 0x19, 'W': 0x1A, 'X': 0x1B, 'Y': 0x1C, 'Z': 0x1D,

    # アルファベット (小文字)
    'a': 0x04, 'b': 0x05, 'c': 0x06, 'd': 0x07, 'e': 0x08,
    'f': 0x09, 'g': 0x0A, 'h': 0x0B, 'i': 0x0C, 'j': 0x0D,
    'k': 0x0E, 'l': 0x0F, 'm': 0x10, 'n': 0x11, 'o': 0x12,
    'p': 0x13, 'q': 0x14, 'r': 0x15, 's': 0x16, 't': 0x17,
    'u': 0x18, 'v': 0x19, 'w': 0x1A, 'x': 0x1B, 'y': 0x1C, 'z': 0x1D,

    # 数字
    '1': 0x1E, '2': 0x1F, '3': 0x20, '4': 0x21, '5': 0x22,
    '6': 0x23, '7': 0x24, '8': 0x25, '9': 0x26, '0': 0x27,
}

# 修飾キーのビットマスク
MODIFIER_KEYS = {'CTRL', 'SHIFT', 'ALT', 'GUI', 'LCTRL', 'LSHIFT', 'LALT', 'LGUI', 'RCTRL', 'RSHIFT', 'RALT', 'RGUI'}


import json

# コマンドソケットパス
COMMAND_SOCKET = '/tmp/hid_command.sock'
CONNECTION_FILE = '/tmp/hid_connected'


class BluetoothHIDService:
    """Bluetooth HID キーボードサービス（コマンドソケット経由）"""

    def __init__(self):
        self._sock = None

    def _get_socket(self):
        """コマンドソケットを取得"""
        if self._sock is None:
            self._sock = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
        return self._sock

    def is_connected(self):
        """接続状態を返す"""
        return os.path.exists(CONNECTION_FILE)

    def send_key(self, key_string: str):
        """キーを送信

        Args:
            key_string: キー文字列 (例: "F13", "CTRL+SHIFT+a", "ALT+F4")
        """
        if not os.path.exists(COMMAND_SOCKET):
            print(f"Bluetooth HID: コマンドソケットなし")
            return False

        try:
            # キー文字列をパース
            modifier, keycode = self._parse_key_string(key_string)

            if keycode == 0:
                print(f"Bluetooth HID: 不明なキー: {key_string}")
                return False

            # コマンドソケットに送信
            sock = self._get_socket()
            cmd = {
                'action': 'send_key',
                'keycode': keycode,
                'modifiers': modifier
            }
            sock.sendto(json.dumps(cmd).encode(), COMMAND_SOCKET)

            print(f"Bluetooth HID: キー送信 {key_string} (modifier=0x{modifier:02X}, keycode=0x{keycode:02X})")
            return True

        except Exception as e:
            print(f"Bluetooth HID: 送信エラー: {e}")
            return False

    def _parse_key_string(self, key_string: str):
        """キー文字列をパース

        Args:
            key_string: キー文字列 (例: "F13", "CTRL+SHIFT+a")

        Returns:
            (modifier, keycode) のタプル
        """
        parts = key_string.upper().split('+')
        modifier = 0
        keycode = 0

        for part in parts:
            part = part.strip()
            if part in MODIFIER_KEYS:
                modifier |= HID_KEYCODES.get(part, 0)
            else:
                # キーコードを取得（大文字・小文字両方チェック）
                keycode = HID_KEYCODES.get(part, 0) or HID_KEYCODES.get(part.lower(), 0)

        return modifier, keycode


# シングルトンインスタンス
_bluetooth_hid_service = None

def get_bluetooth_hid_service():
    """Bluetooth HIDサービスのシングルトンを取得"""
    global _bluetooth_hid_service
    if _bluetooth_hid_service is None:
        _bluetooth_hid_service = BluetoothHIDService()
    return _bluetooth_hid_service
