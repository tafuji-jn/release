#!/usr/bin/env python3
"""L2CAP HID Server - Listens for HID connections and sends keyboard data"""

import bluetooth
import threading
import time
import os

PSM_CTRL = 17  # Control channel
PSM_INTR = 19  # Interrupt channel

class HIDServer:
    def __init__(self):
        self.ctrl_sock = None
        self.intr_sock = None
        self.ctrl_client = None
        self.intr_client = None
        self.running = False

    def start(self):
        """Start listening for HID connections"""
        self.running = True

        # Control channel server
        self.ctrl_sock = bluetooth.BluetoothSocket(bluetooth.L2CAP)
        self.ctrl_sock.bind(("", PSM_CTRL))
        self.ctrl_sock.listen(1)

        # Interrupt channel server
        self.intr_sock = bluetooth.BluetoothSocket(bluetooth.L2CAP)
        self.intr_sock.bind(("", PSM_INTR))
        self.intr_sock.listen(1)

        print(f"HID Server listening on PSM {PSM_CTRL} (ctrl) and {PSM_INTR} (intr)")

        # Accept connections in threads
        ctrl_thread = threading.Thread(target=self._accept_ctrl)
        intr_thread = threading.Thread(target=self._accept_intr)
        ctrl_thread.daemon = True
        intr_thread.daemon = True
        ctrl_thread.start()
        intr_thread.start()

    def _accept_ctrl(self):
        while self.running:
            try:
                client, addr = self.ctrl_sock.accept()
                print(f"Control channel connected from {addr}")
                self.ctrl_client = client
            except Exception as e:
                if self.running:
                    print(f"Control accept error: {e}")

    def _accept_intr(self):
        while self.running:
            try:
                client, addr = self.intr_sock.accept()
                print(f"Interrupt channel connected from {addr}")
                self.intr_client = client
                # Write to file to signal connection
                with open('/tmp/hid_connected', 'w') as f:
                    f.write('1')
            except Exception as e:
                if self.running:
                    print(f"Interrupt accept error: {e}")

    def is_connected(self):
        return self.intr_client is not None

    def send_key(self, keycode, modifiers=0):
        """Send a key press and release"""
        if not self.intr_client:
            print("Not connected")
            return False

        try:
            # Key press: [0xa1, report_id, modifiers, reserved, keycode, 0, 0, 0, 0, 0]
            press = bytes([0xa1, 0x01, modifiers, 0x00, keycode, 0x00, 0x00, 0x00, 0x00, 0x00])
            self.intr_client.send(press)

            time.sleep(0.02)

            # Key release
            release = bytes([0xa1, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00])
            self.intr_client.send(release)

            return True
        except Exception as e:
            print(f"Send error: {e}")
            self.intr_client = None
            try:
                os.remove('/tmp/hid_connected')
            except:
                pass
            return False

    def send_keys(self, keycodes, modifiers=0):
        """Send multiple keys simultaneously"""
        if not self.intr_client:
            return False

        try:
            # Up to 6 keys can be pressed simultaneously
            report = [0xa1, 0x01, modifiers, 0x00] + list(keycodes)[:6]
            report += [0x00] * (10 - len(report))
            self.intr_client.send(bytes(report))

            time.sleep(0.02)

            release = bytes([0xa1, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00])
            self.intr_client.send(release)
            return True
        except Exception as e:
            print(f"Send error: {e}")
            self.intr_client = None
            return False

    def stop(self):
        self.running = False
        if self.ctrl_client:
            self.ctrl_client.close()
        if self.intr_client:
            self.intr_client.close()
        if self.ctrl_sock:
            self.ctrl_sock.close()
        if self.intr_sock:
            self.intr_sock.close()


# USB HID Keycodes
KEY_A = 0x04
KEY_F13 = 0x68
KEY_F14 = 0x69
KEY_F15 = 0x6A
KEY_F16 = 0x6B
KEY_F17 = 0x6C
KEY_F18 = 0x6D
KEY_F19 = 0x6E
KEY_F20 = 0x6F
KEY_F21 = 0x70
KEY_F22 = 0x71
KEY_F23 = 0x72
KEY_F24 = 0x73

# Modifiers
MOD_LCTRL = 0x01
MOD_LSHIFT = 0x02
MOD_LALT = 0x04
MOD_LGUI = 0x08  # Windows key
MOD_RCTRL = 0x10
MOD_RSHIFT = 0x20
MOD_RALT = 0x40
MOD_RGUI = 0x80


import socket
import json

COMMAND_SOCKET = '/tmp/hid_command.sock'

# Global server instance for command handling
_server = None

def handle_commands():
    """Listen for commands on Unix socket"""
    global _server

    # Remove old socket file
    try:
        os.remove(COMMAND_SOCKET)
    except:
        pass

    cmd_sock = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
    cmd_sock.bind(COMMAND_SOCKET)
    os.chmod(COMMAND_SOCKET, 0o777)

    print(f"Command socket listening on {COMMAND_SOCKET}")

    while True:
        try:
            data = cmd_sock.recv(1024)
            cmd = json.loads(data.decode())

            if cmd.get('action') == 'send_key':
                keycode = cmd.get('keycode', 0)
                modifiers = cmd.get('modifiers', 0)
                if _server and _server.is_connected():
                    _server.send_key(keycode, modifiers)
                    print(f"Sent key: {keycode} mod: {modifiers}")
                else:
                    print("Not connected, cannot send key")

        except Exception as e:
            print(f"Command error: {e}")


if __name__ == '__main__':
    _server = HIDServer()
    _server.start()

    # Start command listener in thread
    cmd_thread = threading.Thread(target=handle_commands)
    cmd_thread.daemon = True
    cmd_thread.start()

    print("Waiting for connection...")
    while not _server.is_connected():
        time.sleep(1)

    print("Connected! Sending test key 'a'...")
    _server.send_key(KEY_A)
    print("Key sent!")

    # Keep running
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nShutting down...")
        _server.stop()
