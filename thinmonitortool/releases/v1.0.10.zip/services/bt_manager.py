# -*- coding: utf-8 -*-
"""Bluetooth管理サービス - デバイススキャン・ペアリング・接続管理"""

import os
import json
import threading
from datetime import datetime
from typing import List, Dict, Optional

import dbus
import dbus.mainloop.glib
from gi.repository import GLib
from PyQt5.QtCore import QObject, pyqtSignal


# 設定ファイルパス
SETTINGS_FILE = os.path.join(os.path.dirname(os.path.dirname(__file__)), '.bluetooth_settings.json')
MAX_SAVED_DEVICES = 5


class BluetoothManager(QObject):
    """Bluetooth管理クラス（D-Bus API使用）"""

    # シグナル
    device_found = pyqtSignal(str, str, int)  # address, name, rssi
    device_removed = pyqtSignal(str)  # address
    pairing_complete = pyqtSignal(str, bool, str)  # address, success, message
    connection_changed = pyqtSignal(str, bool)  # address, connected
    discovery_started = pyqtSignal()
    discovery_stopped = pyqtSignal()

    def __init__(self):
        super().__init__()
        self._bus = None
        self._adapter = None
        self._adapter_props = None
        self._loop = None
        self._loop_thread = None
        self._discovered_devices: Dict[str, Dict] = {}
        self._is_discovering = False
        self._running = False

        # D-Bus初期化
        self._init_dbus()

    def _init_dbus(self):
        """D-Bus接続を初期化"""
        try:
            dbus.mainloop.glib.DBusGMainLoop(set_as_default=True)
            self._bus = dbus.SystemBus()

            # アダプタを取得
            adapter_path = "/org/bluez/hci0"
            adapter_obj = self._bus.get_object("org.bluez", adapter_path)
            self._adapter = dbus.Interface(adapter_obj, "org.bluez.Adapter1")
            self._adapter_props = dbus.Interface(adapter_obj, "org.freedesktop.DBus.Properties")

            # プロパティ変更シグナルを監視
            self._bus.add_signal_receiver(
                self._on_properties_changed,
                dbus_interface="org.freedesktop.DBus.Properties",
                signal_name="PropertiesChanged",
                path_keyword="path"
            )

            # インターフェース追加/削除を監視
            self._bus.add_signal_receiver(
                self._on_interfaces_added,
                dbus_interface="org.freedesktop.DBus.ObjectManager",
                signal_name="InterfacesAdded"
            )

            self._bus.add_signal_receiver(
                self._on_interfaces_removed,
                dbus_interface="org.freedesktop.DBus.ObjectManager",
                signal_name="InterfacesRemoved"
            )

            print("BluetoothManager: D-Bus接続成功")
        except Exception as e:
            print(f"BluetoothManager: D-Bus初期化エラー - {e}")

    def _start_glib_loop(self):
        """GLibメインループを別スレッドで開始"""
        if self._loop_thread and self._loop_thread.is_alive():
            return

        self._running = True
        self._loop = GLib.MainLoop()
        self._loop_thread = threading.Thread(target=self._run_loop, daemon=True)
        self._loop_thread.start()

    def _run_loop(self):
        """GLibメインループ実行"""
        try:
            self._loop.run()
        except Exception as e:
            print(f"BluetoothManager: GLibループエラー - {e}")

    def _stop_glib_loop(self):
        """GLibメインループを停止"""
        self._running = False
        if self._loop:
            self._loop.quit()

    def _on_properties_changed(self, interface, changed, invalidated, path):
        """プロパティ変更時のコールバック"""
        if interface == "org.bluez.Device1":
            address = self._path_to_address(path)
            if not address:
                return

            # デバイス発見
            if "RSSI" in changed or "Name" in changed:
                try:
                    device = self._bus.get_object("org.bluez", path)
                    props = dbus.Interface(device, "org.freedesktop.DBus.Properties")

                    addr = str(props.Get("org.bluez.Device1", "Address"))
                    name = str(props.Get("org.bluez.Device1", "Name") or "Unknown")
                    rssi = int(props.Get("org.bluez.Device1", "RSSI") or -100)

                    self._discovered_devices[addr] = {
                        "address": addr,
                        "name": name,
                        "rssi": rssi,
                        "path": path
                    }
                    self.device_found.emit(addr, name, rssi)
                except Exception:
                    pass

            # 接続状態変更
            if "Connected" in changed:
                connected = bool(changed["Connected"])
                self.connection_changed.emit(address, connected)

        elif interface == "org.bluez.Adapter1":
            if "Discovering" in changed:
                self._is_discovering = bool(changed["Discovering"])
                if self._is_discovering:
                    self.discovery_started.emit()
                else:
                    self.discovery_stopped.emit()

    def _on_interfaces_added(self, path, interfaces):
        """インターフェース追加時"""
        if "org.bluez.Device1" in interfaces:
            props = interfaces["org.bluez.Device1"]
            address = str(props.get("Address", ""))
            name = str(props.get("Name", "Unknown"))
            rssi = int(props.get("RSSI", -100))

            if address:
                self._discovered_devices[address] = {
                    "address": address,
                    "name": name,
                    "rssi": rssi,
                    "path": str(path)
                }
                self.device_found.emit(address, name, rssi)

    def _on_interfaces_removed(self, path, interfaces):
        """インターフェース削除時"""
        if "org.bluez.Device1" in interfaces:
            address = self._path_to_address(path)
            if address and address in self._discovered_devices:
                del self._discovered_devices[address]
                self.device_removed.emit(address)

    def _path_to_address(self, path: str) -> Optional[str]:
        """D-Busパスからアドレスを抽出"""
        # /org/bluez/hci0/dev_XX_XX_XX_XX_XX_XX -> XX:XX:XX:XX:XX:XX
        if "/dev_" in path:
            addr_part = path.split("/dev_")[-1]
            return addr_part.replace("_", ":")
        return None

    def _address_to_path(self, address: str) -> str:
        """アドレスからD-Busパスを生成"""
        addr_part = address.replace(":", "_")
        return f"/org/bluez/hci0/dev_{addr_part}"

    def set_discoverable(self, enabled: bool, timeout: int = 180):
        """検出可能モードを設定（PC側から見つけられるようにする）"""
        try:
            self._adapter_props.Set("org.bluez.Adapter1", "Discoverable", dbus.Boolean(enabled))
            if enabled:
                self._adapter_props.Set("org.bluez.Adapter1", "DiscoverableTimeout", dbus.UInt32(timeout))
                print(f"BluetoothManager: 検出可能モード ON ({timeout}秒)")
            else:
                print("BluetoothManager: 検出可能モード OFF")
            return True
        except Exception as e:
            print(f"BluetoothManager: 検出可能モード設定エラー - {e}")
            return False

    def set_pairable(self, enabled: bool, timeout: int = 180):
        """ペアリング可能モードを設定"""
        try:
            self._adapter_props.Set("org.bluez.Adapter1", "Pairable", dbus.Boolean(enabled))
            if enabled:
                self._adapter_props.Set("org.bluez.Adapter1", "PairableTimeout", dbus.UInt32(timeout))
                print(f"BluetoothManager: ペアリング可能モード ON ({timeout}秒)")
            else:
                print("BluetoothManager: ペアリング可能モード OFF")
            return True
        except Exception as e:
            print(f"BluetoothManager: ペアリング可能モード設定エラー - {e}")
            return False

    def start_discovery(self, timeout: int = 30):
        """デバイススキャン開始"""
        try:
            self._start_glib_loop()
            self._discovered_devices.clear()
            self._adapter.StartDiscovery()
            print("BluetoothManager: スキャン開始")

            # タイムアウト後に自動停止
            if timeout > 0:
                def stop_after_timeout():
                    import time
                    time.sleep(timeout)
                    if self._is_discovering:
                        self.stop_discovery()

                threading.Thread(target=stop_after_timeout, daemon=True).start()

            return True
        except dbus.exceptions.DBusException as e:
            print(f"BluetoothManager: スキャン開始エラー - {e}")
            return False

    def stop_discovery(self):
        """デバイススキャン停止"""
        try:
            if self._is_discovering:
                self._adapter.StopDiscovery()
                print("BluetoothManager: スキャン停止")
            return True
        except dbus.exceptions.DBusException as e:
            print(f"BluetoothManager: スキャン停止エラー - {e}")
            return False

    def get_discovered_devices(self) -> List[Dict]:
        """発見済みデバイス一覧を取得"""
        return list(self._discovered_devices.values())

    def get_paired_devices(self) -> List[Dict]:
        """ペアリング済みデバイス一覧を取得"""
        devices = []
        try:
            obj_manager = dbus.Interface(
                self._bus.get_object("org.bluez", "/"),
                "org.freedesktop.DBus.ObjectManager"
            )

            managed_objects = obj_manager.GetManagedObjects()

            for path in managed_objects:
                interfaces = managed_objects[path]
                if "org.bluez.Device1" in interfaces:
                    props = interfaces["org.bluez.Device1"]
                    if props.get("Paired", False):
                        devices.append({
                            "address": str(props.get("Address", "")),
                            "name": str(props.get("Name", "Unknown")),
                            "paired": bool(props.get("Paired", False)),
                            "trusted": bool(props.get("Trusted", False)),
                            "connected": bool(props.get("Connected", False)),
                            "path": str(path),
                            "icon": str(props.get("Icon", "")),
                            "uuids": list(props.get("UUIDs", []))
                        })
        except Exception as e:
            print(f"BluetoothManager: ペアリング済みデバイス取得エラー - {e}")

        return devices

    def get_paired_audio_devices(self) -> List[Dict]:
        """ペアリング済みのオーディオデバイス（A2DP対応）を取得"""
        # A2DP Sink UUID
        A2DP_SINK_UUID = "0000110b-0000-1000-8000-00805f9b34fb"
        AUDIO_SINK_UUID = "0000110a-0000-1000-8000-00805f9b34fb"

        all_devices = self.get_paired_devices()
        audio_devices = []

        for dev in all_devices:
            uuids = [str(u).lower() for u in dev.get("uuids", [])]
            icon = dev.get("icon", "")

            # A2DPまたはオーディオ関連UUIDを持つか、アイコンがaudioの場合
            is_audio = (
                A2DP_SINK_UUID in uuids or
                AUDIO_SINK_UUID in uuids or
                "audio" in icon.lower() or
                any("audio" in u for u in uuids)
            )

            if is_audio:
                audio_devices.append(dev)

        return audio_devices

    def is_bluetooth_audio_connected(self) -> bool:
        """Bluetoothオーディオデバイスが接続されているか確認"""
        audio_devices = self.get_paired_audio_devices()
        return any(dev.get("connected", False) for dev in audio_devices)

    def pair_device(self, address: str) -> bool:
        """デバイスをペアリング"""
        try:
            path = self._address_to_path(address)
            device = self._bus.get_object("org.bluez", path)
            device_iface = dbus.Interface(device, "org.bluez.Device1")
            props_iface = dbus.Interface(device, "org.freedesktop.DBus.Properties")

            # 既にペアリング済みか確認
            if props_iface.Get("org.bluez.Device1", "Paired"):
                self.pairing_complete.emit(address, True, "既にペアリング済み")
                return True

            # ペアリング実行
            device_iface.Pair()

            # 信頼設定
            props_iface.Set("org.bluez.Device1", "Trusted", dbus.Boolean(True))

            # デバイス名取得
            name = str(props_iface.Get("org.bluez.Device1", "Name") or "Unknown")

            print(f"BluetoothManager: ペアリング成功 - {address} ({name})")
            self.pairing_complete.emit(address, True, "ペアリング成功")

            # 設定ファイルに保存
            self.save_device(address, name)

            return True
        except dbus.exceptions.DBusException as e:
            error_msg = str(e)
            print(f"BluetoothManager: ペアリングエラー - {error_msg}")
            self.pairing_complete.emit(address, False, error_msg)
            return False

    def trust_device(self, address: str) -> bool:
        """デバイスを信頼設定"""
        try:
            path = self._address_to_path(address)
            device = self._bus.get_object("org.bluez", path)
            props_iface = dbus.Interface(device, "org.freedesktop.DBus.Properties")
            props_iface.Set("org.bluez.Device1", "Trusted", dbus.Boolean(True))
            return True
        except Exception as e:
            print(f"BluetoothManager: 信頼設定エラー - {e}")
            return False

    def connect_device(self, address: str) -> bool:
        """デバイスに接続"""
        try:
            path = self._address_to_path(address)
            device = self._bus.get_object("org.bluez", path)
            device_iface = dbus.Interface(device, "org.bluez.Device1")
            device_iface.Connect()
            print(f"BluetoothManager: 接続成功 - {address}")
            return True
        except dbus.exceptions.DBusException as e:
            print(f"BluetoothManager: 接続エラー - {e}")
            return False

    def disconnect_device(self, address: str) -> bool:
        """デバイスから切断"""
        try:
            path = self._address_to_path(address)
            device = self._bus.get_object("org.bluez", path)
            device_iface = dbus.Interface(device, "org.bluez.Device1")
            device_iface.Disconnect()
            print(f"BluetoothManager: 切断成功 - {address}")
            return True
        except dbus.exceptions.DBusException as e:
            print(f"BluetoothManager: 切断エラー - {e}")
            return False

    def remove_device(self, address: str) -> bool:
        """デバイスを削除（ペアリング解除）"""
        try:
            path = self._address_to_path(address)
            self._adapter.RemoveDevice(dbus.ObjectPath(path))
            print(f"BluetoothManager: デバイス削除 - {address}")
            return True
        except dbus.exceptions.DBusException as e:
            print(f"BluetoothManager: デバイス削除エラー - {e}")
            return False

    def is_device_connected(self, address: str) -> bool:
        """デバイスが接続中か確認"""
        try:
            path = self._address_to_path(address)
            device = self._bus.get_object("org.bluez", path)
            props_iface = dbus.Interface(device, "org.freedesktop.DBus.Properties")
            return bool(props_iface.Get("org.bluez.Device1", "Connected"))
        except Exception:
            return False

    def get_device_name(self, address: str) -> Optional[str]:
        """bluezからデバイス名を取得"""
        try:
            path = self._address_to_path(address)
            device = self._bus.get_object("org.bluez", path)
            props_iface = dbus.Interface(device, "org.freedesktop.DBus.Properties")
            name = props_iface.Get("org.bluez.Device1", "Name")
            return str(name) if name else None
        except Exception:
            return None

    # ========== 設定ファイル管理 ==========

    def load_settings(self) -> Dict:
        """設定ファイルを読み込み"""
        try:
            if os.path.exists(SETTINGS_FILE):
                with open(SETTINGS_FILE, 'r', encoding='utf-8') as f:
                    return json.load(f)
        except Exception as e:
            print(f"BluetoothManager: 設定読み込みエラー - {e}")

        return {"saved_devices": [], "last_device": None}

    def save_settings(self, settings: Dict):
        """設定ファイルを保存"""
        try:
            with open(SETTINGS_FILE, 'w', encoding='utf-8') as f:
                json.dump(settings, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"BluetoothManager: 設定保存エラー - {e}")

    def get_saved_devices(self) -> List[Dict]:
        """保存済みデバイス一覧を取得"""
        settings = self.load_settings()
        return settings.get("saved_devices", [])

    def get_last_device(self) -> Optional[str]:
        """前回接続デバイスアドレスを取得"""
        settings = self.load_settings()
        return settings.get("last_device")

    def save_device(self, address: str, name: str):
        """デバイスを保存"""
        settings = self.load_settings()
        devices = settings.get("saved_devices", [])

        # 既存デバイスを更新
        found = False
        for dev in devices:
            if dev["address"] == address:
                dev["name"] = name
                dev["last_connected"] = datetime.now().isoformat()
                found = True
                break

        # 新規追加
        if not found:
            devices.append({
                "address": address,
                "name": name,
                "last_connected": datetime.now().isoformat()
            })

        # 最大数を超えた場合、古いものを削除
        if len(devices) > MAX_SAVED_DEVICES:
            # last_connectedでソートして古いものを削除
            devices.sort(key=lambda x: x.get("last_connected", ""), reverse=True)
            devices = devices[:MAX_SAVED_DEVICES]

        settings["saved_devices"] = devices
        self.save_settings(settings)

    def remove_saved_device(self, address: str):
        """保存済みデバイスを削除"""
        settings = self.load_settings()
        devices = settings.get("saved_devices", [])
        devices = [d for d in devices if d["address"] != address]
        settings["saved_devices"] = devices

        # last_deviceも削除
        if settings.get("last_device") == address:
            settings["last_device"] = None

        self.save_settings(settings)

    def set_last_device(self, address: str):
        """前回接続デバイスを設定"""
        settings = self.load_settings()
        settings["last_device"] = address

        # saved_devicesのlast_connectedも更新
        for dev in settings.get("saved_devices", []):
            if dev["address"] == address:
                dev["last_connected"] = datetime.now().isoformat()
                break

        self.save_settings(settings)

    def stop(self):
        """サービス停止"""
        self.stop_discovery()
        self._stop_glib_loop()


# シングルトンインスタンス
_bt_manager_instance: Optional[BluetoothManager] = None


def get_bt_manager() -> BluetoothManager:
    """BluetoothManagerのシングルトンインスタンスを取得"""
    global _bt_manager_instance
    if _bt_manager_instance is None:
        _bt_manager_instance = BluetoothManager()
    return _bt_manager_instance
