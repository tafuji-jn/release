#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Bluetooth HID Keyboard Service
常駐サービスとしてHIDプロファイルを維持し、キー送信を処理
"""

import os
import socket
import threading
import time
import dbus
import dbus.service
import dbus.mainloop.glib
from gi.repository import GLib

# HID キーコード
HID_KEYCODES = {
    'F1': 0x3A, 'F2': 0x3B, 'F3': 0x3C, 'F4': 0x3D,
    'F5': 0x3E, 'F6': 0x3F, 'F7': 0x40, 'F8': 0x41,
    'F9': 0x42, 'F10': 0x43, 'F11': 0x44, 'F12': 0x45,
    'F13': 0x68, 'F14': 0x69, 'F15': 0x6A, 'F16': 0x6B,
    'F17': 0x6C, 'F18': 0x6D, 'F19': 0x6E, 'F20': 0x6F,
    'F21': 0x70, 'F22': 0x71, 'F23': 0x72, 'F24': 0x73,
    'CTRL': 0x01, 'SHIFT': 0x02, 'ALT': 0x04, 'GUI': 0x08,
    'ENTER': 0x28, 'ESC': 0x29, 'BACKSPACE': 0x2A, 'TAB': 0x2B,
    'SPACE': 0x2C, 'DELETE': 0x4C, 'RIGHT': 0x4F, 'LEFT': 0x50,
    'DOWN': 0x51, 'UP': 0x52,
    'a': 0x04, 'b': 0x05, 'c': 0x06, 'd': 0x07, 'e': 0x08,
    'f': 0x09, 'g': 0x0A, 'h': 0x0B, 'i': 0x0C, 'j': 0x0D,
    'k': 0x0E, 'l': 0x0F, 'm': 0x10, 'n': 0x11, 'o': 0x12,
    'p': 0x13, 'q': 0x14, 'r': 0x15, 's': 0x16, 't': 0x17,
    'u': 0x18, 'v': 0x19, 'w': 0x1A, 'x': 0x1B, 'y': 0x1C, 'z': 0x1D,
    '1': 0x1E, '2': 0x1F, '3': 0x20, '4': 0x21, '5': 0x22,
    '6': 0x23, '7': 0x24, '8': 0x25, '9': 0x26, '0': 0x27,
}
MODIFIER_KEYS = {'CTRL', 'SHIFT', 'ALT', 'GUI'}

P_CTRL = 17
P_INTR = 19

SDP_RECORD = '''<?xml version="1.0" encoding="UTF-8" ?>
<record>
    <attribute id="0x0001"><sequence><uuid value="0x1124"/></sequence></attribute>
    <attribute id="0x0004"><sequence><sequence><uuid value="0x0100"/><uint16 value="0x0011"/></sequence><sequence><uuid value="0x0011"/></sequence></sequence></attribute>
    <attribute id="0x0005"><sequence><uuid value="0x1002"/></sequence></attribute>
    <attribute id="0x0006"><sequence><uint16 value="0x656e"/><uint16 value="0x006a"/><uint16 value="0x0100"/></sequence></attribute>
    <attribute id="0x0009"><sequence><sequence><uuid value="0x1124"/><uint16 value="0x0100"/></sequence></sequence></attribute>
    <attribute id="0x000d"><sequence><sequence><sequence><uuid value="0x0100"/><uint16 value="0x0013"/></sequence><sequence><uuid value="0x0011"/></sequence></sequence></sequence></attribute>
    <attribute id="0x0100"><text value="ThinMonitor Keyboard"/></attribute>
    <attribute id="0x0101"><text value="Bluetooth Keyboard"/></attribute>
    <attribute id="0x0102"><text value="ThinMonitorPalet"/></attribute>
    <attribute id="0x0200"><uint16 value="0x0100"/></attribute>
    <attribute id="0x0201"><uint16 value="0x0111"/></attribute>
    <attribute id="0x0202"><uint8 value="0x40"/></attribute>
    <attribute id="0x0203"><uint8 value="0x00"/></attribute>
    <attribute id="0x0204"><boolean value="true"/></attribute>
    <attribute id="0x0205"><boolean value="true"/></attribute>
    <attribute id="0x0206"><sequence><sequence><uint8 value="0x22"/><text encoding="hex" value="05010906a101850175019508050719e029e715002501810295017508810395057501050819012905910295017503910395067508150026ff000507190029ff8100c0"/></sequence></sequence></attribute>
    <attribute id="0x0207"><sequence><sequence><uint16 value="0x0409"/><uint16 value="0x0100"/></sequence></sequence></attribute>
    <attribute id="0x020b"><uint16 value="0x0100"/></attribute>
    <attribute id="0x020c"><uint16 value="0x0c80"/></attribute>
    <attribute id="0x020d"><boolean value="false"/></attribute>
    <attribute id="0x020e"><boolean value="true"/></attribute>
    <attribute id="0x020f"><uint16 value="0x0640"/></attribute>
    <attribute id="0x0210"><uint16 value="0x0320"/></attribute>
</record>'''


class HIDProfile(dbus.service.Object):
    """D-Bus HID Profile"""

    fd = -1

    @dbus.service.method("org.bluez.Profile1", in_signature="", out_signature="")
    def Release(self):
        print("HID Profile: Released")

    @dbus.service.method("org.bluez.Profile1", in_signature="oha{sv}", out_signature="")
    def NewConnection(self, path, fd, properties):
        self.fd = fd.take()
        print(f"HID Profile: NewConnection fd={self.fd}")

    @dbus.service.method("org.bluez.Profile1", in_signature="o", out_signature="")
    def RequestDisconnection(self, path):
        print(f"HID Profile: RequestDisconnection {path}")
        self.fd = -1


class HIDKeyboardService:
    """HID Keyboard Service"""

    def __init__(self):
        self._interrupt_socket = None
        self._interrupt_client = None
        self._is_connected = False
        self._running = False
        self._profile = None
        self._loop = None

    def start(self):
        """サービス開始"""
        if self._running:
            return

        self._running = True

        # D-Busスレッド
        dbus_thread = threading.Thread(target=self._run_dbus, daemon=True)
        dbus_thread.start()

        # L2CAPソケットスレッド
        socket_thread = threading.Thread(target=self._run_socket_server, daemon=True)
        socket_thread.start()

        print("HID Service: Started")

    def _run_dbus(self):
        """D-Bus メインループ"""
        dbus.mainloop.glib.DBusGMainLoop(set_as_default=True)
        bus = dbus.SystemBus()

        # プロファイルを登録
        self._profile = HIDProfile(bus, "/org/bluez/hid_keyboard")

        manager = dbus.Interface(
            bus.get_object("org.bluez", "/org/bluez"),
            "org.bluez.ProfileManager1"
        )

        opts = {
            "Name": dbus.String("ThinMonitor Keyboard"),
            "Role": dbus.String("server"),
            "RequireAuthentication": dbus.Boolean(False),
            "RequireAuthorization": dbus.Boolean(False),
            "ServiceRecord": dbus.String(SDP_RECORD),
        }

        try:
            manager.RegisterProfile("/org/bluez/hid_keyboard",
                                   "00001124-0000-1000-8000-00805f9b34fb", opts)
            print("HID Service: Profile registered")
        except dbus.exceptions.DBusException as e:
            if "Already Exists" in str(e) or "already registered" in str(e).lower():
                print("HID Service: Profile already registered")
            else:
                print(f"HID Service: Profile error - {e}")

        self._loop = GLib.MainLoop()
        self._loop.run()

    def _run_socket_server(self):
        """L2CAP ソケットサーバー"""
        while self._running:
            try:
                # Interrupt channel のみ使用
                self._interrupt_socket = socket.socket(
                    socket.AF_BLUETOOTH, socket.SOCK_SEQPACKET, socket.BTPROTO_L2CAP)
                self._interrupt_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                self._interrupt_socket.bind((socket.BDADDR_ANY, P_INTR))
                self._interrupt_socket.listen(1)
                self._interrupt_socket.settimeout(1.0)

                print(f"HID Service: Listening on PSM {P_INTR}")

                while self._running:
                    try:
                        client, addr = self._interrupt_socket.accept()
                        self._interrupt_client = client
                        self._is_connected = True
                        print(f"HID Service: Connected from {addr}")

                        # 接続維持
                        while self._running and self._is_connected:
                            time.sleep(0.5)

                    except socket.timeout:
                        continue
                    except Exception as e:
                        print(f"HID Service: Accept error - {e}")
                        self._is_connected = False
                        time.sleep(1)

            except Exception as e:
                print(f"HID Service: Socket error - {e}")
                time.sleep(2)

    def stop(self):
        """サービス停止"""
        self._running = False
        self._is_connected = False
        if self._loop:
            self._loop.quit()
        if self._interrupt_client:
            self._interrupt_client.close()
        if self._interrupt_socket:
            self._interrupt_socket.close()

    def is_connected(self):
        return self._is_connected

    def send_key(self, key_string):
        """キー送信"""
        if not self._is_connected or not self._interrupt_client:
            return False

        try:
            modifier, keycode = self._parse_key(key_string)

            # Key press
            report = bytes([0xA1, 0x01, modifier, 0x00, keycode, 0x00, 0x00, 0x00, 0x00, 0x00])
            self._interrupt_client.send(report)

            time.sleep(0.02)

            # Key release
            release = bytes([0xA1, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00])
            self._interrupt_client.send(release)

            print(f"HID Service: Sent {key_string}")
            return True

        except Exception as e:
            print(f"HID Service: Send error - {e}")
            self._is_connected = False
            return False

    def _parse_key(self, key_string):
        parts = key_string.upper().split('+')
        modifier = 0
        keycode = 0

        for part in parts:
            part = part.strip()
            if part in MODIFIER_KEYS:
                modifier |= HID_KEYCODES.get(part, 0)
            else:
                keycode = HID_KEYCODES.get(part, 0) or HID_KEYCODES.get(part.lower(), 0)

        return modifier, keycode


# Singleton
_service = None

def get_hid_service():
    global _service
    if _service is None:
        _service = HIDKeyboardService()
    return _service


if __name__ == "__main__":
    service = get_hid_service()
    service.start()

    print("HID Keyboard Service running. Press Ctrl+C to exit.")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        service.stop()
        print("\nStopped")
