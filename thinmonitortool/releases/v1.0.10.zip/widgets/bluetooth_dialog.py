# -*- coding: utf-8 -*-
"""Bluetoothスキャン・ペアリングダイアログ"""

from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QListWidget, QListWidgetItem, QWidget, QProgressBar, QMessageBox
)
from PyQt5.QtCore import Qt, QTimer, pyqtSignal
from PyQt5.QtGui import QFont


class DeviceListItem(QWidget):
    """デバイスリストアイテムウィジェット"""

    def __init__(self, address: str, name: str, rssi: int, paired: bool = False, connected: bool = False):
        super().__init__()
        self.address = address
        self.name = name
        self.rssi = rssi
        self.paired = paired
        self.connected = connected

        self._setup_ui()

    def _setup_ui(self):
        layout = QHBoxLayout(self)
        layout.setContentsMargins(10, 8, 10, 8)

        # 状態アイコン
        if self.connected:
            icon = "🔵"
        elif self.paired:
            icon = "✓"
        else:
            icon = "○"

        icon_label = QLabel(icon)
        icon_label.setFixedWidth(24)
        layout.addWidget(icon_label)

        # デバイス情報
        info_layout = QVBoxLayout()
        info_layout.setSpacing(2)

        name_label = QLabel(self.name)
        name_label.setStyleSheet("color: #ffffff; font-size: 14px; font-weight: bold;")
        info_layout.addWidget(name_label)

        addr_label = QLabel(self.address)
        addr_label.setStyleSheet("color: #888888; font-size: 11px;")
        info_layout.addWidget(addr_label)

        layout.addLayout(info_layout, 1)

        # RSSI表示
        if self.rssi > -100:
            rssi_label = QLabel(f"{self.rssi}dBm")
            rssi_label.setStyleSheet("color: #666666; font-size: 11px;")
            layout.addWidget(rssi_label)


class BluetoothScanDialog(QDialog):
    """Bluetoothデバイススキャンダイアログ"""

    deviceSelected = pyqtSignal(str, str)  # address, name

    def __init__(self, parent=None):
        super().__init__(parent)
        self._bt_manager = None
        self._selected_address = None
        self._selected_name = None
        self._is_scanning = False

        self._setup_ui()
        self._connect_signals()

    def _setup_ui(self):
        self.setWindowTitle("Bluetoothデバイス")
        self.setFixedSize(400, 500)
        self.setStyleSheet("""
            QDialog {
                background-color: #2a2a2a;
            }
            QLabel {
                color: #ffffff;
            }
            QPushButton {
                background-color: #444;
                color: #fff;
                border: none;
                border-radius: 4px;
                padding: 10px 20px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #555;
            }
            QPushButton:pressed {
                background-color: #666;
            }
            QPushButton:disabled {
                background-color: #333;
                color: #666;
            }
            QListWidget {
                background-color: #333;
                border: 1px solid #444;
                border-radius: 4px;
            }
            QListWidget::item {
                border-bottom: 1px solid #444;
            }
            QListWidget::item:selected {
                background-color: rgba(233, 69, 96, 0.3);
            }
            QProgressBar {
                background-color: #333;
                border: none;
                border-radius: 2px;
                height: 4px;
            }
            QProgressBar::chunk {
                background-color: #e94560;
                border-radius: 2px;
            }
        """)

        layout = QVBoxLayout(self)
        layout.setSpacing(15)
        layout.setContentsMargins(20, 20, 20, 20)

        # タイトル
        title = QLabel("Bluetoothデバイスをスキャン")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #ffffff;")
        layout.addWidget(title)

        # スキャン状態
        status_layout = QHBoxLayout()

        self._status_label = QLabel("スキャンを開始してください")
        self._status_label.setStyleSheet("color: #888888; font-size: 12px;")
        status_layout.addWidget(self._status_label)

        status_layout.addStretch()

        self._scan_btn = QPushButton("スキャン開始")
        self._scan_btn.setFixedWidth(120)
        self._scan_btn.clicked.connect(self._on_scan_clicked)
        status_layout.addWidget(self._scan_btn)

        layout.addLayout(status_layout)

        # プログレスバー
        self._progress = QProgressBar()
        self._progress.setTextVisible(False)
        self._progress.setRange(0, 0)  # 無限ループ
        self._progress.hide()
        layout.addWidget(self._progress)

        # デバイスリスト
        self._device_list = QListWidget()
        self._device_list.itemClicked.connect(self._on_item_clicked)
        self._device_list.itemDoubleClicked.connect(self._on_item_double_clicked)
        layout.addWidget(self._device_list, 1)

        # ボタンエリア
        btn_layout = QHBoxLayout()

        self._pair_btn = QPushButton("ペアリング")
        self._pair_btn.setEnabled(False)
        self._pair_btn.setStyleSheet("""
            QPushButton {
                background-color: #e94560;
            }
            QPushButton:hover {
                background-color: #d63850;
            }
            QPushButton:disabled {
                background-color: #333;
                color: #666;
            }
        """)
        self._pair_btn.clicked.connect(self._on_pair_clicked)
        btn_layout.addWidget(self._pair_btn)

        self._cancel_btn = QPushButton("キャンセル")
        self._cancel_btn.clicked.connect(self.reject)
        btn_layout.addWidget(self._cancel_btn)

        layout.addLayout(btn_layout)

    def _connect_signals(self):
        """BluetoothManagerのシグナルを接続"""
        from services.bt_manager import get_bt_manager
        self._bt_manager = get_bt_manager()

        self._bt_manager.device_found.connect(self._on_device_found)
        self._bt_manager.discovery_started.connect(self._on_discovery_started)
        self._bt_manager.discovery_stopped.connect(self._on_discovery_stopped)
        self._bt_manager.pairing_complete.connect(self._on_pairing_complete)

    def _on_scan_clicked(self):
        """スキャンボタンクリック"""
        if self._is_scanning:
            self._bt_manager.stop_discovery()
        else:
            self._device_list.clear()
            self._bt_manager.start_discovery(timeout=20)

    def _on_discovery_started(self):
        """スキャン開始"""
        self._is_scanning = True
        self._scan_btn.setText("スキャン停止")
        self._status_label.setText("スキャン中...")
        self._progress.show()

    def _on_discovery_stopped(self):
        """スキャン停止"""
        self._is_scanning = False
        self._scan_btn.setText("スキャン開始")
        self._status_label.setText(f"{self._device_list.count()}台のデバイスが見つかりました")
        self._progress.hide()

    def _on_device_found(self, address: str, name: str, rssi: int):
        """デバイス発見"""
        # 既存のアイテムを更新または追加
        for i in range(self._device_list.count()):
            item = self._device_list.item(i)
            widget = self._device_list.itemWidget(item)
            if widget and widget.address == address:
                # 更新
                widget.name = name
                widget.rssi = rssi
                return

        # 新規追加
        item = QListWidgetItem()
        widget = DeviceListItem(address, name, rssi)
        item.setSizeHint(widget.sizeHint())
        self._device_list.addItem(item)
        self._device_list.setItemWidget(item, widget)

    def _on_item_clicked(self, item: QListWidgetItem):
        """アイテムクリック"""
        widget = self._device_list.itemWidget(item)
        if widget:
            self._selected_address = widget.address
            self._selected_name = widget.name
            self._pair_btn.setEnabled(True)

    def _on_item_double_clicked(self, item: QListWidgetItem):
        """アイテムダブルクリック"""
        self._on_item_clicked(item)
        self._on_pair_clicked()

    def _on_pair_clicked(self):
        """ペアリングボタンクリック"""
        if not self._selected_address:
            return

        self._pair_btn.setEnabled(False)
        self._pair_btn.setText("ペアリング中...")
        self._status_label.setText(f"{self._selected_name} にペアリング中...")

        # ペアリング実行
        self._bt_manager.pair_device(self._selected_address)

    def _on_pairing_complete(self, address: str, success: bool, message: str):
        """ペアリング完了"""
        self._pair_btn.setText("ペアリング")
        self._pair_btn.setEnabled(True)

        if success:
            self._status_label.setText("ペアリング成功")
            self.deviceSelected.emit(address, self._selected_name)
            self.accept()
        else:
            self._status_label.setText(f"ペアリング失敗: {message}")
            QMessageBox.warning(self, "エラー", f"ペアリングに失敗しました:\n{message}")

    def showEvent(self, event):
        """ダイアログ表示時"""
        super().showEvent(event)
        # 既存のペアリング済みデバイスを表示
        self._load_paired_devices()

    def _load_paired_devices(self):
        """ペアリング済みデバイスを読み込み"""
        paired = self._bt_manager.get_paired_devices()
        for dev in paired:
            item = QListWidgetItem()
            widget = DeviceListItem(
                dev["address"],
                dev["name"],
                -100,
                paired=True,
                connected=dev.get("connected", False)
            )
            item.setSizeHint(widget.sizeHint())
            self._device_list.addItem(item)
            self._device_list.setItemWidget(item, widget)

    def closeEvent(self, event):
        """ダイアログ閉じる時"""
        if self._is_scanning:
            self._bt_manager.stop_discovery()
        super().closeEvent(event)
