# -*- coding: utf-8 -*-
"""共通ユーティリティ関数"""

from PyQt5.QtCore import Qt
from PyQt5.QtGui import QPainter, QColor, QPixmap, QImage


def load_transparent_icon(path, width, height, color=None, fill_color=None, fill_inner=False):
    """透過PNG/SVGを正しく読み込む。colorで線の色変更、fill_colorで透過部分を塗りつぶし、fill_innerで円内部のみ"""
    path_str = str(path)
    if path_str.endswith('.svg'):
        # SVGの場合はQSvgRendererを使用
        from PyQt5.QtSvg import QSvgRenderer
        renderer = QSvgRenderer(path_str)
        if not renderer.isValid():
            return QPixmap()
        pixmap = QPixmap(width, height)
        pixmap.fill(Qt.transparent)
        painter = QPainter(pixmap)
        renderer.render(painter)
        painter.end()
        image = pixmap.toImage()
        if color or fill_color:
            cx, cy = width / 2, height / 2
            radius = min(width, height) / 2 * 0.9  # 円の半径（少し小さめ）
            for y in range(image.height()):
                for x in range(image.width()):
                    pixel = image.pixelColor(x, y)
                    if pixel.alpha() > 0 and color:
                        # 線の色を変更
                        image.setPixelColor(x, y, QColor(color.red(), color.green(), color.blue(), pixel.alpha()))
                    elif pixel.alpha() == 0 and fill_color:
                        # 透過部分を塗りつぶし（fill_innerなら円内部のみ）
                        if fill_inner:
                            dist = ((x - cx) ** 2 + (y - cy) ** 2) ** 0.5
                            if dist < radius:
                                image.setPixelColor(x, y, fill_color)
                        else:
                            image.setPixelColor(x, y, fill_color)
            pixmap = QPixmap.fromImage(image)
        return pixmap
    else:
        image = QImage(path_str)
        if image.isNull():
            return QPixmap()
        # ARGB32形式に変換して透過を確保
        image = image.convertToFormat(QImage.Format_ARGB32)
        # スケーリング
        image = image.scaled(width, height, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        return QPixmap.fromImage(image)
