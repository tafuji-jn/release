# -*- coding: utf-8 -*-
"""時計ウィジェット"""

import json
import urllib.request
import urllib.error
import ssl

from PyQt5.QtWidgets import QWidget, QFrame, QVBoxLayout, QHBoxLayout, QLabel
from PyQt5.QtCore import Qt, QTimer, QTime, QDate, QLocale, QPropertyAnimation, QEasingCurve, pyqtProperty, pyqtSignal
from PyQt5.QtGui import QPainter, QColor, QFont


class FlipDigitWidget(QWidget):
    """フリップクロック風の上下分割数字ボックス（アニメーション付き）"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(220, 210)
        self._current_value = "00"
        self._next_value = "00"
        self._flip_angle = 0.0  # 0〜180度
        self._is_flipping = False

        # アニメーション設定
        self._animation = QPropertyAnimation(self, b"flip_angle")
        self._animation.setDuration(300)  # 300ms
        self._animation.setEasingCurve(QEasingCurve.OutQuad)
        self._animation.finished.connect(self._on_animation_finished)

    def get_flip_angle(self):
        return self._flip_angle

    def set_flip_angle(self, angle):
        self._flip_angle = angle
        self.update()

    flip_angle = pyqtProperty(float, get_flip_angle, set_flip_angle)

    def set_value(self, value: str):
        if value != self._current_value:
            if not self._is_flipping:
                self._next_value = value
                self._start_flip()
            else:
                # アニメーション中なら次の値を更新
                self._next_value = value

    def _start_flip(self):
        self._is_flipping = True
        self._animation.setStartValue(0.0)
        self._animation.setEndValue(180.0)
        self._animation.start()

    def _on_animation_finished(self):
        self._current_value = self._next_value
        self._flip_angle = 0.0
        self._is_flipping = False
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setRenderHint(QPainter.TextAntialiasing)

        w = self.width()
        h = self.height()
        half_h = h // 2
        radius = 12
        gap = 3  # 上下パネル間の隙間（分割線の太さ）

        bg_color = QColor(45, 45, 45)
        bg_color_dark = QColor(38, 38, 38)
        text_color = QColor(255, 255, 255)
        line_color = QColor(0, 0, 0)

        font = QFont("Segoe UI", 90, QFont.Bold)
        painter.setFont(font)

        if not self._is_flipping:
            # 静止状態
            self._draw_static_panel(painter, w, h, half_h, radius, gap,
                                     bg_color, bg_color_dark, text_color, line_color,
                                     self._current_value)
        else:
            # アニメーション中
            angle = self._flip_angle

            if angle <= 90:
                # 前半: 上パネルが倒れる
                # 背景（次の値の上半分を先に描画）
                self._draw_upper_panel(painter, 0, 0, w, half_h - gap, radius,
                                        bg_color, self._next_value, text_color, clip_upper=True)
                # 下パネル（現在の値）
                self._draw_lower_panel(painter, 0, half_h + gap, w, half_h - gap, radius,
                                        bg_color_dark, self._current_value, text_color)

                # 倒れる上パネル（現在の値）
                self._draw_flipping_upper(painter, w, half_h, gap, radius, angle,
                                           bg_color, self._current_value, text_color)
            else:
                # 後半: 下パネルが起き上がる
                # 上パネル（次の値）
                self._draw_upper_panel(painter, 0, 0, w, half_h - gap, radius,
                                        bg_color, self._next_value, text_color, clip_upper=True)
                # 背景（現在の値の下半分）
                self._draw_lower_panel(painter, 0, half_h + gap, w, half_h - gap, radius,
                                        bg_color_dark, self._current_value, text_color)

                # 起き上がる下パネル（次の値）
                self._draw_flipping_lower(painter, w, half_h, gap, radius, angle,
                                           bg_color_dark, self._next_value, text_color)

            # 分割線
            painter.setPen(line_color)
            for i in range(gap * 2 + 1):
                painter.drawLine(0, half_h - gap + i, w, half_h - gap + i)

    def _draw_static_panel(self, painter, w, h, half_h, radius, gap,
                            bg_color, bg_color_dark, text_color, line_color, value):
        """静止状態のパネルを描画"""
        # 上半分のパネル
        painter.setBrush(bg_color)
        painter.setPen(Qt.NoPen)
        painter.drawRoundedRect(0, 0, w, half_h - gap, radius, radius)
        painter.drawRect(0, half_h - gap - radius, w, radius)

        # 下半分のパネル（少し暗く）
        painter.setBrush(bg_color_dark)
        painter.drawRoundedRect(0, half_h + gap, w, half_h - gap, radius, radius)
        painter.drawRect(0, half_h + gap, w, radius)

        # 数字を描画
        painter.setPen(text_color)
        text_rect = self.rect()
        painter.drawText(text_rect, Qt.AlignCenter, value)

        # 分割線（数字の上に描画）
        painter.setBrush(line_color)
        painter.setPen(Qt.NoPen)
        painter.drawRect(0, half_h - gap, w, gap * 2)

    def _draw_upper_panel(self, painter, x, y, w, h, radius, bg_color, value, text_color, clip_upper=False):
        """上パネルを描画"""
        painter.save()
        painter.setBrush(bg_color)
        painter.setPen(Qt.NoPen)
        painter.drawRoundedRect(x, y, w, h, radius, radius)
        painter.drawRect(x, y + h - radius, w, radius)

        if clip_upper:
            painter.setClipRect(x, y, w, h)
        painter.setPen(text_color)
        full_rect = self.rect()
        painter.drawText(full_rect, Qt.AlignCenter, value)
        painter.restore()

    def _draw_lower_panel(self, painter, x, y, w, h, radius, bg_color, value, text_color):
        """下パネルを描画"""
        painter.save()
        painter.setBrush(bg_color)
        painter.setPen(Qt.NoPen)
        painter.drawRoundedRect(x, y, w, h, radius, radius)
        painter.drawRect(x, y, w, radius)

        painter.setClipRect(x, y, w, h)
        painter.setPen(text_color)
        full_rect = self.rect()
        painter.drawText(full_rect, Qt.AlignCenter, value)
        painter.restore()

    def _draw_flipping_upper(self, painter, w, half_h, gap, radius, angle, bg_color, value, text_color):
        """倒れる上パネルを描画"""
        painter.save()

        # スケール変換で回転効果を表現
        scale_y = abs(90 - angle) / 90.0
        if scale_y < 0.05:
            scale_y = 0.05

        panel_h = half_h - gap
        center_y = half_h - gap

        painter.translate(0, center_y)
        painter.scale(1.0, scale_y)
        painter.translate(0, -panel_h)

        painter.setBrush(bg_color)
        painter.setPen(Qt.NoPen)
        painter.drawRoundedRect(0, 0, w, panel_h, radius, radius)
        painter.drawRect(0, panel_h - radius, w, radius)

        painter.setClipRect(0, 0, w, panel_h)
        painter.setPen(text_color)
        # テキスト位置調整
        painter.drawText(0, 0, w, self.height(), Qt.AlignCenter, value)

        painter.restore()

    def _draw_flipping_lower(self, painter, w, half_h, gap, radius, angle, bg_color, value, text_color):
        """起き上がる下パネルを描画"""
        painter.save()

        scale_y = (angle - 90) / 90.0
        if scale_y < 0.05:
            scale_y = 0.05

        panel_h = half_h - gap
        start_y = half_h + gap

        painter.translate(0, start_y)
        painter.scale(1.0, scale_y)

        painter.setBrush(bg_color)
        painter.setPen(Qt.NoPen)
        painter.drawRoundedRect(0, 0, w, panel_h, radius, radius)
        painter.drawRect(0, 0, w, radius)

        painter.setClipRect(0, 0, w, panel_h)
        painter.setPen(text_color)
        # テキスト位置調整（下半分）
        painter.drawText(0, -half_h + gap, w, self.height(), Qt.AlignCenter, value)

        painter.restore()


class ClockWidget(QFrame):
    """左側の時計表示ウィジェット"""

    # 埼玉県蓮田市の座標
    LATITUDE = 35.9950
    LONGITUDE = 139.6611

    # 天気コードとアイコンのマッピング
    WEATHER_ICONS = {
        0: "☀️",      # Clear sky
        1: "🌤️",     # Mainly clear
        2: "⛅",      # Partly cloudy
        3: "☁️",      # Overcast
        45: "🌫️",    # Fog
        48: "🌫️",    # Depositing rime fog
        51: "🌧️",    # Light drizzle
        53: "🌧️",    # Moderate drizzle
        55: "🌧️",    # Dense drizzle
        61: "🌧️",    # Slight rain
        63: "🌧️",    # Moderate rain
        65: "🌧️",    # Heavy rain
        71: "🌨️",    # Slight snow
        73: "🌨️",    # Moderate snow
        75: "❄️",     # Heavy snow
        80: "🌧️",    # Slight rain showers
        81: "🌧️",    # Moderate rain showers
        82: "🌧️",    # Violent rain showers
        95: "⛈️",     # Thunderstorm
        96: "⛈️",     # Thunderstorm with slight hail
        99: "⛈️",     # Thunderstorm with heavy hail
    }

    # テーマ変更シグナル
    themeChanged = pyqtSignal(str)  # 'light' or 'dark'

    def __init__(self, parent=None):
        super().__init__(parent)
        self._current_temp = "--"
        self._current_icon = "☁️"
        # スワイプ検出用
        self._swipe_start_x = None
        self._swipe_start_y = None
        self._edge_threshold = 150  # 左端からこの範囲でスワイプ開始を検出
        self._swipe_threshold = 50  # スワイプと判定する最小距離
        self._slide_menu = None
        self.setup_ui()
        self.setup_timer()
        self.fetch_weather()  # 初回取得

    def setup_ui(self):
        """UIの初期化"""
        self.setObjectName("clockWidget")

        main_layout = QVBoxLayout(self)
        main_layout.setAlignment(Qt.AlignCenter)
        main_layout.setSpacing(15)
        main_layout.setContentsMargins(20, 20, 20, 20)

        # 時刻表示エリア（フリップクロック風）
        time_layout = QHBoxLayout()
        time_layout.setAlignment(Qt.AlignCenter)
        time_layout.setSpacing(8)

        # 時
        self.hour_widget = FlipDigitWidget()
        time_layout.addWidget(self.hour_widget)

        # コロン
        colon1 = QLabel(":")
        colon1.setObjectName("colonLabel")
        colon1.setAlignment(Qt.AlignCenter)
        colon1.setFixedWidth(25)
        time_layout.addWidget(colon1)

        # 分
        self.minute_widget = FlipDigitWidget()
        time_layout.addWidget(self.minute_widget)

        # コロン
        colon2 = QLabel(":")
        colon2.setObjectName("colonLabel")
        colon2.setAlignment(Qt.AlignCenter)
        colon2.setFixedWidth(25)
        time_layout.addWidget(colon2)

        # 秒
        self.second_widget = FlipDigitWidget()
        time_layout.addWidget(self.second_widget)

        main_layout.addLayout(time_layout)

        # 下部エリア（日付と天気）
        bottom_layout = QHBoxLayout()
        bottom_layout.setContentsMargins(10, 0, 10, 0)

        # 日付（左寄せ）
        self.date_label = QLabel()
        self.date_label.setObjectName("dateLabel")
        self.date_label.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        bottom_layout.addWidget(self.date_label)

        bottom_layout.addStretch()

        # 天気（右寄せ）
        weather_layout = QHBoxLayout()
        weather_layout.setSpacing(8)

        self.weather_icon = QLabel(self._current_icon)
        self.weather_icon.setObjectName("weatherIcon")
        weather_layout.addWidget(self.weather_icon)

        self.temp_label = QLabel(self._current_temp)
        self.temp_label.setObjectName("tempLabel")
        weather_layout.addWidget(self.temp_label)

        bottom_layout.addLayout(weather_layout)

        main_layout.addLayout(bottom_layout)

        self.update_display()

    def setup_timer(self):
        """タイマーの設定（1秒ごとに更新）"""
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_display)
        self.timer.start(1000)

        # 天気更新タイマー（30分ごと）
        self.weather_timer = QTimer(self)
        self.weather_timer.timeout.connect(self.fetch_weather)
        self.weather_timer.start(1800000)  # 30分 = 1800000ms

    def fetch_weather(self):
        """Open-Meteo APIから天気情報を取得"""
        try:
            url = (
                f"https://api.open-meteo.com/v1/forecast?"
                f"latitude={self.LATITUDE}&longitude={self.LONGITUDE}"
                f"&current=temperature_2m,weather_code"
                f"&timezone=Asia%2FTokyo"
            )
            req = urllib.request.Request(url, headers={'User-Agent': 'ThinMonitorPalet/1.0'})
            # SSL証明書検証をスキップ（Windows環境対策）
            ssl_context = ssl.create_default_context()
            ssl_context.check_hostname = False
            ssl_context.verify_mode = ssl.CERT_NONE
            with urllib.request.urlopen(req, timeout=10, context=ssl_context) as response:
                data = json.loads(response.read().decode('utf-8'))

            current = data.get('current', {})
            temp = current.get('temperature_2m')
            weather_code = current.get('weather_code', 3)

            if temp is not None:
                self._current_temp = f"{int(round(temp))}°"
            self._current_icon = self.WEATHER_ICONS.get(weather_code, "☁️")

            # UIを更新
            self.temp_label.setText(self._current_temp)
            self.weather_icon.setText(self._current_icon)

        except (urllib.error.URLError, urllib.error.HTTPError, json.JSONDecodeError, Exception) as e:
            print(f"Weather fetch error: {e}")
            # エラー時はデフォルト値を維持

    def update_display(self):
        """時刻表示の更新"""
        current_time = QTime.currentTime()
        current_date = QDate.currentDate()

        # 時刻を更新
        self.hour_widget.set_value(current_time.toString("hh"))
        self.minute_widget.set_value(current_time.toString("mm"))
        self.second_widget.set_value(current_time.toString("ss"))

        # 日付を更新（Mon, Dec 22 形式）
        locale = QLocale(QLocale.English)
        day_name = locale.dayName(current_date.dayOfWeek(), QLocale.ShortFormat)
        month_name = locale.monthName(current_date.month(), QLocale.ShortFormat)
        self.date_label.setText(f"{day_name}, {month_name} {current_date.day()}")

    def set_slide_menu(self, menu):
        """スライドメニューを設定（外部から注入）"""
        self._slide_menu = menu
        if menu:
            menu.setParent(self)
            menu.setFixedHeight(self.height() if self.height() > 0 else 580)
            menu.themeChanged.connect(self._on_menu_theme_changed)
            menu.hide()

    def _on_menu_theme_changed(self, theme):
        """メニューからテーマ変更された時"""
        self.themeChanged.emit(theme)

    def set_menu_theme(self, theme):
        """メニューのテーマ状態を設定"""
        if self._slide_menu:
            self._slide_menu.set_current_theme(theme)

    def resizeEvent(self, event):
        """リサイズ時にメニューの高さを調整"""
        super().resizeEvent(event)
        if self._slide_menu:
            self._slide_menu.setFixedHeight(self.height())

    def mousePressEvent(self, event):
        """マウス押下時"""
        if event.button() == Qt.LeftButton:
            x = event.pos().x()
            # 左端付近でのタッチ開始を検出
            if x < self._edge_threshold:
                self._swipe_start_x = x
                self._swipe_start_y = event.pos().y()
            # メニュー表示中は、メニュー外タッチで閉じる
            elif self._slide_menu and self._slide_menu.is_menu_visible():
                if x > self._slide_menu.width():
                    self._slide_menu.hide_menu()
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        """マウス移動時"""
        if self._swipe_start_x is not None:
            delta_x = event.pos().x() - self._swipe_start_x
            # 右方向へのスワイプを検出
            if delta_x > self._swipe_threshold:
                self._swipe_start_x = None
                if self._slide_menu:
                    self._slide_menu.show_menu()
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        """マウスリリース時"""
        self._swipe_start_x = None
        self._swipe_start_y = None
        super().mouseReleaseEvent(event)
