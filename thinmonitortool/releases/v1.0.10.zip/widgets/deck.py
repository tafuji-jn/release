# -*- coding: utf-8 -*-
"""Deckボタンエリアウィジェット（ahkエリア / streamdeckエリア）"""

import json
import base64
from pathlib import Path

from PyQt5.QtWidgets import QFrame, QWidget, QVBoxLayout, QHBoxLayout, QLabel
from PyQt5.QtCore import Qt, QPoint, QPropertyAnimation, QEasingCurve, pyqtSignal, QTimer, QByteArray
from PyQt5.QtGui import QPainter, QColor, QPixmap
from PyQt5.QtSvg import QSvgRenderer


class DeckButton(QFrame):
    """Stream Deck風のボタンウィジェット"""
    clicked = pyqtSignal()
    keyPressed = pyqtSignal(str)  # キー送信シグナル

    def __init__(self, icon: str, label: str, color: str = "#3498db", key: str = "", icon_image: str = "", size: int = 120, parent=None):
        super().__init__(parent)
        self.setObjectName("deckButton")
        self._size = size
        self._key = key  # 送信するキー
        self.setFixedSize(size, size)
        self.setCursor(Qt.PointingHandCursor)

        # カラーを保存
        self._color = color
        self._hover = False

        layout = QVBoxLayout(self)
        margin = int(size * 0.06)
        layout.setContentsMargins(margin, margin, margin, margin)
        layout.setSpacing(int(size * 0.02))
        layout.setAlignment(Qt.AlignCenter)

        # アイコン（画像またはテキスト）
        icon_size = int(size * 0.55)
        self.icon_label = QLabel()
        self.icon_label.setAlignment(Qt.AlignCenter)
        self.icon_label.setFixedSize(int(size * 0.7), int(size * 0.6))

        if icon_image:
            # Base64画像をデコードして表示
            try:
                pixmap = self._base64_to_pixmap(icon_image)
                if pixmap and not pixmap.isNull():
                    scaled = pixmap.scaled(icon_size, icon_size, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                    self.icon_label.setPixmap(scaled)
                    self.icon_label.setStyleSheet("background: transparent;")
                else:
                    raise ValueError("Invalid pixmap")
            except Exception as e:
                print(f"画像デコードエラー: {e}")
                # フォールバック: 絵文字表示
                self.icon_label.setText(icon)
                self.icon_label.setStyleSheet(f"""
                    font-size: {icon_size}px;
                    color: {color};
                    background: transparent;
                """)
        else:
            # 絵文字表示
            self.icon_label.setText(icon)
            self.icon_label.setStyleSheet(f"""
                font-size: {icon_size}px;
                color: {color};
                background: transparent;
            """)
        layout.addWidget(self.icon_label, alignment=Qt.AlignCenter)

        # ラベル
        self.text_label = QLabel(label)
        self.text_label.setAlignment(Qt.AlignCenter)
        label_font_size = int(size * 0.11)
        self.text_label.setStyleSheet(f"""
            font-size: {label_font_size}px;
            font-family: 'Noto Sans JP', 'Yu Gothic UI', 'Hiragino Sans', 'Meiryo', sans-serif;
            font-weight: 500;
            color: #e0e0e0;
            background: transparent;
            letter-spacing: 1px;
        """)
        layout.addWidget(self.text_label, alignment=Qt.AlignCenter)

        self._update_style()

    def _update_style(self):
        if self._hover:
            self.setStyleSheet(f"""
                #deckButton {{
                    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                        stop:0 #4a4a4a, stop:1 #2a2a2a);
                    border: 2px solid {self._color};
                    border-radius: 15px;
                }}
            """)
        else:
            self.setStyleSheet("""
                #deckButton {
                    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                        stop:0 #3a3a3a, stop:1 #1a1a1a);
                    border: 1px solid #555555;
                    border-radius: 15px;
                }
            """)

    def enterEvent(self, event):
        # タッチ操作ではmousePressEvent/mouseReleaseEventで制御するため
        # ここでは何もしない（ウィンドウフォーカス変更時の誤発火防止）
        super().enterEvent(event)

    def leaveEvent(self, event):
        # タッチ操作ではmousePressEvent/mouseReleaseEventで制御するため
        # ここでは何もしない
        super().leaveEvent(event)

    def mousePressEvent(self, event):
        # 押下位置を記録
        self._press_pos = event.pos()
        # タップ時に枠線を表示
        self._hover = True
        self._update_style()
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        # スワイプ判定（移動距離が小さい場合のみクリック）
        if hasattr(self, '_press_pos') and self._press_pos:
            delta = event.pos() - self._press_pos
            if abs(delta.x()) < 20 and abs(delta.y()) < 20:
                # クリック判定
                label = self.text_label.text()
                print(f"Button clicked: {label} (key={self._key})")
                self.clicked.emit()
                if self._key:
                    self.keyPressed.emit(self._key)
        self._press_pos = None
        # タップ後にホバー状態をリセット（枠線を消す）
        self._hover = False
        self._update_style()
        super().mouseReleaseEvent(event)

    def _base64_to_pixmap(self, base64_str: str) -> QPixmap:
        """Base64文字列をQPixmapに変換"""
        image_data = base64.b64decode(base64_str)
        pixmap = QPixmap()
        pixmap.loadFromData(QByteArray(image_data))
        return pixmap


class PageIndicator(QWidget):
    """iOS風ドットインジケータ"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._total_dots = 3  # ドット数
        self._current_position = 0.0  # 0.0 - 1.0
        self.setFixedSize(30, 80)

    def set_total_dots(self, count):
        """ドット数を設定"""
        self._total_dots = max(2, count)
        self.update()

    def set_position(self, ratio):
        """スクロール位置を設定（0.0-1.0）"""
        self._current_position = max(0.0, min(1.0, ratio))
        self.update()

    def paintEvent(self, event):
        if self._total_dots < 2:
            return

        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        dot_radius = 3
        dot_spacing = 12
        total_height = (self._total_dots - 1) * dot_spacing

        # 中央揃え
        start_y = (self.height() - total_height) / 2

        # 現在のアクティブドットインデックス（0〜total_dots-1の実数）
        active_index = self._current_position * (self._total_dots - 1)

        for i in range(self._total_dots):
            y = start_y + i * dot_spacing
            x = self.width() / 2

            # アクティブドットからの距離で透明度を決定
            distance = abs(i - active_index)
            if distance < 1:
                # アクティブまたは隣接
                alpha = int(255 * (1 - distance * 0.6))
                radius = dot_radius + (1 - distance) * 2
            else:
                alpha = 100
                radius = dot_radius

            painter.setPen(Qt.NoPen)
            painter.setBrush(QColor(255, 255, 255, alpha))
            painter.drawEllipse(int(x - radius), int(y - radius), int(radius * 2), int(radius * 2))


class SwipeableButtonArea(QFrame):
    """スワイプ対応の下部ボタンエリア（ahkエリア / streamdeckエリア）"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("buttonArea")
        self.setFixedHeight(140)

        # スワイプ関連
        self._swipe_start_x = None
        self._swipe_start_pos = None
        self._swipe_threshold = 80
        self._current_page = 0
        self._is_animating = False

        # 設定ファイルからボタンデータを読み込み
        self._buttons_data = self._load_config()

        self.setup_ui()

    def _load_config(self):
        """設定ファイルからボタン構成を読み込む"""
        # 親ディレクトリのdeck_config.jsonを参照
        config_path = Path(__file__).parent.parent / "deck_config.json"
        default_data = [
            [
                ("⚙️", "設定", "#95a5a6", "F13"),
                ("🌤️", "天気", "#f39c12", "F14"),
                ("📅", "予定", "#e74c3c", "F15"),
                ("🎵", "音楽", "#9b59b6", "F16"),
            ]
        ]

        try:
            if config_path.exists():
                with open(config_path, 'r', encoding='utf-8') as f:
                    config = json.load(f)

                pages = config.get('pages', [])
                result = []
                for page in pages:
                    page_buttons = []
                    for btn in page:
                        page_buttons.append((
                            btn.get('icon', '?'),
                            btn.get('label', ''),
                            btn.get('color', '#3498db'),
                            btn.get('key', ''),  # キー設定
                            btn.get('icon_image', '')  # 画像アイコン（Base64）
                        ))
                    result.append(page_buttons)
                return result if result else default_data
        except Exception as e:
            print(f"deck_config.json 読み込みエラー: {e}")

        return default_data

    def setup_ui(self):
        """UIの初期化"""
        # メインレイアウト
        main_layout = QHBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # ページコンテナ（スワイプ対応）
        self.page_container = QWidget(self)
        self.page_container.setStyleSheet("background-color: transparent;")

        # ページウィジェットを作成
        self._pages = []
        self._create_pages()

        # アニメーション設定
        self._slide_animation = QPropertyAnimation(self.page_container, b"pos")
        self._slide_animation.setDuration(250)
        self._slide_animation.setEasingCurve(QEasingCurve.OutCubic)
        self._slide_animation.finished.connect(self._on_animation_finished)

        # ページインジケータ（ドット）
        self.indicator_widget = QWidget(self)
        self.indicator_widget.setFixedSize(60, 20)
        self._update_indicator()

        # Bluetoothステータスインジケータ（左上）
        self._bt_connected = False
        self.bt_status_label = QLabel(self)
        self.bt_status_label.setFixedSize(30, 30)
        self._update_bt_status()

        # Bluetooth接続状態を定期的にチェック
        self._bt_check_timer = QTimer(self)
        self._bt_check_timer.timeout.connect(self._check_bt_connection)
        self._bt_check_timer.start(2000)  # 2秒ごとにチェック

    def _create_pages(self):
        """ページを作成"""
        for page_data in self._buttons_data:
            page = QWidget(self.page_container)
            page_layout = QHBoxLayout(page)
            page_layout.setContentsMargins(30, 8, 30, 8)
            page_layout.setSpacing(20)

            page_layout.addStretch()
            for button_info in page_data:
                # 5要素（icon, label, color, key, icon_image）または旧形式に対応
                if len(button_info) >= 5:
                    icon, label, color, key, icon_image = button_info[:5]
                elif len(button_info) >= 4:
                    icon, label, color, key = button_info[:4]
                    icon_image = ""
                else:
                    icon, label, color = button_info[:3]
                    key = ""
                    icon_image = ""
                btn = DeckButton(icon, label, color, key=key, icon_image=icon_image, size=120)
                btn.keyPressed.connect(self._on_key_pressed)
                page_layout.addWidget(btn)
            page_layout.addStretch()

            self._pages.append(page)

    def _on_key_pressed(self, key: str):
        """キー押下時の処理 - Bluetooth HIDでキーを送信"""
        try:
            from services.bt_keyboard import get_keyboard_service
            keyboard_service = get_keyboard_service()
            if keyboard_service.is_connected():
                keyboard_service.send_key(key)
            else:
                print(f"BT Keyboard: 未接続 (key={key})")
        except ImportError as e:
            print(f"BT Keyboard: サービスのインポートに失敗: {e}")
        except Exception as e:
            print(f"BT Keyboard: キー送信エラー: {e}")

    def _check_bt_connection(self):
        """HIDキーボードサービスの接続状態をチェック"""
        try:
            from services.bt_keyboard import get_keyboard_service
            keyboard_service = get_keyboard_service()
            connected = keyboard_service.is_connected()
            if connected != self._bt_connected:
                self._bt_connected = connected
                self._update_bt_status()
        except Exception:
            pass  # エラー時は状態を変更しない

    def _update_bt_status(self):
        """Bluetoothステータス表示を更新"""
        # SVGアイコンを読み込んで色を変更
        icon_path = Path(__file__).parent.parent / "icon" / "bluetooth.svg"

        if self._bt_connected:
            color = "#3498db"  # 青
            bg_color = "#2a2a2a"
            tooltip = "HID Keyboard: 接続中"
        else:
            color = "#666666"  # グレー
            bg_color = "#1a1a1a"
            tooltip = "HID Keyboard: 未接続"

        # SVGを読み込んでPixmapに変換
        try:
            with open(icon_path, 'r') as f:
                svg_content = f.read()
            # 色を置換
            svg_content = svg_content.replace('currentColor', color)

            renderer = QSvgRenderer(svg_content.encode())
            pixmap = QPixmap(20, 20)
            pixmap.fill(Qt.transparent)
            painter = QPainter(pixmap)
            renderer.render(painter)
            painter.end()

            self.bt_status_label.setPixmap(pixmap)
        except Exception as e:
            # フォールバック: テキスト表示
            self.bt_status_label.setText("BT")

        self.bt_status_label.setStyleSheet(f"""
            QLabel {{
                background-color: {bg_color};
                border-radius: 4px;
                padding: 4px;
            }}
        """)
        self.bt_status_label.setToolTip(tooltip)

    def resizeEvent(self, event):
        """リサイズ時にページを再配置"""
        super().resizeEvent(event)
        self._layout_pages()

    def _layout_pages(self):
        """ページを横に並べて配置"""
        if not self._pages:
            return

        page_width = self.width()
        page_height = self.height()

        # コンテナのサイズを設定
        total_width = page_width * len(self._pages)
        self.page_container.setFixedSize(total_width, page_height)

        # 各ページを配置
        for i, page in enumerate(self._pages):
            page.setGeometry(i * page_width, 0, page_width, page_height)

        # インジケータを右下に配置
        self.indicator_widget.move(self.width() - 70, self.height() - 25)

        # Bluetoothステータスを左上に配置
        self.bt_status_label.move(10, 8)

        # 現在のページ位置に移動
        self._update_page_position(animate=False)

    def _update_page_position(self, animate=True):
        """ページ位置を更新"""
        target_x = -self._current_page * self.width()
        target_pos = QPoint(target_x, 0)

        if animate and not self._is_animating:
            self._is_animating = True
            self._slide_animation.setStartValue(self.page_container.pos())
            self._slide_animation.setEndValue(target_pos)
            self._slide_animation.start()
        else:
            self.page_container.move(target_pos)

    def _update_indicator(self):
        """ページインジケータ（ドット）を更新"""
        # 既存のレイアウトをクリア
        if self.indicator_widget.layout():
            while self.indicator_widget.layout().count():
                item = self.indicator_widget.layout().takeAt(0)
                if item.widget():
                    item.widget().deleteLater()
        else:
            layout = QHBoxLayout(self.indicator_widget)
            layout.setContentsMargins(0, 0, 0, 0)
            layout.setSpacing(8)

        layout = self.indicator_widget.layout()
        for i in range(len(self._buttons_data)):
            dot = QLabel("●" if i == self._current_page else "○")
            dot.setStyleSheet(f"color: {'#ffffff' if i == self._current_page else '#555555'}; font-size: 10px;")
            layout.addWidget(dot)

    def _on_animation_finished(self):
        """アニメーション完了"""
        self._is_animating = False

    def mousePressEvent(self, event):
        """タッチ/マウス押下"""
        self._swipe_start_x = event.pos().x()
        self._swipe_start_pos = self.page_container.pos()
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        """タッチ/マウス移動"""
        if self._swipe_start_x is not None and self._swipe_start_pos is not None:
            delta_x = event.pos().x() - self._swipe_start_x
            new_x = self._swipe_start_pos.x() + delta_x

            # ページの範囲制限（少し余裕を持たせる）
            max_x = 50
            min_x = -self.width() * (len(self._pages) - 1) - 50
            new_x = max(min_x, min(max_x, new_x))

            self.page_container.move(new_x, 0)
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        """タッチ/マウスリリース"""
        if self._swipe_start_x is not None:
            delta_x = event.pos().x() - self._swipe_start_x

            if abs(delta_x) > self._swipe_threshold:
                if delta_x > 0 and self._current_page > 0:
                    # 右スワイプ → 前のページへ
                    self._current_page -= 1
                elif delta_x < 0 and self._current_page < len(self._pages) - 1:
                    # 左スワイプ → 次のページへ
                    self._current_page += 1

            self._update_indicator()
            self._update_page_position(animate=True)

        self._swipe_start_x = None
        self._swipe_start_pos = None
        super().mouseReleaseEvent(event)

    def set_page_count(self, count):
        """ページ数を変更"""
        # 現在のページ数と同じなら何もしない
        if count == len(self._buttons_data):
            return

        # 設定ファイルを読み込んで必要なページ数だけ使用
        all_buttons = self._load_all_buttons()

        # ページ数に応じてボタンを分配
        buttons_per_page = 12
        new_pages = []
        for i in range(count):
            start = i * buttons_per_page
            end = start + buttons_per_page
            if start < len(all_buttons):
                new_pages.append(all_buttons[start:end])
            else:
                # ボタンが足りない場合は空ページ
                new_pages.append([("➕", "追加", "#555555")])

        self._buttons_data = new_pages
        self._rebuild_pages()

    def _load_all_buttons(self):
        """全ボタンデータを読み込む"""
        config_path = Path(__file__).parent.parent / "deck_config.json"
        all_buttons = []

        try:
            if config_path.exists():
                with open(config_path, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                for page in config.get('pages', []):
                    for btn in page:
                        all_buttons.append((
                            btn.get('icon', '?'),
                            btn.get('label', ''),
                            btn.get('color', '#3498db'),
                            btn.get('key', ''),  # キー設定
                            btn.get('icon_image', '')  # 画像アイコン
                        ))
        except Exception as e:
            print(f"ボタン読み込みエラー: {e}")

        return all_buttons

    def _rebuild_pages(self):
        """ページを再構築"""
        # 既存のページを削除
        for page in self._pages:
            page.setParent(None)
            page.deleteLater()
        self._pages = []

        # 現在のページをリセット
        self._current_page = 0

        # 新しいページを作成
        self._create_pages()

        # ページを表示
        for page in self._pages:
            page.show()

        # レイアウトを更新
        self._layout_pages()
        self._update_indicator()

        # コンテナ位置をリセット
        self.page_container.move(0, 0)

    def get_page_count(self):
        """現在のページ数を返す"""
        return len(self._buttons_data)
