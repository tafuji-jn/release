# -*- coding: utf-8 -*-
"""カレンダーウィジェット"""

import json
import calendar
import jpholiday
from datetime import date
from pathlib import Path

from PyQt5.QtWidgets import (
    QFrame, QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
    QGridLayout, QPushButton
)
from PyQt5.QtCore import (
    Qt, QTimer, QDate, QLocale, QPoint,
    QPropertyAnimation, QEasingCurve, pyqtSignal, QParallelAnimationGroup
)
from PyQt5.QtGui import QPainter, QColor, QFont

class CalendarWidget(QFrame):
    """右側の月間カレンダーウィジェット"""

    # 日付がクリックされた時のシグナル
    dateClicked = pyqtSignal(int, int, int)  # year, month, day
    # 表示月が変更された時のシグナル
    monthChanged = pyqtSignal(int, int)  # year, month

    # テーマカラー定義
    THEMES = {
        'light': {
            'container_bg': '#f5f5f5',
            'text_primary': '#000000',
            'text_secondary': '#666666',
            'text_tertiary': '#333333',
            'border': '#cccccc',
            'cell_bg': '#f5f5f5',
            'cell_selected': '#d0d0d0',
            'sunday': '#e94560',
            'saturday': '#4dabf7',
            'today_bg': '#e94560',
            'today_text': '#ffffff',
            'badge_bg': 'rgba(0, 0, 0, 0.3)',
            'empty_bg': '#f5f5f5',
            'weekday_header': '#333333',
            'mini_text': '#333333',
        },
        'dark': {
            'container_bg': '#1e1e1e',
            'text_primary': '#ffffff',
            'text_secondary': '#dddddd',
            'text_tertiary': '#ffffff',
            'border': '#555555',
            'cell_bg': '#1e1e1e',
            'cell_selected': '#333333',
            'sunday': '#ff6b6b',
            'saturday': '#74c0fc',
            'today_bg': '#e94560',
            'today_text': '#ffffff',
            'badge_bg': 'rgba(255, 255, 255, 0.4)',
            'empty_bg': '#1e1e1e',
            'weekday_header': '#888888',
            'mini_text': '#999999',
        }
    }

    SETTINGS_FILE = Path(__file__).parent.parent / '.calendar_settings.json'

    def __init__(self, parent=None):
        super().__init__(parent)
        self.day_labels = []
        self._event_counts = {}  # 予定がある日付と件数の辞書 {date: count}
        self._selected_date = None  # 選択中の日付
        self._current_theme = self._load_theme()  # 保存されたテーマを読み込み
        # 表示中の年月を追跡
        current_date = QDate.currentDate()
        self._display_year = current_date.year()
        self._display_month = current_date.month()
        # スワイプ検出用
        self._drag_start_x = None
        self._drag_start_container_x = None  # ドラッグ開始時のコンテナ位置
        self._swipe_threshold = 80  # スワイプと判定する最小移動距離
        self._calendar_container = None
        self._next_calendar_container = None  # 次月/前月用のコンテナ
        self._is_dragging = False
        self._is_animating = False  # アニメーション中フラグ
        self._container_width = 620  # カレンダーコンテナの幅
        self._anim_group = None
        self._slide_animation = None
        self._pending_transition = None
        self._click_pos = None  # タップ検出用
        self._click_threshold = 10  # タップと判定する最大移動距離
        self.setup_ui()
        self.setup_timer()

    def _load_theme(self):
        """保存されたテーマを読み込み"""
        try:
            if self.SETTINGS_FILE.exists():
                with open(self.SETTINGS_FILE, 'r') as f:
                    settings = json.load(f)
                    return settings.get('theme', 'light')
        except Exception:
            pass
        return 'light'

    def _save_theme(self):
        """テーマを保存"""
        try:
            with open(self.SETTINGS_FILE, 'w') as f:
                json.dump({'theme': self._current_theme}, f)
        except Exception as e:
            print(f"Failed to save theme: {e}")

    def set_theme(self, theme):
        """テーマを設定"""
        if theme not in self.THEMES:
            return
        self._current_theme = theme
        self._save_theme()
        self._apply_theme()
        self.update_display()

    def _get_theme_color(self, key):
        """現在のテーマから色を取得"""
        return self.THEMES[self._current_theme].get(key, '#000000')

    def _apply_theme(self):
        """テーマをコンテナに適用"""
        if self._calendar_container:
            bg = self._get_theme_color('container_bg')
            self._calendar_container.setStyleSheet(f"""
                background-color: {bg};
                border-radius: 10px;
            """)

    def setup_ui(self):
        """UIの初期化"""
        self.setObjectName("calendarWidget")

        main_layout = QHBoxLayout(self)
        main_layout.setContentsMargins(20, 10, 20, 20)  # 上10px、下20pxマージン

        # カレンダー本体（共通メソッドで作成）
        calendar_container = self._create_calendar_container()

        # ラベル参照を設定
        self.month_num_label = calendar_container.month_num_label
        self.year_label = calendar_container.year_label
        self.month_name_label = calendar_container.month_name_label
        self.prev_month_widget = calendar_container.prev_mini
        self.next_month_widget = calendar_container.next_mini
        self.day_labels = calendar_container.day_labels
        self.today_button = calendar_container.today_button

        main_layout.addWidget(calendar_container)
        main_layout.addStretch()

        # カレンダーコンテナを保存（スワイプ検出用）
        self._calendar_container = calendar_container
        # マウスイベントを受け取れるようにする
        calendar_container.setMouseTracking(True)
        calendar_container.installEventFilter(self)

        self.update_display()

    def is_holiday(self, year, month, day):
        """祝日かどうかを判定（jpholidayを使用）"""
        return jpholiday.is_holiday(date(year, month, day))

    def eventFilter(self, obj, event):
        """イベントフィルター - カレンダーコンテナのマウスイベントを処理"""
        from PyQt5.QtCore import QEvent
        try:
            # カレンダーコンテナが無効な場合はスキップ
            if self._calendar_container is None:
                return super().eventFilter(obj, event)

            if obj == self._calendar_container and not self._is_animating:
                if event.type() == QEvent.MouseButtonPress:
                    if event.button() == Qt.LeftButton:
                        self._drag_start_x = event.globalX()
                        self._drag_start_container_x = self._calendar_container.x()
                        self._click_pos = event.pos()  # タップ検出用
                        self._is_dragging = True
                    return False
                elif event.type() == QEvent.MouseMove:
                    if self._is_dragging and self._drag_start_x is not None:
                        # ドラッグ中：カレンダーを指に追従させる
                        delta_x = event.globalX() - self._drag_start_x
                        # 移動量に制限をかける（画面外に行きすぎないように）
                        max_offset = 200
                        delta_x = max(-max_offset, min(max_offset, delta_x))
                        new_x = self._drag_start_container_x + delta_x
                        self._calendar_container.move(new_x, self._calendar_container.y())
                    return False
                elif event.type() == QEvent.MouseButtonRelease:
                    if event.button() == Qt.LeftButton and self._is_dragging:
                        delta_x = event.globalX() - self._drag_start_x
                        original_x = self._drag_start_container_x

                        if delta_x > self._swipe_threshold:
                            # 右にスワイプ → 前月へ
                            self._snap_and_change_month(original_x, is_previous=True)
                        elif delta_x < -self._swipe_threshold:
                            # 左にスワイプ → 翌月へ
                            self._snap_and_change_month(original_x, is_previous=False)
                        else:
                            # 閾値未満 → 元の位置に戻る
                            self._snap_back(original_x)

                            # タップ判定：移動が少なければ日付クリックとして処理
                            if self._click_pos is not None:
                                move_dist = (event.pos() - self._click_pos).manhattanLength()
                                if move_dist < self._click_threshold:
                                    self._handle_day_click(event.pos())

                        self._drag_start_x = None
                        self._click_pos = None
                        self._is_dragging = False
                    return False
        except RuntimeError:
            # ウィジェットが削除されている場合
            pass
        return super().eventFilter(obj, event)

    def _handle_day_click(self, pos):
        """日付セルのクリック処理"""
        # クリック位置から日付セルを特定
        import calendar as cal_module
        cal = cal_module.Calendar(firstweekday=6)
        month_days = cal.monthdayscalendar(self._display_year, self._display_month)

        for row_idx, row in enumerate(self.day_labels):
            if row_idx >= len(month_days):
                break
            for col_idx, label in enumerate(row):
                # ラベルの位置をコンテナ座標に変換
                label_pos = label.mapTo(self._calendar_container, QPoint(0, 0))
                label_rect = label.rect().translated(label_pos)
                if label_rect.contains(pos):
                    # カレンダーデータから日付を取得
                    day = month_days[row_idx][col_idx]
                    if day > 0:
                        self._on_day_clicked(self._display_year, self._display_month, day)
                    return

    def _snap_back(self, original_x):
        """元の位置にスナップバック"""
        self._slide_animation = QPropertyAnimation(self._calendar_container, b"pos")
        self._slide_animation.setDuration(150)
        self._slide_animation.setStartValue(self._calendar_container.pos())
        self._slide_animation.setEndValue(QPoint(original_x, self._calendar_container.y()))
        self._slide_animation.setEasingCurve(QEasingCurve.OutCubic)
        self._slide_animation.start()

    def _snap_and_change_month(self, original_x, is_previous):
        """スナップして月を変更 - 次のカレンダーが横からスライドイン"""
        if self._is_animating:
            return
        self._is_animating = True

        # 既存のアニメーションを停止
        if self._anim_group:
            self._anim_group.stop()
            try:
                self._anim_group.finished.disconnect()
            except:
                pass
            self._anim_group = None

        container_y = self._calendar_container.y()
        container_width = self._calendar_container.width() + 50

        # 次の月を計算
        next_year = self._display_year
        next_month = self._display_month
        if is_previous:
            next_month -= 1
            if next_month < 1:
                next_month = 12
                next_year -= 1
        else:
            next_month += 1
            if next_month > 12:
                next_month = 1
                next_year += 1

        # 次のカレンダーコンテナを作成（一時的）
        self._next_calendar_container = self._create_calendar_container()
        self._next_calendar_container.setParent(self)
        self._update_calendar_container(self._next_calendar_container, next_year, next_month)

        # 次のカレンダーの初期位置（画面外）
        if is_previous:
            next_start_x = original_x - container_width
        else:
            next_start_x = original_x + container_width

        self._next_calendar_container.move(next_start_x, container_y)
        self._next_calendar_container.show()

        # 現在のカレンダーの終了位置
        if is_previous:
            current_end_x = original_x + container_width
        else:
            current_end_x = original_x - container_width

        # 並行アニメーション
        self._anim_group = QParallelAnimationGroup()

        # 現在のカレンダーをスライドアウト
        anim_out = QPropertyAnimation(self._calendar_container, b"pos")
        anim_out.setDuration(250)
        anim_out.setStartValue(self._calendar_container.pos())
        anim_out.setEndValue(QPoint(current_end_x, container_y))
        anim_out.setEasingCurve(QEasingCurve.OutCubic)
        self._anim_group.addAnimation(anim_out)

        # 次のカレンダーをスライドイン
        anim_in = QPropertyAnimation(self._next_calendar_container, b"pos")
        anim_in.setDuration(250)
        anim_in.setStartValue(QPoint(next_start_x, container_y))
        anim_in.setEndValue(QPoint(original_x, container_y))
        anim_in.setEasingCurve(QEasingCurve.OutCubic)
        self._anim_group.addAnimation(anim_in)

        # 完了後の処理用に値を保存
        self._pending_transition = {
            'original_x': original_x,
            'next_year': next_year,
            'next_month': next_month
        }
        self._anim_group.finished.connect(self._on_slide_animation_finished)
        self._anim_group.start()

    def _on_slide_animation_finished(self):
        """スライドアニメーション完了時のハンドラ"""
        try:
            if self._pending_transition:
                self._complete_slide_transition(
                    self._pending_transition['original_x'],
                    self._pending_transition['next_year'],
                    self._pending_transition['next_month']
                )
                self._pending_transition = None
        except RuntimeError:
            # ウィジェットが削除されている場合
            self._is_animating = False
            self._pending_transition = None

    def _complete_slide_transition(self, original_x, next_year, next_month):
        """スライドトランジション完了後の処理"""
        try:
            # 月を更新
            self._display_year = next_year
            self._display_month = next_month

            # 月変更シグナルを発行
            self.monthChanged.emit(next_year, next_month)

            # 古いコンテナを削除して新しいコンテナに置き換え
            if self._next_calendar_container:
                # 古いコンテナを非表示にして後で削除
                old_container = self._calendar_container
                old_container.removeEventFilter(self)
                old_container.hide()

                # 新しいコンテナをメインに
                self._calendar_container = self._next_calendar_container
                self._calendar_container.setObjectName("calendarContainer")
                self._calendar_container.installEventFilter(self)

                # ラベル参照を更新（タイマー更新用）
                self.month_num_label = self._calendar_container.month_num_label
                self.year_label = self._calendar_container.year_label
                self.month_name_label = self._calendar_container.month_name_label
                self.prev_month_widget = self._calendar_container.prev_mini
                self.next_month_widget = self._calendar_container.next_mini
                self.day_labels = self._calendar_container.day_labels
                self.today_button = self._calendar_container.today_button

                self._next_calendar_container = None

                # 位置を確定（レイアウトのマージンに合わせて固定位置）
                self._calendar_container.move(20, self._calendar_container.y())

                # 古いコンテナを削除（遅延）
                QTimer.singleShot(100, old_container.deleteLater)
        finally:
            self._is_animating = False

    def _create_calendar_container(self):
        """カレンダーコンテナを作成"""
        container = QFrame()
        container.setObjectName("calendarContainer")
        container.setFixedSize(self._container_width, 560)  # サイズ固定（下側角丸用に余裕）
        container_layout = QVBoxLayout(container)
        container_layout.setContentsMargins(5, 0, 20, 8)
        container_layout.setSpacing(3)

        # ヘッダー部分
        header_widget = QWidget()
        header_layout = QHBoxLayout(header_widget)
        header_layout.setSpacing(10)
        header_layout.setContentsMargins(0, 0, 0, 0)

        # 月数字
        month_num_label = QLabel()
        month_num_label.setObjectName("monthNumLabel")
        month_font = QFont("Segoe UI", 60, QFont.Bold)
        month_font.setStretch(90)
        month_num_label.setFont(month_font)
        month_num_label.setFixedWidth(90)
        month_num_label.setAlignment(Qt.AlignRight | Qt.AlignBottom)
        header_layout.addWidget(month_num_label, 0, Qt.AlignBottom)

        # 年とMonth名
        year_month_widget = QWidget()
        year_month_layout = QVBoxLayout(year_month_widget)
        year_month_layout.setSpacing(0)
        year_month_layout.setContentsMargins(0, 0, 0, 0)
        year_label = QLabel()
        year_label.setObjectName("yearLabel")
        year_label.setAlignment(Qt.AlignLeft)
        year_month_layout.addWidget(year_label)
        month_name_label = QLabel()
        month_name_label.setObjectName("monthNameLabel")
        month_name_label.setAlignment(Qt.AlignLeft)
        year_month_layout.addWidget(month_name_label)
        header_layout.addWidget(year_month_widget, 0, Qt.AlignBottom)

        header_layout.addStretch()

        # ミニカレンダー（前月・翌月）
        prev_mini = self._create_mini_calendar()
        header_layout.addWidget(prev_mini, 0, Qt.AlignBottom)
        header_layout.addSpacing(10)
        next_mini = self._create_mini_calendar()
        header_layout.addWidget(next_mini, 0, Qt.AlignBottom)

        container_layout.addWidget(header_widget)

        # 区切り線
        separator = QFrame()
        separator.setFrameShape(QFrame.HLine)
        separator.setObjectName("calendarSeparator")
        separator.setFixedHeight(2)
        container_layout.addWidget(separator)

        # カレンダーグリッド（固定幅のウィジェットでラップ）
        grid_widget = QWidget()
        grid_widget.setFixedSize(600, 425)  # 7列 × 85px + マージン, 高さ=25+6*65+10
        grid_layout = QGridLayout(grid_widget)
        grid_layout.setSpacing(0)
        grid_layout.setContentsMargins(0, 0, 2, 5)

        weekday_names = ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"]
        weekday_labels = []
        for col, name in enumerate(weekday_names):
            label = QLabel(name)
            label.setAlignment(Qt.AlignCenter)
            label.setFixedSize(85, 25)
            if col == 0:
                label.setObjectName("weekdayHeaderSunday")
            elif col == 6:
                label.setObjectName("weekdayHeaderSaturday")
            else:
                label.setObjectName("weekdayHeader")
            grid_layout.addWidget(label, 0, col)
            weekday_labels.append(label)

        day_labels = []
        for row in range(6):
            row_labels = []
            for col in range(7):
                label = QLabel("")
                label.setAlignment(Qt.AlignLeft | Qt.AlignTop)
                label.setFixedSize(85, 65)
                label.setObjectName("dayCell")
                label.setProperty("row", row)
                label.setProperty("col", col)
                grid_layout.addWidget(label, row + 1, col)
                row_labels.append(label)
            day_labels.append(row_labels)

        container_layout.addWidget(grid_widget)

        # Todayボタン（当月以外の時に表示）- 絶対位置で左上に配置
        today_button = QPushButton("Today", container)  # containerの子として作成
        today_button.setObjectName("todayButton")
        today_button.setCursor(Qt.PointingHandCursor)
        today_button.setFixedSize(60, 28)
        today_button.move(10, 10)  # 左上に絶対位置で配置
        today_button.hide()  # 初期状態は非表示
        today_button.clicked.connect(self._on_today_clicked)

        # 参照を保存
        container.month_num_label = month_num_label
        container.year_label = year_label
        container.month_name_label = month_name_label
        container.prev_mini = prev_mini
        container.next_mini = next_mini
        container.day_labels = day_labels
        container.weekday_labels = weekday_labels
        container.today_button = today_button

        return container

    def _update_calendar_container(self, container, year, month):
        """カレンダーコンテナの内容を更新"""
        current_date = QDate.currentDate()
        today = current_date.day() if (year == current_date.year() and month == current_date.month()) else -1

        # Todayボタンの表示/非表示とスタイル
        is_current_month = (year == current_date.year() and month == current_date.month())
        if hasattr(container, 'today_button') and container.today_button:
            if is_current_month:
                container.today_button.hide()
            else:
                container.today_button.show()
            # テーマ変更時にスタイルを再適用
            container.today_button.setStyleSheet("""
                background-color: #e94560;
                color: #ffffff;
                font-size: 12px;
                font-weight: bold;
                border: none;
                border-radius: 14px;
                padding: 4px 10px;
            """)

        # ヘッダー更新
        container.month_num_label.setText(str(month))
        container.year_label.setText(str(year))
        locale = QLocale(QLocale.English)
        month_name = locale.monthName(month, QLocale.LongFormat)
        container.month_name_label.setText(month_name)

        # ヘッダースタイル適用（テーマ対応）
        text_primary = self._get_theme_color('text_primary')
        text_secondary = self._get_theme_color('text_secondary')
        text_tertiary = self._get_theme_color('text_tertiary')
        container_bg = self._get_theme_color('container_bg')

        container.month_num_label.setStyleSheet(f"color: {text_primary}; font-size: 80px; font-weight: bold;")
        container.year_label.setStyleSheet(f"color: {text_primary}; font-size: 22px; padding-left: 2px;")
        container.month_name_label.setStyleSheet(f"color: {text_secondary}; font-size: 20px; margin-bottom: 15px;")

        # コンテナ背景
        container.setStyleSheet(f"background-color: {container_bg}; border-radius: 10px;")

        # 曜日ヘッダーのスタイル更新
        weekday_color = self._get_theme_color('weekday_header')
        sunday_color = self._get_theme_color('sunday')
        saturday_color = self._get_theme_color('saturday')
        for i, label in enumerate(container.weekday_labels):
            if i == 0:
                label.setStyleSheet(f"color: {sunday_color}; font-size: 12px; font-weight: bold;")
            elif i == 6:
                label.setStyleSheet(f"color: {saturday_color}; font-size: 12px; font-weight: bold;")
            else:
                label.setStyleSheet(f"color: {weekday_color}; font-size: 12px; font-weight: bold;")

        # ミニカレンダー更新
        display_date = QDate(year, month, 1)
        prev_date = display_date.addMonths(-1)
        self._update_mini_calendar(container.prev_mini, prev_date.year(), prev_date.month())
        next_date = display_date.addMonths(1)
        self._update_mini_calendar(container.next_mini, next_date.year(), next_date.month())

        # カレンダーグリッド更新
        cal = calendar.Calendar(firstweekday=6)
        month_days = cal.monthdayscalendar(year, month)
        # 6行になるようにパディング
        while len(month_days) < 6:
            month_days.append([0, 0, 0, 0, 0, 0, 0])

        # テーマカラー取得
        border_color = self._get_theme_color('border')
        cell_bg = self._get_theme_color('cell_bg')
        cell_selected = self._get_theme_color('cell_selected')
        text_primary = self._get_theme_color('text_primary')
        sunday_color = self._get_theme_color('sunday')
        saturday_color = self._get_theme_color('saturday')
        today_bg = self._get_theme_color('today_bg')
        today_text = self._get_theme_color('today_text')
        badge_bg = self._get_theme_color('badge_bg')
        empty_bg = self._get_theme_color('empty_bg')

        for row_idx, week in enumerate(month_days):
            if row_idx >= 6:
                break
            for col_idx, day in enumerate(week):
                label = container.day_labels[row_idx][col_idx]

                if day != 0:
                    cell_date = date(year, month, day)
                    event_count = self._event_counts.get(cell_date, 0)
                    is_selected = self._selected_date == cell_date

                    is_holiday = self.is_holiday(year, month, day)

                    # ボーダー（上/左は隣が空または端の場合のみ）
                    trans = "transparent"
                    cell_above_empty = row_idx == 0 or month_days[row_idx - 1][col_idx] == 0
                    cell_left_empty = col_idx == 0 or week[col_idx - 1] == 0
                    top_border = border_color if cell_above_empty else trans
                    left_border = border_color if cell_left_empty else trans

                    # 色の判定（今日 > 祝日/日曜 > 土曜 > 通常）
                    if day == today:
                        text_color = today_text
                        bg_color = today_bg
                        font_weight = "font-weight: bold;"
                    elif is_holiday or col_idx == 0:
                        text_color = sunday_color
                        bg_color = cell_selected if is_selected else cell_bg
                        font_weight = ""
                    elif col_idx == 6:
                        text_color = saturday_color
                        bg_color = cell_selected if is_selected else cell_bg
                        font_weight = ""
                    else:
                        text_color = text_primary
                        bg_color = cell_selected if is_selected else cell_bg
                        font_weight = ""

                    # 日付テキスト
                    label.setText(str(day))

                    label.setStyleSheet(f"""
                        color: {text_color};
                        background-color: {bg_color};
                        {font_weight}
                        font-size: 14px;
                        padding: 2px;
                        border-top: 1px solid {top_border};
                        border-left: 1px solid {left_border};
                        border-right: 1px solid {border_color};
                        border-bottom: 1px solid {border_color};
                        border-radius: 0px;
                    """)

                    # 予定件数バッジ（既存のものを削除して再作成）
                    for child in label.findChildren(QLabel, "eventBadge"):
                        child.deleteLater()

                    if event_count > 0:
                        dot = QLabel("", label)
                        dot.setObjectName("eventBadge")
                        dot.setFixedSize(8, 8)
                        dot.setStyleSheet(f"""
                            background-color: {badge_bg};
                            border-radius: 4px;
                            border: none;
                        """)
                        dot.move(60, 10)  # 右下に配置
                        dot.show()
                else:
                    # 空セルの処理（罫線なし）
                    label.setText("")
                    for child in label.findChildren(QLabel, "eventBadge"):
                        child.deleteLater()
                    label.setStyleSheet(f"""
                        background-color: {empty_bg};
                        border: none;
                    """)

    def go_to_current_month(self):
        """当月に戻る"""
        current_date = QDate.currentDate()
        self._display_year = current_date.year()
        self._display_month = current_date.month()
        # 選択状態をクリア（今日はハイライトされるので選択不要）
        self._selected_date = None
        self.update_display()

    def _on_today_clicked(self):
        """Todayボタンクリック時の処理"""
        self.go_to_current_month()
        # 今日の日付でシグナルを発行（予定表示を今日に戻す）
        current_date = QDate.currentDate()
        self.dateClicked.emit(current_date.year(), current_date.month(), current_date.day())

    def set_event_counts(self, event_counts):
        """予定がある日付と件数を設定"""
        self._event_counts = event_counts
        self.update_display()

    def set_selected_date(self, selected_date):
        """選択中の日付を設定"""
        self._selected_date = selected_date
        self.update_display()

    def _on_day_clicked(self, year, month, day):
        """日付セルがクリックされた時の処理"""
        self._selected_date = date(year, month, day)
        self.update_display()
        self.dateClicked.emit(year, month, day)

    def _create_mini_calendar(self):
        """ミニカレンダーウィジェットを作成"""
        widget = QFrame()
        widget.setObjectName("miniCalendar")
        main_layout = QHBoxLayout(widget)
        main_layout.setContentsMargins(3, 3, 3, 3)
        main_layout.setSpacing(3)

        # 左側：月数字と年
        left_widget = QWidget()
        left_layout = QVBoxLayout(left_widget)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(0)
        left_layout.addStretch()

        # 大きな月数字
        month_num_label = QLabel()
        month_num_label.setObjectName("miniMonthNum")
        month_num_label.setAlignment(Qt.AlignCenter)
        month_num_label.setFixedWidth(30)  # 幅固定
        left_layout.addWidget(month_num_label)

        # 年
        year_label = QLabel()
        year_label.setObjectName("miniYearLabel")
        year_label.setAlignment(Qt.AlignCenter)
        left_layout.addWidget(year_label)

        left_layout.addStretch()
        main_layout.addWidget(left_widget)

        # 右側：カレンダーグリッド
        right_widget = QWidget()
        right_layout = QVBoxLayout(right_widget)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(1)

        # 曜日ヘッダー
        weekday_layout = QHBoxLayout()
        weekday_layout.setSpacing(0)
        weekday_names = ["S", "M", "T", "W", "T", "F", "S"]
        for i, name in enumerate(weekday_names):
            lbl = QLabel(name)
            lbl.setFixedSize(17, 12)
            lbl.setAlignment(Qt.AlignCenter)
            if i == 0:
                lbl.setObjectName("miniWeekdaySun")
            elif i == 6:
                lbl.setObjectName("miniWeekdaySat")
            else:
                lbl.setObjectName("miniWeekday")
            weekday_layout.addWidget(lbl)
        right_layout.addLayout(weekday_layout)

        # 日付グリッド
        grid = QGridLayout()
        grid.setSpacing(0)
        day_labels = []
        for row in range(6):
            row_labels = []
            for col in range(7):
                lbl = QLabel("")
                lbl.setFixedSize(17, 12)
                lbl.setAlignment(Qt.AlignCenter)
                lbl.setObjectName("miniDayCell")
                grid.addWidget(lbl, row, col)
                row_labels.append(lbl)
            day_labels.append(row_labels)
        right_layout.addLayout(grid)

        main_layout.addWidget(right_widget)

        widget.day_labels = day_labels
        widget.month_num_label = month_num_label
        widget.year_label = year_label
        return widget

    def _update_mini_calendar(self, widget, year, month):
        """ミニカレンダーを更新"""
        try:
            # ウィジェットが有効かチェック
            if widget is None:
                return

            # テーマカラー取得
            mini_text = self._get_theme_color('mini_text')
            sunday_color = self._get_theme_color('sunday')
            saturday_color = self._get_theme_color('saturday')

            # 月数字と年を更新
            widget.month_num_label.setText(str(month))
            widget.month_num_label.setStyleSheet(f"color: {mini_text}; font-size: 28px; font-weight: bold;")
            widget.year_label.setText(str(year))
            widget.year_label.setStyleSheet(f"color: {mini_text}; font-size: 11px;")

            # カレンダーを生成（日曜始まり）
            cal = calendar.Calendar(firstweekday=6)
            month_days = cal.monthdayscalendar(year, month)

            # 日付セルをクリア＆更新
            for row_idx, row in enumerate(widget.day_labels):
                for col_idx, label in enumerate(row):
                    if row_idx < len(month_days) and month_days[row_idx][col_idx] != 0:
                        day = month_days[row_idx][col_idx]
                        label.setText(str(day))

                        # 祝日判定
                        is_holiday = self.is_holiday(year, month, day)

                        if is_holiday or col_idx == 0:  # 祝日または日曜
                            label.setStyleSheet(f"color: {sunday_color}; font-size: 9px;")
                        elif col_idx == 6:  # 土曜
                            label.setStyleSheet(f"color: {saturday_color}; font-size: 9px;")
                        else:
                            label.setStyleSheet(f"color: {mini_text}; font-size: 9px;")
                    else:
                        label.setText("")
                        label.setStyleSheet("")
        except RuntimeError:
            # ウィジェットが削除されている場合は何もしない
            pass

    def setup_timer(self):
        """タイマーの設定（1分ごとに更新）"""
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_display)
        self.timer.start(60000)

    def update_display(self):
        """カレンダー表示の更新"""
        # アニメーション中は更新をスキップ（ラベル参照が無効な可能性があるため）
        if self._is_animating:
            return

        # ラベル参照が有効かチェック
        try:
            if self.month_num_label is None:
                return
        except (RuntimeError, AttributeError):
            # ウィジェットが削除されている場合
            return

        try:
            # 共通の更新処理を呼び出し
            self._update_calendar_container(self._calendar_container, self._display_year, self._display_month)
        except RuntimeError:
            # ウィジェットが削除されている場合は何もしない
            pass


