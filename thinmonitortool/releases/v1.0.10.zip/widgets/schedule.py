# -*- coding: utf-8 -*-
"""スケジュールウィジェット"""

import threading
from datetime import date, timedelta

from PyQt5.QtWidgets import (
    QFrame, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QScrollArea
)
from PyQt5.QtCore import Qt, QTimer, QDate, pyqtSignal
from PyQt5.QtGui import QPainter, QColor, QPixmap

from .deck import PageIndicator

class TouchScrollArea(QScrollArea):
    """タッチ対応スクロールエリア（慣性スクロール付き）"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._drag_start_y = None
        self._last_y = None
        self._velocity = 0
        self._is_dragging = False
        self._scroll_indicator = None

        # 慣性スクロール用タイマー
        self._kinetic_timer = QTimer(self)
        self._kinetic_timer.timeout.connect(self._do_kinetic_scroll)
        self._kinetic_timer.setInterval(16)  # 60fps

        # 速度履歴（慣性計算用）
        self._velocity_history = []
        self._last_time = None

        # スクロールバーを非表示
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

    def set_scroll_indicator(self, indicator):
        """スクロールインジケータを設定"""
        self._scroll_indicator = indicator

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._drag_start_y = event.y()
            self._last_y = event.y()
            self._is_dragging = True
            self._velocity = 0
            self._velocity_history = []
            self._last_time = event.timestamp()
            self._kinetic_timer.stop()
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self._is_dragging and self._last_y is not None:
            delta_y = self._last_y - event.y()
            scrollbar = self.verticalScrollBar()
            scrollbar.setValue(scrollbar.value() + delta_y)

            # 速度計算
            current_time = event.timestamp()
            if self._last_time:
                dt = current_time - self._last_time
                if dt > 0:
                    velocity = delta_y / dt * 16  # 16msあたりの速度に正規化
                    self._velocity_history.append(velocity)
                    # 直近5個の速度を保持
                    if len(self._velocity_history) > 5:
                        self._velocity_history.pop(0)

            self._last_y = event.y()
            self._last_time = current_time
            self._update_indicator()
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton and self._is_dragging:
            self._is_dragging = False

            # 平均速度を計算
            if self._velocity_history:
                self._velocity = sum(self._velocity_history) / len(self._velocity_history)
                # 速度が十分なら慣性スクロール開始
                if abs(self._velocity) > 0.5:
                    self._kinetic_timer.start()
            self._drag_start_y = None
            self._last_y = None
        super().mouseReleaseEvent(event)

    def _do_kinetic_scroll(self):
        """慣性スクロールを実行"""
        if abs(self._velocity) < 0.3:
            self._kinetic_timer.stop()
            return

        scrollbar = self.verticalScrollBar()
        new_value = scrollbar.value() + int(self._velocity)

        # 境界チェック
        if new_value < scrollbar.minimum():
            new_value = scrollbar.minimum()
            self._velocity = 0
        elif new_value > scrollbar.maximum():
            new_value = scrollbar.maximum()
            self._velocity = 0

        scrollbar.setValue(new_value)
        self._update_indicator()

        # 減速（摩擦）
        self._velocity *= 0.92

    def _update_indicator(self):
        """スクロールインジケータを更新（ページ位置ベース）"""
        if self._scroll_indicator:
            scrollbar = self.verticalScrollBar()
            max_val = scrollbar.maximum()
            if max_val > 0:
                ratio = scrollbar.value() / max_val
            else:
                ratio = 0
            self._scroll_indicator.set_position(ratio)

    def wheelEvent(self, event):
        """マウスホイールでもスクロール"""
        super().wheelEvent(event)
        self._update_indicator()


class PageIndicator(QWidget):
    """iOS風ドットインジケータ"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._total_dots = 3  # ドット数
        self._current_position = 0.0  # 0.0 - 1.0
        self.setFixedSize(30, 80)

    def set_total_dots(self, count):
        """ドット数を設定"""
        self._total_dots = max(2, count)
        self.update()

    def set_position(self, ratio):
        """スクロール位置を設定（0.0-1.0）"""
        self._current_position = max(0.0, min(1.0, ratio))
        self.update()

    def paintEvent(self, event):
        if self._total_dots < 2:
            return

        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        dot_radius = 3
        dot_spacing = 12
        total_height = (self._total_dots - 1) * dot_spacing

        # 中央揃え
        start_y = (self.height() - total_height) / 2

        # 現在のアクティブドットインデックス（0〜total_dots-1の実数）
        active_index = self._current_position * (self._total_dots - 1)

        for i in range(self._total_dots):
            y = start_y + i * dot_spacing
            x = self.width() / 2

            # アクティブドットからの距離で透明度を決定
            distance = abs(i - active_index)
            if distance < 1:
                # アクティブまたは隣接
                alpha = int(255 * (1 - distance * 0.6))
                radius = dot_radius + (1 - distance) * 2
            else:
                alpha = 100
                radius = dot_radius

            painter.setPen(Qt.NoPen)
            painter.setBrush(QColor(255, 255, 255, alpha))
            painter.drawEllipse(int(x - radius), int(y - radius), int(radius * 2), int(radius * 2))


class ScheduleWidget(QFrame):
    """Googleカレンダー予定表示ウィジェット"""

    # 曜日の日本語表記
    WEEKDAY_NAMES = ["月曜日", "火曜日", "水曜日", "木曜日", "金曜日", "土曜日", "日曜日"]

    # 予定取得完了シグナル（イベント日付と件数の辞書を送信）
    eventsLoaded = pyqtSignal(dict)
    # 追加取得完了シグナル（内部用）
    _additionalEventsReady = pyqtSignal(list, int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("scheduleWidget")
        self._events = []  # 表示中の予定リスト
        self._all_events = []  # 全予定リスト（フィルタ前）
        self._selected_date = date.today()  # 選択中の日付
        self._fetched_until = None  # 取得済み最終日
        self._display_year = None  # カレンダー表示中の年
        self._display_month = None  # カレンダー表示中の月
        self._border_radius = 12
        self._calendar_service = None
        self._is_authenticated = False
        # 追加取得完了シグナルを接続
        self._additionalEventsReady.connect(self._merge_events)
        # 背景画像を読み込み
        self._bg_pixmap = None
        self._load_background()
        self.setup_ui()
        self.setup_calendar()
        self.setup_refresh_timer()

    def _load_background(self):
        """背景画像を読み込み"""
        from PyQt5.QtGui import QPixmap
        from pathlib import Path
        schedule_path = Path(__file__).parent.parent / "schedule.png"
        self._bg_pixmap = QPixmap(str(schedule_path))

    def paintEvent(self, event):
        """カスタム描画で滑らかな角丸を実現"""
        from PyQt5.QtGui import QPainterPath, QBrush, QLinearGradient
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing, True)
        painter.setRenderHint(QPainter.SmoothPixmapTransform, True)

        # 角丸パスを作成
        path = QPainterPath()
        path.addRoundedRect(0, 0, self.width(), self.height(),
                           self._border_radius, self._border_radius)
        painter.setClipPath(path)

        # 背景画像を描画
        if self._bg_pixmap and not self._bg_pixmap.isNull():
            scaled = self._bg_pixmap.scaled(
                self.size(),
                Qt.KeepAspectRatioByExpanding,
                Qt.SmoothTransformation
            )
            x = (self.width() - scaled.width()) // 2
            y = (self.height() - scaled.height()) // 2
            painter.drawPixmap(x, y, scaled)

        # グラデーションオーバーレイ
        gradient = QLinearGradient(0, 0, self.width(), 0)
        gradient.setColorAt(0, QColor(0, 0, 0, 220))      # 86%
        gradient.setColorAt(0.4, QColor(0, 0, 0, 180))    # 70%
        gradient.setColorAt(1, QColor(0, 0, 0, 150))      # 59%
        painter.fillPath(path, QBrush(gradient))

    def setup_ui(self):
        """UIの初期化"""
        # オーバーレイ用のレイアウト
        outer_layout = QVBoxLayout(self)
        outer_layout.setContentsMargins(0, 0, 0, 0)

        # 暗いオーバーレイ
        overlay = QFrame()
        overlay.setObjectName("scheduleOverlay")
        main_layout = QHBoxLayout(overlay)
        main_layout.setContentsMargins(20, 13, 20, 13)
        main_layout.setSpacing(20)

        outer_layout.addWidget(overlay)

        # 左側: 日付表示
        date_widget = QWidget()
        date_widget.setStyleSheet("background: transparent;")
        date_layout = QVBoxLayout(date_widget)
        date_layout.setContentsMargins(0, 0, 0, 0)
        date_layout.setSpacing(0)
        date_layout.setAlignment(Qt.AlignCenter)

        # 大きな日付数字
        current_date = QDate.currentDate()
        self.day_label = QLabel(str(current_date.day()))
        self.day_label.setObjectName("scheduleDayNum")
        self.day_label.setAlignment(Qt.AlignCenter)
        date_layout.addWidget(self.day_label)

        # 曜日
        weekday_idx = current_date.dayOfWeek() - 1  # Qt: 1=月曜
        self.weekday_label = QLabel(self.WEEKDAY_NAMES[weekday_idx])
        self.weekday_label.setObjectName("scheduleWeekday")
        self.weekday_label.setAlignment(Qt.AlignCenter)
        date_layout.addWidget(self.weekday_label)

        date_widget.setFixedWidth(100)
        main_layout.addWidget(date_widget)

        # 区切り線
        separator = QFrame()
        separator.setFrameShape(QFrame.VLine)
        separator.setObjectName("scheduleSeparator")
        main_layout.addWidget(separator)

        # 右側: 予定リスト
        right_widget = QWidget()
        right_widget.setStyleSheet("background: transparent;")
        right_layout = QHBoxLayout(right_widget)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(8)

        # スクロールエリア（タッチ対応）
        self.scroll_area = TouchScrollArea()
        self.scroll_area.setObjectName("scheduleScrollArea")
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setStyleSheet("background: transparent;")
        self.scroll_area.viewport().setStyleSheet("background: transparent;")

        # 予定リストコンテナ
        self.events_container = QWidget()
        self.events_container.setStyleSheet("background: transparent;")
        self.events_layout = QVBoxLayout(self.events_container)
        self.events_layout.setContentsMargins(0, 0, 0, 0)
        self.events_layout.setSpacing(4)  # 間隔を詰める
        self.events_layout.addStretch()

        self.scroll_area.setWidget(self.events_container)
        right_layout.addWidget(self.scroll_area, 1)

        # ドットインジケータ
        self.page_indicator = PageIndicator()
        self.page_indicator.setStyleSheet("background: transparent;")
        self.scroll_area.set_scroll_indicator(self.page_indicator)
        right_layout.addWidget(self.page_indicator)

        main_layout.addWidget(right_widget, 1)

        # 予定なし表示
        self._show_no_events()

    def _clear_events(self):
        """既存のアイテムをクリア"""
        while self.events_layout.count() > 1:  # stretchを残す
            item = self.events_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

    def _show_no_events(self):
        """予定なしメッセージを表示"""
        self._clear_events()
        placeholder = QLabel("本日の予定はありません")
        placeholder.setObjectName("scheduleNoEvents")
        placeholder.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.events_layout.insertWidget(0, placeholder)
        if hasattr(self, 'page_indicator'):
            self.page_indicator.hide()

    def _create_event_item(self, time_str: str, title: str, color: str = "#4285f4", date_label: str = ""):
        """予定アイテムを作成"""
        item = QFrame()
        item.setObjectName("scheduleEventItem")
        item_layout = QHBoxLayout(item)
        item_layout.setContentsMargins(10, 8, 10, 8)
        item_layout.setSpacing(12)

        # カラーバー
        color_bar = QFrame()
        color_bar.setFixedSize(4, 40)
        color_bar.setStyleSheet(f"background-color: {color}; border-radius: 2px;")
        item_layout.addWidget(color_bar)

        # テキスト部分
        text_layout = QVBoxLayout()
        text_layout.setSpacing(2)

        title_label = QLabel(title)
        title_label.setObjectName("scheduleEventTitle")
        title_label.setWordWrap(True)
        text_layout.addWidget(title_label)

        # 日付ラベル + 時刻
        if date_label:
            time_with_date = f"{date_label}  {time_str}"
        else:
            time_with_date = time_str
        time_label = QLabel(time_with_date)
        time_label.setObjectName("scheduleEventTime")
        text_layout.addWidget(time_label)

        item_layout.addLayout(text_layout)
        item_layout.addStretch()

        return item

    def set_events(self, events: list, store_all=True):
        """予定を設定"""
        self._clear_events()

        if store_all:
            self._all_events = events
            # イベント日付と件数を集計してシグナルを発行
            event_counts = {}
            for e in events:
                d = e.get('date')
                if d:
                    event_counts[d] = event_counts.get(d, 0) + 1
            self.eventsLoaded.emit(event_counts)

        self._events = events

        if not events:
            self._show_no_events()
            self.page_indicator.hide()
            return

        # 予定を追加
        for event in events:
            item = self._create_event_item(
                event.get('time', ''),
                event.get('title', ''),
                event.get('color', '#4285f4'),
                event.get('date_label', '')
            )
            self.events_layout.insertWidget(self.events_layout.count() - 1, item)

        # ページインジケータの更新を遅延実行（レイアウト確定後）
        QTimer.singleShot(100, self._update_page_indicator)

    def _update_page_indicator(self):
        """ページインジケータを更新（コンテンツ高さベース）"""
        viewport_height = self.scroll_area.viewport().height()
        content_height = self.events_container.sizeHint().height()

        if viewport_height <= 0 or content_height <= viewport_height:
            # スクロール不要な場合はインジケータ非表示
            self.page_indicator.hide()
        else:
            # ページ数を計算（ビューポート高さ単位）
            page_count = max(2, min(6, (content_height + viewport_height - 1) // viewport_height))
            self.page_indicator.set_total_dots(page_count)
            self.page_indicator.set_position(0)
            self.page_indicator.show()

    def select_date(self, year, month, day):
        """指定した日付の予定を表示（選択日+翌日の2日分）"""
        from datetime import timedelta
        selected = date(year, month, day)
        next_day = selected + timedelta(days=1)
        self._selected_date = selected

        # 日付表示を更新
        self.day_label.setText(str(day))
        weekday_idx = selected.weekday()  # 0=月曜
        self.weekday_label.setText(self.WEEKDAY_NAMES[weekday_idx])

        # 選択日と翌日の予定をフィルタリング（コピーを作成）
        filtered_events = []
        for e in self._all_events:
            event_date = e.get('date')
            if event_date == selected:
                event_copy = e.copy()
                event_copy['date_label'] = ''  # 選択日はラベル不要
                filtered_events.append(event_copy)
            elif event_date == next_day:
                event_copy = e.copy()
                event_copy['date_label'] = '明日'  # 翌日ラベル
                filtered_events.append(event_copy)

        self.set_events(filtered_events, store_all=False)

    def get_event_dates(self):
        """予定がある日付のセットを取得"""
        return set(e.get('date') for e in self._all_events if e.get('date'))

    def add_sample_events(self):
        """サンプル予定を追加（テスト用）"""
        sample_events = [
            {'time': '09:00 - 10:00', 'title': 'チームミーティング', 'color': '#4285f4'},
            {'time': '11:00 - 12:00', 'title': 'プロジェクトレビュー', 'color': '#0f9d58'},
            {'time': '14:00 - 15:30', 'title': 'クライアント打ち合わせ', 'color': '#db4437'},
            {'time': '16:00 - 17:00', 'title': '週次報告', 'color': '#f4b400'},
        ]
        self.set_events(sample_events)

    def setup_calendar(self):
        """Google Calendar認証を設定"""
        try:
            from google_calendar import get_calendar_service
            self._calendar_service = get_calendar_service()
            print("Google Calendar: サービス初期化完了")
            # バックグラウンドで認証
            threading.Thread(target=self._authenticate_and_fetch, daemon=True).start()
        except ImportError as e:
            print(f"Google Calendar module not found: {e}")
        except Exception as e:
            print(f"Google Calendar setup error: {e}")

    def _authenticate_and_fetch(self):
        """認証して予定を取得（バックグラウンド）"""
        try:
            print("Google Calendar: 認証開始...")
            if self._calendar_service:
                self._calendar_service.authenticate()
                self._is_authenticated = True
                print("Google Calendar: 認証成功")
                # メインスレッドでUI更新
                QTimer.singleShot(0, self.fetch_events)
        except FileNotFoundError as e:
            print(f"Google Calendar認証エラー: {e}")
        except Exception as e:
            print(f"Google Calendar接続エラー: {e}")
            import traceback
            traceback.print_exc()

    def setup_refresh_timer(self):
        """予定を定期更新するタイマーを設定"""
        self._refresh_timer = QTimer(self)
        self._refresh_timer.timeout.connect(self.fetch_events)
        self._refresh_timer.start(300000)  # 5分ごとに更新

    def fetch_events(self):
        """Google Calendarから予定を取得（90日分 + 表示月）"""
        import sys
        print(f"[DEBUG] fetch_events: authenticated={self._is_authenticated}", file=sys.stderr)
        if not self._is_authenticated or not self._calendar_service:
            return

        try:
            import calendar as cal_module

            # 90日後の月末までを基本とする
            base_date = date.today() + timedelta(days=90)
            base_month_end = date(base_date.year, base_date.month,
                                  cal_module.monthrange(base_date.year, base_date.month)[1])
            base_days = (base_month_end - date.today()).days + 1
            print(f"[DEBUG] 基本取得: 90日後({base_date})の月末({base_month_end})まで = {base_days}日分", file=sys.stderr)

            # 表示月がある場合、その月末までの日数を計算
            if self._display_year and self._display_month:
                last_day = cal_module.monthrange(self._display_year, self._display_month)[1]
                display_month_end = date(self._display_year, self._display_month, last_day)
                days_to_display_month = (display_month_end - date.today()).days + 1

                # 表示月の方が遠ければそちらを使用
                if days_to_display_month > base_days:
                    fetch_days = days_to_display_month
                    print(f"[DEBUG] 表示月({self._display_year}/{self._display_month})まで取得: {fetch_days}日分", file=sys.stderr)
                else:
                    fetch_days = base_days
            else:
                fetch_days = base_days

            events = self._calendar_service.get_events(days=fetch_days)
            print(f"[DEBUG] 取得した予定: {len(events)}件", file=sys.stderr)
            self.set_events(events)

            # 取得済み最終日を記録
            self._fetched_until = date.today() + timedelta(days=fetch_days)
            print(f"[DEBUG] 取得済み範囲: 今日 〜 {self._fetched_until}", file=sys.stderr)

            # 今日の予定だけを表示
            today = date.today()
            self.select_date(today.year, today.month, today.day)
        except Exception as e:
            print(f"予定取得エラー: {e}")
            import traceback
            traceback.print_exc()

    def fetch_events_for_month(self, year, month):
        """指定月の予定を追加取得（未取得の場合のみ）"""
        import sys
        print(f"[DEBUG] fetch_events_for_month called: {year}/{month}", file=sys.stderr)
        print(f"[DEBUG] authenticated={self._is_authenticated}, fetched_until={self._fetched_until}", file=sys.stderr)

        # 表示月を記録
        self._display_year = year
        self._display_month = month

        if not self._is_authenticated or not self._calendar_service:
            print(f"[DEBUG] スキップ: 未認証", file=sys.stderr)
            return

        # その月の最終日を計算
        import calendar as cal_module
        last_day = cal_module.monthrange(year, month)[1]
        month_end = date(year, month, last_day)

        # すでに取得済みならスキップ
        if self._fetched_until and month_end <= self._fetched_until:
            print(f"[DEBUG] 月 {year}/{month} は取得済み（〜{self._fetched_until}）", file=sys.stderr)
            return

        # 取得開始日を決定（取得済み最終日の翌日 or 今日）
        if self._fetched_until:
            start_date = self._fetched_until + timedelta(days=1)
        else:
            start_date = date.today()

        # 取得日数を計算（月末まで + 余裕を持って30日）
        days_to_fetch = (month_end - start_date).days + 30
        if days_to_fetch <= 0:
            return

        import sys
        print(f"[DEBUG] 追加取得開始: {start_date} から {days_to_fetch} 日分", file=sys.stderr)

        try:
            # バックグラウンドで取得
            threading.Thread(
                target=self._fetch_additional_events,
                args=(start_date, days_to_fetch),
                daemon=True
            ).start()
        except Exception as e:
            print(f"追加取得エラー: {e}")

    def _fetch_additional_events(self, start_date, days):
        """追加の予定を取得（バックグラウンド）"""
        import sys
        try:
            # google_calendarに開始日指定の取得メソッドがないため、
            # 全期間を再取得して既存データとマージ
            total_days = (start_date - date.today()).days + days
            print(f"[DEBUG] 追加取得中: total_days={total_days}", file=sys.stderr)
            events = self._calendar_service.get_events(days=total_days)
            print(f"[DEBUG] 追加取得完了: {len(events)}件", file=sys.stderr)

            # シグナルでメインスレッドに通知
            self._additionalEventsReady.emit(events, total_days)
        except Exception as e:
            print(f"[DEBUG] 追加取得エラー: {e}", file=sys.stderr)
            import traceback
            traceback.print_exc(file=sys.stderr)

    def _merge_events(self, new_events, total_days):
        """新しい予定をマージしてUIを更新"""
        import sys
        print(f"[DEBUG] _merge_events: {len(new_events)}件をマージ", file=sys.stderr)

        # 既存のイベントをタイトル+日付+時刻でインデックス化（より正確な重複チェック）
        existing_keys = set()
        for e in self._all_events:
            key = (e.get('date'), e.get('time'), e.get('title'))
            existing_keys.add(key)

        # 新しいイベントを追加（重複除外）
        added = 0
        for event in new_events:
            key = (event.get('date'), event.get('time'), event.get('title'))
            if key not in existing_keys:
                self._all_events.append(event)
                existing_keys.add(key)
                added += 1

        # 日付順にソート
        self._all_events.sort(key=lambda x: x.get('date', date.max))

        # 取得済み最終日を更新
        self._fetched_until = date.today() + timedelta(days=total_days)
        print(f"[DEBUG] マージ完了: {added}件追加、取得済み範囲 〜 {self._fetched_until}", file=sys.stderr)

        # イベント件数を再集計してシグナル発行
        event_counts = {}
        for e in self._all_events:
            d = e.get('date')
            if d:
                event_counts[d] = event_counts.get(d, 0) + 1
        print(f"[DEBUG] eventsLoaded発行: {len(event_counts)}日分", file=sys.stderr)
        self.eventsLoaded.emit(event_counts)


