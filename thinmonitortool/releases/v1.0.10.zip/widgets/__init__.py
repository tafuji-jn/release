# -*- coding: utf-8 -*-
"""ウィジェットパッケージ"""

from .common import load_transparent_icon
from .clock import FlipDigitWidget, ClockWidget
from .menu import SlideMenu
from .deck import DeckButton, SwipeableButtonArea, PageIndicator

# 遅延インポート（循環参照回避）
def get_calendar_widget():
    from .calendar import CalendarWidget
    return CalendarWidget

def get_schedule_widget():
    from .schedule import ScheduleWidget, TouchScrollArea
    return ScheduleWidget

def get_spotify_widget():
    from .spotify import SpotifyWidget, TouchFriendlySlider
    return SpotifyWidget
