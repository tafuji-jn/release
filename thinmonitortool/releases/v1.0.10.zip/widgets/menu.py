# -*- coding: utf-8 -*-
"""スライドメニューウィジェット"""

from PyQt5.QtWidgets import (
    QFrame, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QWidget, QScrollArea
)
from PyQt5.QtCore import Qt, QPoint, QPropertyAnimation, QEasingCurve, pyqtSignal, QTimer
import threading


class SlideMenu(QFrame):
    """左からスライドインするメニュー"""

    themeChanged = pyqtSignal(str)  # 'light' or 'dark'
    rebootRequested = pyqtSignal()  # 端末再起動リクエスト
    googleAuthRequested = pyqtSignal()  # Google再認証リクエスト
    spotifyAuthRequested = pyqtSignal()  # Spotify再認証リクエスト
    bluetoothDeviceChanged = pyqtSignal(str)  # Bluetooth接続先変更
    audioOutputChanged = pyqtSignal(str)  # 音声出力先変更
    updateCheckRequested = pyqtSignal()  # アプリ更新チェックリクエスト

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("slideMenu")
        self._is_visible = False
        self._menu_width = 250
        self._submenu_width = 200
        self._bt_device_buttons = []  # Bluetoothデバイスボタンのリスト
        self._current_bt_address = None
        self._submenu = None  # サブメニューパネル
        self._submenu_visible = False
        self.setup_ui()
        self._setup_submenu()

    def setup_ui(self):
        """UIの初期化"""
        self.setFixedWidth(self._menu_width)
        self.setStyleSheet("""
            #slideMenu {
                background-color: rgba(30, 30, 30, 0.95);
                border-right: 1px solid #444;
            }
            #menuTitle {
                color: #ffffff;
                font-size: 18px;
                font-weight: bold;
                padding: 15px;
            }
            #menuItem {
                color: #ffffff;
                font-size: 14px;
                padding: 12px 20px;
                border: none;
                text-align: left;
            }
            #menuItem:hover {
                background-color: rgba(255, 255, 255, 0.1);
            }
            #menuItem:pressed {
                background-color: rgba(255, 255, 255, 0.2);
            }
            #menuItemActive {
                color: #ffffff;
                font-size: 14px;
                padding: 12px 20px;
                border: none;
                text-align: left;
                background-color: rgba(233, 69, 96, 0.8);
            }
            #sectionLabel {
                color: #888888;
                font-size: 12px;
                padding: 15px 20px 5px 20px;
            }
        """)

        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # タイトル（固定）
        title = QLabel("設定")
        title.setObjectName("menuTitle")
        main_layout.addWidget(title)

        # スクロールエリア（タッチスクロール対応）
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setStyleSheet("QScrollArea { background: transparent; }")
        # タッチ・ドラッグでスクロール可能に
        from PyQt5.QtWidgets import QScroller
        QScroller.grabGesture(scroll.viewport(), QScroller.LeftMouseButtonGesture)

        # スクロール内のコンテンツ
        scroll_content = QWidget()
        scroll_content.setStyleSheet("background: transparent;")
        layout = QVBoxLayout(scroll_content)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # セクション: テーマ
        theme_label = QLabel("カレンダーテーマ")
        theme_label.setObjectName("sectionLabel")
        layout.addWidget(theme_label)

        # ライトテーマボタン
        self.light_btn = QPushButton("☀️  ライト（白基調）")
        self.light_btn.setObjectName("menuItemActive")
        self.light_btn.clicked.connect(lambda: self._on_theme_selected('light'))
        layout.addWidget(self.light_btn)

        # ダークテーマボタン
        self.dark_btn = QPushButton("🌙  ダーク（黒基調）")
        self.dark_btn.setObjectName("menuItem")
        self.dark_btn.clicked.connect(lambda: self._on_theme_selected('dark'))
        layout.addWidget(self.dark_btn)

        # セクション: アカウント連携
        account_label = QLabel("アカウント連携")
        account_label.setObjectName("sectionLabel")
        layout.addWidget(account_label)

        # Google認証ボタン
        self.google_auth_btn = QPushButton("📅  Google カレンダー認証")
        self.google_auth_btn.setObjectName("menuItem")
        self.google_auth_btn.clicked.connect(self._on_google_auth_clicked)
        layout.addWidget(self.google_auth_btn)

        # Spotify認証ボタン
        self.spotify_auth_btn = QPushButton("🎵  Spotify 認証")
        self.spotify_auth_btn.setObjectName("menuItem")
        self.spotify_auth_btn.clicked.connect(self._on_spotify_auth_clicked)
        layout.addWidget(self.spotify_auth_btn)

        # セクション: Bluetooth
        bt_label = QLabel("Bluetooth接続先")
        bt_label.setObjectName("sectionLabel")
        layout.addWidget(bt_label)

        # Bluetoothデバイスリスト用コンテナ
        self._bt_container = QWidget()
        self._bt_layout = QVBoxLayout(self._bt_container)
        self._bt_layout.setContentsMargins(0, 0, 0, 0)
        self._bt_layout.setSpacing(0)
        layout.addWidget(self._bt_container)

        # ペアリングモードボタン（PC側から見つけられるようにする）
        self._bt_pairing_btn = QPushButton("📡  ペアリングモード")
        self._bt_pairing_btn.setObjectName("menuItem")
        self._bt_pairing_btn.clicked.connect(self._on_bt_pairing_mode_clicked)
        layout.addWidget(self._bt_pairing_btn)

        # セクション: 音声出力
        audio_label = QLabel("音声出力")
        audio_label.setObjectName("sectionLabel")
        layout.addWidget(audio_label)

        # 音声出力ボタン用コンテナ
        self._audio_container = QWidget()
        self._audio_layout = QVBoxLayout(self._audio_container)
        self._audio_layout.setContentsMargins(0, 0, 0, 0)
        self._audio_layout.setSpacing(0)
        layout.addWidget(self._audio_container)
        self._audio_buttons = []

        # セクション: システム
        system_label = QLabel("システム")
        system_label.setObjectName("sectionLabel")
        layout.addWidget(system_label)

        # アプリ更新チェックボタン
        self.update_check_btn = QPushButton("🔄  アプリ更新チェック")
        self.update_check_btn.setObjectName("menuItem")
        self.update_check_btn.clicked.connect(self._on_update_check_clicked)
        layout.addWidget(self.update_check_btn)

        # 端末再起動ボタン
        self.reboot_btn = QPushButton("🔄  端末を再起動")
        self.reboot_btn.setObjectName("menuItem")
        self.reboot_btn.setStyleSheet("""
            QPushButton {
                color: #ff6b6b;
                font-size: 14px;
                padding: 12px 20px;
                border: none;
                text-align: left;
                background: transparent;
            }
            QPushButton:hover {
                background-color: rgba(255, 107, 107, 0.2);
            }
            QPushButton:pressed {
                background-color: rgba(255, 107, 107, 0.3);
            }
        """)
        self.reboot_btn.clicked.connect(self._on_reboot_clicked)
        layout.addWidget(self.reboot_btn)

        # 端末シャットダウンボタン
        self.shutdown_btn = QPushButton("⏻  端末をシャットダウン")
        self.shutdown_btn.setObjectName("menuItem")
        self.shutdown_btn.setStyleSheet("""
            QPushButton {
                color: #ff6b6b;
                font-size: 14px;
                padding: 12px 20px;
                border: none;
                text-align: left;
                background: transparent;
            }
            QPushButton:hover {
                background-color: rgba(255, 107, 107, 0.2);
            }
            QPushButton:pressed {
                background-color: rgba(255, 107, 107, 0.3);
            }
        """)
        self.shutdown_btn.clicked.connect(self._on_shutdown_clicked)
        layout.addWidget(self.shutdown_btn)

        # 閉じるヒント
        hint = QLabel("← スワイプで閉じる")
        hint.setObjectName("sectionLabel")
        hint.setAlignment(Qt.AlignCenter)
        layout.addWidget(hint)

        # スクロールエリアにコンテンツをセット
        scroll.setWidget(scroll_content)
        main_layout.addWidget(scroll)

        # 初期状態: 画面外に配置
        self.move(-self._menu_width, 0)

    def _on_theme_selected(self, theme):
        """テーマ選択時"""
        self._update_button_states(theme)
        self.themeChanged.emit(theme)

    def _on_reboot_clicked(self):
        """再起動ボタンクリック時"""
        from PyQt5.QtWidgets import QMessageBox
        msg = QMessageBox()
        msg.setWindowTitle("端末再起動")
        msg.setText("端末を再起動しますか？")
        msg.setIcon(QMessageBox.Warning)
        msg.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        msg.setDefaultButton(QMessageBox.No)
        msg.button(QMessageBox.Yes).setText("再起動")
        msg.button(QMessageBox.No).setText("キャンセル")
        msg.setStyleSheet("""
            QMessageBox {
                background-color: #2a2a2a;
            }
            QMessageBox QLabel {
                color: #ffffff;
                font-size: 14px;
            }
            QPushButton {
                background-color: #444;
                color: #fff;
                border: none;
                border-radius: 4px;
                padding: 8px 20px;
                font-size: 14px;
                min-width: 80px;
            }
            QPushButton:hover {
                background-color: #555;
            }
        """)

        if msg.exec_() == QMessageBox.Yes:
            import subprocess
            subprocess.run(['sudo', 'reboot'])

    def _on_shutdown_clicked(self):
        """シャットダウンボタンクリック時"""
        from PyQt5.QtWidgets import QMessageBox
        msg = QMessageBox()
        msg.setWindowTitle("端末シャットダウン")
        msg.setText("端末をシャットダウンしますか？")
        msg.setIcon(QMessageBox.Warning)
        msg.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        msg.setDefaultButton(QMessageBox.No)
        msg.button(QMessageBox.Yes).setText("シャットダウン")
        msg.button(QMessageBox.No).setText("キャンセル")
        msg.setStyleSheet("""
            QMessageBox {
                background-color: #2a2a2a;
            }
            QMessageBox QLabel {
                color: #ffffff;
                font-size: 14px;
            }
            QPushButton {
                background-color: #444;
                color: #fff;
                border: none;
                border-radius: 4px;
                padding: 8px 20px;
                font-size: 14px;
                min-width: 80px;
            }
            QPushButton:hover {
                background-color: #555;
            }
        """)

        if msg.exec_() == QMessageBox.Yes:
            import subprocess
            subprocess.run(['sudo', 'shutdown', '-h', 'now'])

    def set_current_theme(self, theme):
        """現在のテーマ状態を設定（シグナルなし）"""
        self._update_button_states(theme)

    def _update_button_states(self, theme):
        """ボタンの選択状態を更新"""
        if theme == 'light':
            self.light_btn.setObjectName("menuItemActive")
            self.dark_btn.setObjectName("menuItem")
        else:
            self.light_btn.setObjectName("menuItem")
            self.dark_btn.setObjectName("menuItemActive")
        # スタイル再適用
        self.light_btn.setStyle(self.light_btn.style())
        self.dark_btn.setStyle(self.dark_btn.style())

    def show_menu(self):
        """メニューを表示"""
        if self._is_visible:
            return
        self._is_visible = True

        # Bluetooth接続状態を更新
        self.refresh_bt_devices()
        # 音声出力デバイスを更新
        self.refresh_audio_outputs()

        self.show()
        self.raise_()

        self._anim = QPropertyAnimation(self, b"pos")
        self._anim.setDuration(200)
        self._anim.setStartValue(QPoint(-self._menu_width, 0))
        self._anim.setEndValue(QPoint(0, 0))
        self._anim.setEasingCurve(QEasingCurve.OutCubic)
        self._anim.start()

    def hide_menu(self):
        """メニューを非表示"""
        if not self._is_visible:
            return
        self._is_visible = False

        # サブメニューも閉じる
        self._hide_submenu()

        self._anim = QPropertyAnimation(self, b"pos")
        self._anim.setDuration(200)
        self._anim.setStartValue(self.pos())
        self._anim.setEndValue(QPoint(-self._menu_width, 0))
        self._anim.setEasingCurve(QEasingCurve.InCubic)
        self._anim.finished.connect(self.hide)
        self._anim.start()

    def is_menu_visible(self):
        return self._is_visible

    def _on_google_auth_clicked(self):
        """Google認証ボタンクリック時"""
        self.googleAuthRequested.emit()

    def _on_spotify_auth_clicked(self):
        """Spotify認証ボタンクリック時"""
        self.spotifyAuthRequested.emit()

    def _on_update_check_clicked(self):
        """更新チェックボタンクリック時"""
        print("Menu: 更新チェックボタン押下", flush=True)
        self.updateCheckRequested.emit()

    def update_auth_status(self, service, is_authenticated):
        """認証ステータスを更新してボタンの表示を変更"""
        if service == 'google':
            if is_authenticated:
                self.google_auth_btn.setText("📅  Google カレンダー (認証済)")
                self.google_auth_btn.setStyleSheet("""
                    QPushButton {
                        color: #4caf50;
                        font-size: 14px;
                        padding: 12px 20px;
                        border: none;
                        text-align: left;
                        background: transparent;
                    }
                    QPushButton:hover {
                        background-color: rgba(76, 175, 80, 0.2);
                    }
                """)
            else:
                self.google_auth_btn.setText("📅  Google カレンダー認証")
                self.google_auth_btn.setStyleSheet("")
                self.google_auth_btn.setObjectName("menuItem")
                self.google_auth_btn.setStyle(self.google_auth_btn.style())

        elif service == 'spotify':
            if is_authenticated:
                self.spotify_auth_btn.setText("🎵  Spotify (認証済)")
                self.spotify_auth_btn.setStyleSheet("""
                    QPushButton {
                        color: #4caf50;
                        font-size: 14px;
                        padding: 12px 20px;
                        border: none;
                        text-align: left;
                        background: transparent;
                    }
                    QPushButton:hover {
                        background-color: rgba(76, 175, 80, 0.2);
                    }
                """)
            else:
                self.spotify_auth_btn.setText("🎵  Spotify 認証")
                self.spotify_auth_btn.setStyleSheet("")
                self.spotify_auth_btn.setObjectName("menuItem")
                self.spotify_auth_btn.setStyle(self.spotify_auth_btn.style())

    # ========== サブメニュー関連 ==========

    def _setup_submenu(self):
        """サブメニューパネルを初期化"""
        self._submenu = QFrame(self.parent())
        self._submenu.setObjectName("subMenu")
        self._submenu.setFixedWidth(self._submenu_width)
        self._submenu.setStyleSheet("""
            #subMenu {
                background-color: rgba(40, 40, 40, 0.98);
                border-left: 1px solid #555;
                border-right: 1px solid #444;
            }
            #subMenuTitle {
                color: #aaaaaa;
                font-size: 12px;
                padding: 10px 15px 5px 15px;
            }
            #subMenuItem {
                color: #ffffff;
                font-size: 13px;
                padding: 10px 15px;
                border: none;
                text-align: left;
                background: transparent;
            }
            #subMenuItem:hover {
                background-color: rgba(255, 255, 255, 0.1);
            }
            #subMenuItemConnecting {
                color: #888888;
                font-size: 13px;
                padding: 10px 15px;
                border: none;
                text-align: left;
                background: transparent;
            }
        """)

        layout = QVBoxLayout(self._submenu)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # タイトル
        self._submenu_title = QLabel("Bluetoothスピーカー")
        self._submenu_title.setObjectName("subMenuTitle")
        layout.addWidget(self._submenu_title)

        # デバイスリスト用コンテナ
        self._submenu_container = QWidget()
        self._submenu_layout = QVBoxLayout(self._submenu_container)
        self._submenu_layout.setContentsMargins(0, 0, 0, 0)
        self._submenu_layout.setSpacing(0)
        layout.addWidget(self._submenu_container)

        layout.addStretch()

        # 初期状態は非表示
        self._submenu.hide()

    def _show_submenu(self, devices: list):
        """サブメニューを表示"""
        # 既存のボタンをクリア
        for i in reversed(range(self._submenu_layout.count())):
            widget = self._submenu_layout.itemAt(i).widget()
            if widget:
                widget.deleteLater()

        if not devices:
            label = QLabel("デバイスがありません")
            label.setStyleSheet("color: #888; padding: 10px 15px; font-size: 12px;")
            self._submenu_layout.addWidget(label)
        else:
            for dev in devices:
                btn = QPushButton(f"  {dev['name']}")
                btn.setObjectName("subMenuItem")
                btn.setToolTip(dev['address'])
                btn.clicked.connect(lambda checked, d=dev: self._on_bt_speaker_clicked(d))
                self._submenu_layout.addWidget(btn)

        # 位置をメニューの右隣に設定
        self._submenu.setParent(self.parent())
        self._submenu.move(self._menu_width, 0)
        self._submenu.setFixedHeight(self.height())
        self._submenu.show()
        self._submenu.raise_()
        self._submenu_visible = True

    def _hide_submenu(self):
        """サブメニューを非表示"""
        if self._submenu:
            self._submenu.hide()
        self._submenu_visible = False

    def _on_bt_speaker_clicked(self, device: dict):
        """Bluetoothスピーカー選択時"""
        address = device['address']
        name = device['name']

        # ボタンを「接続中...」に変更
        for i in range(self._submenu_layout.count()):
            widget = self._submenu_layout.itemAt(i).widget()
            if isinstance(widget, QPushButton) and widget.toolTip() == address:
                widget.setText(f"  {name} 接続中...")
                widget.setObjectName("subMenuItemConnecting")
                widget.setEnabled(False)
                widget.setStyle(widget.style())
                break

        # 別スレッドで接続を試行
        def connect_async():
            from services.bt_manager import get_bt_manager
            bt_manager = get_bt_manager()
            success = bt_manager.connect_device(address)

            # メインスレッドでUI更新
            QTimer.singleShot(0, lambda: self._on_bt_speaker_connected(address, name, success))

        threading.Thread(target=connect_async, daemon=True).start()

    def _on_bt_speaker_connected(self, address: str, name: str, success: bool):
        """Bluetoothスピーカー接続結果"""
        from PyQt5.QtWidgets import QMessageBox

        if success:
            print(f"Bluetoothスピーカー接続成功: {name}")
            self._hide_submenu()
            # 少し待ってから音声出力を更新
            QTimer.singleShot(1000, self.refresh_audio_outputs)
        else:
            # 失敗メッセージ
            msg = QMessageBox(self.window())
            msg.setWindowTitle("接続エラー")
            msg.setText(f"{name} への接続に失敗しました")
            msg.setIcon(QMessageBox.Warning)
            msg.setStyleSheet("""
                QMessageBox { background-color: #2a2a2a; }
                QMessageBox QLabel { color: #ffffff; font-size: 14px; }
                QPushButton { background-color: #444; color: #fff; border: none; border-radius: 4px; padding: 8px 20px; }
            """)
            msg.exec_()

            # サブメニューを再描画
            from services.bt_manager import get_bt_manager
            bt_manager = get_bt_manager()
            devices = bt_manager.get_paired_audio_devices()
            self._show_submenu(devices)

    # ========== Bluetooth関連メソッド ==========

    def _on_bt_pairing_mode_clicked(self):
        """ペアリングモードボタンクリック（PC側から見つけられるようにする）"""
        from services.bt_manager import get_bt_manager
        from PyQt5.QtWidgets import QMessageBox

        bt_manager = get_bt_manager()

        # 検出可能＋ペアリング可能モードをON（3分間）
        bt_manager.set_discoverable(True, 180)
        bt_manager.set_pairable(True, 180)

        # ユーザーに通知
        msg = QMessageBox(self.window())
        msg.setWindowTitle("ペアリングモード")
        msg.setText("3分間、PC側から検出可能になりました。\n\nPC側のBluetooth設定から\nこのデバイスを探してペアリングしてください。")
        msg.setIcon(QMessageBox.Information)
        msg.setStandardButtons(QMessageBox.Ok)
        msg.setStyleSheet("""
            QMessageBox {
                background-color: #2a2a2a;
            }
            QMessageBox QLabel {
                color: #ffffff;
                font-size: 14px;
            }
            QPushButton {
                background-color: #444;
                color: #fff;
                border: none;
                border-radius: 4px;
                padding: 8px 20px;
                font-size: 14px;
                min-width: 80px;
            }
            QPushButton:hover {
                background-color: #555;
            }
        """)
        msg.exec_()

    # ========== 音声出力関連メソッド ==========

    def refresh_audio_outputs(self):
        """音声出力デバイスリストを更新"""
        import subprocess

        # 既存のボタンをクリア
        for btn in self._audio_buttons:
            self._audio_layout.removeWidget(btn)
            btn.deleteLater()
        self._audio_buttons.clear()

        # サブメニューを閉じる
        self._hide_submenu()

        bt_speaker_connected = False

        try:
            # 利用可能なシンクを取得
            result = subprocess.run(
                ['pactl', 'list', 'sinks', 'short'],
                capture_output=True, text=True, timeout=5
            )
            sinks = []
            for line in result.stdout.strip().split('\n'):
                if line:
                    parts = line.split('\t')
                    if len(parts) >= 2:
                        sink_name = parts[1]
                        sinks.append(sink_name)

            # デフォルトシンクを取得
            result = subprocess.run(
                ['pactl', 'get-default-sink'],
                capture_output=True, text=True, timeout=5
            )
            default_sink = result.stdout.strip()

            for sink in sinks:
                # ヘッドセット(HFP)は除外（HIDキーボード接続先のPC）
                if 'headset' in sink.lower() or 'handsfree' in sink.lower():
                    continue

                # 表示名を決定
                if 'hdmi' in sink.lower():
                    display_name = 'HDMI'
                elif 'bluez' in sink.lower() and 'a2dp' in sink.lower():
                    display_name = 'Bluetoothスピーカー'
                    bt_speaker_connected = True
                elif 'bluez' in sink.lower():
                    display_name = 'Bluetoothスピーカー'
                    bt_speaker_connected = True
                elif 'mailbox' in sink.lower():
                    display_name = 'ヘッドホン端子'
                else:
                    display_name = sink[:25]

                is_active = (sink == default_sink)

                btn = QPushButton(display_name)
                btn.setToolTip(sink)
                btn.clicked.connect(lambda checked, s=sink: self._on_audio_output_clicked(s))

                # スタイルを適用（高さを確保）
                btn.setMinimumHeight(40)
                btn.setStyleSheet("""
                    QPushButton {
                        color: #ffffff;
                        font-size: 14px;
                        padding: 8px 20px;
                        border: none;
                        text-align: left;
                        background-color: %s;
                    }
                    QPushButton:hover {
                        background-color: %s;
                    }
                """ % (
                    "rgba(233, 69, 96, 0.8)" if is_active else "transparent",
                    "rgba(233, 69, 96, 1.0)" if is_active else "rgba(255, 255, 255, 0.1)"
                ))

                self._audio_layout.addWidget(btn)
                self._audio_buttons.append(btn)

            # Bluetoothスピーカー未接続の場合、ペアリング済みデバイスを表示するボタンを追加
            if not bt_speaker_connected:
                self._add_bt_speaker_expand_button()

        except Exception as e:
            print(f"Audio output refresh error: {e}")

    def _add_bt_speaker_expand_button(self):
        """Bluetoothスピーカー未接続時の展開ボタンを追加"""
        from services.bt_manager import get_bt_manager
        bt_manager = get_bt_manager()
        audio_devices = bt_manager.get_paired_audio_devices()

        if not audio_devices:
            return  # ペアリング済みオーディオデバイスがない

        btn = QPushButton("Bluetoothスピーカー  >")
        btn.setMinimumHeight(40)
        btn.setStyleSheet("""
            QPushButton {
                color: #aaaaaa;
                font-size: 14px;
                padding: 8px 20px;
                border: none;
                text-align: left;
                background: transparent;
            }
            QPushButton:hover {
                background-color: rgba(255, 255, 255, 0.1);
                color: #ffffff;
            }
        """)
        btn.clicked.connect(self._on_bt_speaker_expand_clicked)

        self._audio_layout.addWidget(btn)
        self._audio_buttons.append(btn)

    def _on_bt_speaker_expand_clicked(self):
        """Bluetoothスピーカー展開ボタンクリック"""
        if self._submenu_visible:
            self._hide_submenu()
        else:
            from services.bt_manager import get_bt_manager
            bt_manager = get_bt_manager()
            devices = bt_manager.get_paired_audio_devices()
            self._show_submenu(devices)

    def _on_audio_output_clicked(self, sink_name: str):
        """音声出力選択時"""
        import subprocess
        try:
            subprocess.run(['pactl', 'set-default-sink', sink_name], timeout=5)
            self.refresh_audio_outputs()
            self.audioOutputChanged.emit(sink_name)
            print(f"Audio output changed to: {sink_name}")
        except Exception as e:
            print(f"Audio output change error: {e}")

    def _on_bt_device_selected(self, address: str, name: str):
        """デバイス選択時"""
        # 設定を保存
        from services.bt_manager import get_bt_manager
        bt_manager = get_bt_manager()
        bt_manager.save_device(address, name)
        bt_manager.set_last_device(address)

        # UIを更新
        self.refresh_bt_devices()

        # シグナル発火
        self.bluetoothDeviceChanged.emit(address)

    def refresh_bt_devices(self):
        """Bluetoothデバイスリストを更新"""
        # 既存のボタンをクリア
        for btn in self._bt_device_buttons:
            btn.deleteLater()
        self._bt_device_buttons.clear()

        # 保存済みデバイスを読み込み
        from services.bt_manager import get_bt_manager
        bt_manager = get_bt_manager()
        devices = bt_manager.get_saved_devices()
        last_device = bt_manager.get_last_device()

        # OSからデバイス名を取得して更新
        for dev in devices:
            os_name = bt_manager.get_device_name(dev["address"])
            if os_name and os_name != dev["name"]:
                dev["name"] = os_name
                bt_manager.save_device(dev["address"], os_name)

        # 接続状態を確認
        from services.bt_keyboard import get_keyboard_service
        keyboard = get_keyboard_service()
        connected_addr = keyboard.get_target_address() if keyboard.is_connected() else None

        for dev in devices:
            addr = dev["address"]
            name = dev["name"]
            is_current = (addr == last_device)
            is_connected = (addr == connected_addr)

            # ボタンを作成
            if is_connected:
                icon = "🔵"
                btn_style = "menuItemActive"
            elif is_current:
                icon = "⚪"
                btn_style = "menuItemActive"
            else:
                icon = "⚪"
                btn_style = "menuItem"

            btn = QPushButton(f"{icon}  {name}")
            btn.setObjectName(btn_style)
            btn.setToolTip(addr)
            btn.clicked.connect(lambda checked, a=addr: self._on_bt_device_clicked(a))

            # スタイル設定
            if btn_style == "menuItem":
                btn.setStyleSheet("""
                    QPushButton {
                        color: #ffffff;
                        font-size: 13px;
                        padding: 10px 20px;
                        border: none;
                        text-align: left;
                        background: transparent;
                    }
                    QPushButton:hover {
                        background-color: rgba(255, 255, 255, 0.1);
                    }
                """)
            else:
                btn.setStyleSheet("""
                    QPushButton {
                        color: #ffffff;
                        font-size: 13px;
                        padding: 10px 20px;
                        border: none;
                        text-align: left;
                        background-color: rgba(233, 69, 96, 0.5);
                    }
                    QPushButton:hover {
                        background-color: rgba(233, 69, 96, 0.7);
                    }
                """)

            self._bt_layout.addWidget(btn)
            self._bt_device_buttons.append(btn)

        self._current_bt_address = last_device

    def _on_bt_device_clicked(self, address: str):
        """デバイスボタンクリック"""
        if address == self._current_bt_address:
            return

        # 接続先を変更
        from services.bt_manager import get_bt_manager
        bt_manager = get_bt_manager()
        bt_manager.set_last_device(address)

        # UIを更新
        self.refresh_bt_devices()

        # シグナル発火
        self.bluetoothDeviceChanged.emit(address)

    def set_current_bt_device(self, address: str):
        """現在の接続先を設定（外部から呼び出し用）"""
        self._current_bt_address = address
        self.refresh_bt_devices()
