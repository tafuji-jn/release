#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ThinMonitorPalet - ラズベリーパイ用時計＆ツールパネル
解像度: 1920x720
"""

import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QMessageBox
from PyQt5.QtCore import Qt, QTimer

# ウィジェットをインポート
from widgets.clock import ClockWidget
from widgets.menu import SlideMenu
from widgets.calendar import CalendarWidget
from widgets.schedule import ScheduleWidget
from widgets.spotify import SpotifyWidget
from widgets.deck import SwipeableButtonArea
from widgets.qr_auth_dialog import QRAuthDialog

# Bluetooth SPPサーバー（設定同期用）
from services.bluetooth_spp import get_spp_server
# Bluetooth HIDキーボード（キー送信用）
from services.bt_keyboard import get_keyboard_service
# Bluetooth管理（設定保存用）
from services.bt_manager import get_bt_manager

# デフォルトのBluetoothアドレス（設定ファイルがない場合のフォールバック）
DEFAULT_BT_ADDRESS = "B8:31:B5:79:93:96"


class MainWindow(QMainWindow):
    """メインウィンドウ"""

    def __init__(self):
        super().__init__()
        self.setup_ui()
        self.apply_styles()

    def setup_ui(self):
        """UIの初期化"""
        self.setWindowTitle("ThinMonitorPalet")
        self.setGeometry(0, 0, 1920, 720)
        self.setFixedSize(1920, 720)

        # 中央ウィジェット
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        # メインレイアウト
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # 上部エリア（時計、カレンダー、スケジュール）
        top_widget = QWidget()
        top_layout = QHBoxLayout(top_widget)
        top_layout.setContentsMargins(0, 0, 0, 0)
        top_layout.setSpacing(0)

        # 左側: 時計エリア
        self.clock_widget = ClockWidget()
        self.clock_widget.setFixedWidth(750)
        top_layout.addWidget(self.clock_widget)

        # スライドメニューを作成して時計ウィジェットに設定
        self.slide_menu = SlideMenu()
        self.clock_widget.set_slide_menu(self.slide_menu)

        # Bluetooth接続先変更シグナルを接続
        self.slide_menu.bluetoothDeviceChanged.connect(self._on_bt_device_changed)

        # 認証シグナルを接続
        self.slide_menu.googleAuthRequested.connect(self._on_google_auth_requested)
        self.slide_menu.spotifyAuthRequested.connect(self._on_spotify_auth_requested)

        # 更新チェックシグナルを接続
        self.slide_menu.updateCheckRequested.connect(self._on_update_check_requested)

        # 中央: カレンダーウィジェット
        self.calendar_widget = CalendarWidget()
        self.calendar_widget.setFixedWidth(650)
        top_layout.addWidget(self.calendar_widget)

        # 右側: スケジュール領域（上60%）と予備領域（下40%）
        right_panel = QWidget()
        right_panel.setObjectName("rightPanel")
        right_panel.setFixedWidth(520)
        right_layout = QVBoxLayout(right_panel)
        right_layout.setContentsMargins(10, 10, 10, 10)
        right_layout.setSpacing(10)

        # スケジュールウィジェット（上62%）
        self.schedule_widget = ScheduleWidget()
        right_layout.addWidget(self.schedule_widget, 31)

        # Spotifyウィジェット（下38%）
        self.spotify_widget = SpotifyWidget()
        right_layout.addWidget(self.spotify_widget, 19)

        top_layout.addWidget(right_panel)

        # カレンダーとスケジュールの連携
        self.calendar_widget.dateClicked.connect(self._on_calendar_date_clicked)
        self.schedule_widget.eventsLoaded.connect(self._on_events_loaded)
        self.clock_widget.themeChanged.connect(self.calendar_widget.set_theme)
        self.clock_widget.set_menu_theme(self.calendar_widget._current_theme)
        # 月変更時に未取得範囲の予定を追加取得
        self.calendar_widget.monthChanged.connect(self.schedule_widget.fetch_events_for_month)

        main_layout.addWidget(top_widget)

        # 下部: スワイプ対応ボタンエリア（ahkエリア / streamdeckエリア）
        self.button_area = SwipeableButtonArea()
        main_layout.addWidget(self.button_area)


        # Bluetooth SPPサーバーを起動（設定同期用）
        self._start_spp_server()

        # Bluetooth HIDキーボードを起動（キー送信用）
        self._start_hid_keyboard()

        # 起動時に認証ステータスを更新
        QTimer.singleShot(1000, self._update_auth_status_on_startup)

    def _start_hid_keyboard(self):
        """Bluetooth HIDキーボードを起動"""
        import subprocess
        from pathlib import Path
        try:
            # HIDプロファイルを別プロセスで起動（D-Bus Profile API使用）
            hid_profile_path = Path(__file__).parent / "services" / "hid_profile.py"
            self._hid_process = subprocess.Popen(
                ["python3", "-u", str(hid_profile_path)],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
            print(f"BT HID Profile: 起動 (PID={self._hid_process.pid})")

            # 保存済みのデバイスアドレスを取得
            bt_manager = get_bt_manager()
            target_address = bt_manager.get_last_device()

            # キー送信用サービスも起動（クライアントモード）
            self._keyboard_service = get_keyboard_service()
            if target_address:
                self._keyboard_service.start(target_address=target_address)
                print(f"BT Keyboard: クライアントモードで起動 (target={target_address})")
            else:
                self._keyboard_service.start(target_address=None)
                print("BT Keyboard: サーバーモードで起動")

            # メニューのBluetooth一覧を更新
            self.slide_menu.refresh_bt_devices()
        except Exception as e:
            print(f"BT Keyboard: 起動エラー - {e}")

    def _start_spp_server(self):
        """Bluetooth SPPサーバーを起動"""
        try:
            self._spp_server = get_spp_server(on_config_updated=self._on_deck_config_updated)
            self._spp_server.start()
        except Exception as e:
            print(f"Bluetooth SPP: 起動エラー - {e}")

    def _on_deck_config_updated(self):
        """deck_config.jsonが更新された時の処理（別スレッドから呼ばれる）"""
        print("Deck設定が更新されました。UIを再読み込みします。")
        # メインスレッドでUI更新を実行
        from PyQt5.QtCore import QTimer
        QTimer.singleShot(0, self._reload_deck_ui)

    def _reload_deck_ui(self):
        """Deck UIを再読み込み（メインスレッドで実行）"""
        self.button_area._buttons_data = self.button_area._load_config()
        self.button_area._rebuild_pages()

    def _on_bt_device_changed(self, address: str):
        """Bluetooth接続先が変更された時の処理"""
        print(f"Bluetooth接続先を変更: {address}")
        if hasattr(self, '_keyboard_service'):
            self._keyboard_service.change_target(address)

    def _on_google_auth_requested(self):
        """Google認証リクエスト時の処理"""
        from google_calendar import get_calendar_service

        try:
            service = get_calendar_service()

            # 既存の認証をクリア（再認証の場合）
            service.clear_credentials()

            # 認証URLを取得
            auth_url = service.get_auth_url()

            # QRコードダイアログを表示
            dialog = QRAuthDialog(self, "Google カレンダー", QRAuthDialog.MODE_CODE)
            dialog.set_auth_url(auth_url)

            # 認証完了時の処理
            def on_auth_completed(code):
                try:
                    service.complete_auth_with_code(code)
                    dialog.show_success("Google カレンダー認証成功！")
                    self.slide_menu.update_auth_status('google', True)
                    # スケジュールウィジェットの認証状態を更新
                    if hasattr(self, 'schedule_widget'):
                        self.schedule_widget._is_authenticated = True
                        self.schedule_widget._calendar_service = service
                        # 予定を再取得
                        QTimer.singleShot(100, self.schedule_widget.fetch_events)
                except Exception as e:
                    dialog.show_error(f"認証エラー: {str(e)}")

            dialog.authCompleted.connect(on_auth_completed)
            dialog.exec_()

        except FileNotFoundError as e:
            QMessageBox.warning(self, "認証エラー",
                f"認証情報ファイルが見つかりません。\n\n{str(e)}")
        except Exception as e:
            QMessageBox.warning(self, "認証エラー", f"エラー: {str(e)}")

    def _on_spotify_auth_requested(self):
        """Spotify認証リクエスト時の処理（コールバック自動受信）"""
        from spotify_service import get_spotify_service
        from widgets.qr_auth_dialog import QRAuthDialog
        import socket

        try:
            service = get_spotify_service()

            # 既存の認証をクリア（再認証の場合）
            service.clear_credentials()

            # ローカルIPアドレスを取得
            def get_local_ip():
                try:
                    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                    s.connect(("8.8.8.8", 80))
                    ip = s.getsockname()[0]
                    s.close()
                    return ip
                except:
                    return "localhost"

            local_ip = get_local_ip()
            callback_port = 8888
            redirect_uri = f"http://{local_ip}:{callback_port}/callback"

            # 認証URLを取得（カスタムリダイレクトURI）
            auth_url = service.get_auth_url(redirect_uri=redirect_uri)

            # QRコードダイアログを表示（コールバック自動受信モード）
            dialog = QRAuthDialog(self, "Spotify", QRAuthDialog.MODE_CALLBACK, callback_port)
            dialog.set_auth_url(auth_url)

            # 認証完了時の処理
            def on_auth_completed(code):
                try:
                    service.complete_auth_with_code(code)
                    dialog.show_success("Spotify認証成功！")
                    self._on_spotify_auth_success(service)
                except Exception as e:
                    dialog.show_error(f"認証エラー: {str(e)}")

            dialog.authCompleted.connect(on_auth_completed)
            dialog.exec_()

        except FileNotFoundError as e:
            QMessageBox.warning(self, "認証エラー",
                f"認証情報ファイルが見つかりません。\n\n"
                f"{str(e)}\n\n"
                f"※ Spotify Developer Dashboard で\n"
                f"リダイレクトURIに http://<PiのIP>:8888/callback を追加してください")
        except Exception as e:
            QMessageBox.warning(self, "認証エラー", f"エラー: {str(e)}")

    def _on_spotify_auth_success(self, service):
        """Spotify認証成功時の処理"""
        self.slide_menu.update_auth_status('spotify', True)
        # Spotifyウィジェットの認証状態を更新
        if hasattr(self, 'spotify_widget'):
            self.spotify_widget._is_authenticated = True
            self.spotify_widget._spotify_service = service
            # 再生状態を取得
            QTimer.singleShot(100, self.spotify_widget._fetch_playback_state)

    def _on_update_check_requested(self):
        """アプリ更新チェックリクエスト時の処理"""
        print("Main: 更新チェック開始", flush=True)
        import threading
        import urllib.request
        import json
        from pathlib import Path

        app_dir = Path(__file__).parent
        version_url = "https://raw.githubusercontent.com/tafuji-jn/release/main/thinmonitortool/version.json"
        local_version_file = app_dir / ".version"

        def check_and_update():
            print("Main: check_and_update スレッド開始", flush=True)
            try:
                # リモートのバージョン情報を取得
                with urllib.request.urlopen(version_url, timeout=10) as response:
                    remote_info = json.loads(response.read().decode('utf-8'))

                remote_version = remote_info.get('version', '')
                remote_commit = remote_info.get('commit', '')
                remote_date = remote_info.get('date', '')
                download_url = remote_info.get('download_url', '')

                # ローカルのバージョン情報を取得
                local_version = ''
                if local_version_file.exists():
                    with open(local_version_file, 'r') as f:
                        local_info = json.load(f)
                        local_version = local_info.get('version', '')

                if local_version == remote_version:
                    # 更新なし
                    QTimer.singleShot(0, lambda: QMessageBox.information(
                        self, "更新チェック", f"最新バージョンです。\n\n現在: {local_version}"))
                else:
                    # 更新あり - 更新するか確認
                    update_info = {
                        'version': remote_version,
                        'commit': remote_commit,
                        'date': remote_date,
                        'download_url': download_url,
                        'local_version': local_version
                    }
                    QTimer.singleShot(0, lambda: self._confirm_update(app_dir, update_info))

            except urllib.error.URLError as e:
                QTimer.singleShot(0, lambda: QMessageBox.warning(
                    self, "更新チェック", f"サーバーに接続できませんでした。\n\nインターネット接続を確認してください。"))
            except Exception as e:
                QTimer.singleShot(0, lambda: QMessageBox.warning(
                    self, "更新チェック", f"エラー: {str(e)}"))

        # 別スレッドで実行
        threading.Thread(target=check_and_update, daemon=True).start()

    def _confirm_update(self, app_dir, update_info):
        """更新確認ダイアログを表示"""
        local_ver = update_info['local_version'] or '未設定'
        remote_ver = update_info['version']
        remote_date = update_info['date']

        msg = QMessageBox(self)
        msg.setWindowTitle("更新があります")
        msg.setText(f"新しいバージョンが利用可能です。\n\n"
                    f"現在: {local_ver}\n"
                    f"最新: {remote_ver} ({remote_date})\n\n"
                    f"更新しますか？")
        msg.setIcon(QMessageBox.Question)
        msg.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        msg.setDefaultButton(QMessageBox.Yes)
        msg.button(QMessageBox.Yes).setText("更新する")
        msg.button(QMessageBox.No).setText("後で")

        if msg.exec_() == QMessageBox.Yes:
            self._do_update(app_dir, update_info)

    def _do_update(self, app_dir, update_info):
        """更新を実行"""
        import subprocess
        import threading
        import urllib.request
        import zipfile
        import json
        import shutil
        from pathlib import Path

        download_url = update_info['download_url']

        def update():
            try:
                # ZIPをダウンロード
                zip_path = app_dir / "update.zip"
                urllib.request.urlretrieve(download_url, zip_path)

                # 一時ディレクトリに展開
                temp_dir = app_dir / "_update_temp"
                if temp_dir.exists():
                    shutil.rmtree(temp_dir)

                with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                    zip_ref.extractall(temp_dir)

                # 展開されたファイルをコピー（認証ファイルは除外）
                exclude_files = {
                    'credentials.json',
                    'spotify_credentials.json',
                    'token.pickle',
                    '.spotify_token_cache',
                    '.version',
                    'deck_config.json'
                }

                for item in temp_dir.iterdir():
                    if item.name in exclude_files:
                        continue

                    dest = app_dir / item.name
                    if item.is_dir():
                        if dest.exists():
                            shutil.rmtree(dest)
                        shutil.copytree(item, dest)
                    else:
                        shutil.copy2(item, dest)

                # バージョンファイルを更新
                version_file = app_dir / ".version"
                with open(version_file, 'w') as f:
                    json.dump({
                        'version': update_info['version'],
                        'commit': update_info['commit'],
                        'date': update_info['date']
                    }, f, indent=2)

                # クリーンアップ
                zip_path.unlink()
                shutil.rmtree(temp_dir)

                # pip install を実行（依存関係の更新）
                subprocess.run(
                    ['pip', 'install', '-r', 'requirements.txt'],
                    cwd=app_dir,
                    capture_output=True,
                    check=True
                )

                # 更新成功 - 再起動を確認
                QTimer.singleShot(0, self._confirm_restart)

            except Exception as e:
                QTimer.singleShot(0, lambda: QMessageBox.warning(
                    self, "更新エラー", f"更新に失敗しました。\n\n{str(e)}"))

        threading.Thread(target=update, daemon=True).start()

    def _confirm_restart(self):
        """再起動確認ダイアログを表示"""
        msg = QMessageBox(self)
        msg.setWindowTitle("更新完了")
        msg.setText("更新が完了しました。\n変更を反映するにはアプリを再起動してください。")
        msg.setIcon(QMessageBox.Information)
        msg.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        msg.setDefaultButton(QMessageBox.Yes)
        msg.button(QMessageBox.Yes).setText("今すぐ再起動")
        msg.button(QMessageBox.No).setText("後で")

        if msg.exec_() == QMessageBox.Yes:
            self._restart_app()

    def _restart_app(self):
        """アプリを再起動"""
        import subprocess
        from pathlib import Path

        app_dir = Path(__file__).parent
        start_script = app_dir / "start.sh"

        # 現在のアプリを終了して再起動
        subprocess.Popen(
            ['bash', '-c', f'sleep 1 && {start_script}'],
            cwd=app_dir,
            start_new_session=True
        )
        self.close()

    def _update_auth_status_on_startup(self):
        """起動時に認証ステータスを更新"""
        try:
            from google_calendar import get_calendar_service
            google_service = get_calendar_service()
            is_google_auth = not google_service.needs_authentication()
            self.slide_menu.update_auth_status('google', is_google_auth)
        except Exception:
            pass

        try:
            from spotify_service import get_spotify_service
            spotify_service = get_spotify_service()
            is_spotify_auth = not spotify_service.needs_authentication()
            self.slide_menu.update_auth_status('spotify', is_spotify_auth)
        except Exception:
            pass

    def closeEvent(self, event):
        """アプリ終了時の処理"""
        if hasattr(self, '_hid_process') and self._hid_process:
            self._hid_process.terminate()
            print("BT HID Profile: 停止")
        if hasattr(self, '_keyboard_service'):
            self._keyboard_service.stop()
        if hasattr(self, '_spp_server'):
            self._spp_server.stop()
        if hasattr(self, 'spotify_widget') and self.spotify_widget._spotify_service:
            try:
                self.spotify_widget._spotify_service.pause()
                print("Spotify: 再生停止")
            except Exception as e:
                print(f"Spotify pause error on close: {e}")
        event.accept()

    def apply_styles(self):
        """スタイルシートの適用"""
        self.setStyleSheet("""
            QMainWindow { background-color: #000000; }
            #clockWidget { background-color: #000000; }
            #colonLabel { color: #ffffff; font-size: 70px; font-weight: bold; font-family: 'Segoe UI', 'Arial', sans-serif; }
            #dateLabel { color: #ffffff; font-size: 26px; font-family: 'Segoe UI', 'Yu Gothic UI', sans-serif; }
            #weatherIcon { color: #ffffff; font-size: 26px; }
            #tempLabel { color: #ffffff; font-size: 26px; font-family: 'Segoe UI', sans-serif; }
            #calendarWidget { background-color: #000000; }
            #buttonArea { background-color: #1a1a1a; border-top: 1px solid #333333; }
            #calendarContainer { background-color: #f5f5f5; border-radius: 10px; }
            #monthNumLabel { color: #000000; font-size: 80px; font-weight: bold; font-family: 'Segoe UI', sans-serif; }
            #yearLabel { color: #000000; font-size: 22px; font-family: 'Segoe UI', sans-serif; padding-left: 2px; }
            #monthNameLabel { color: #666666; font-size: 20px; font-family: 'Segoe UI', sans-serif; margin-bottom: 15px; }
            #todayButton { background-color: #e94560; color: #ffffff; font-size: 12px; font-weight: bold; border: none; border-radius: 14px; padding: 4px 10px; }
            #todayButton:hover { background-color: #d63850; }
            #todayButton:pressed { background-color: #c42a40; }
            #calendarSeparator { background-color: #333333; max-height: 2px; }
            #weekdayHeader { color: #333333; font-size: 12px; font-weight: bold; font-family: 'Segoe UI', sans-serif; }
            #weekdayHeaderSunday { color: #e94560; font-size: 12px; font-weight: bold; font-family: 'Segoe UI', sans-serif; }
            #weekdayHeaderSaturday { color: #4dabf7; font-size: 12px; font-weight: bold; font-family: 'Segoe UI', sans-serif; }
            #dayCell { color: #000000; font-size: 22px; font-family: 'Segoe UI', sans-serif; background-color: #f5f5f5; border-top: 1px solid #cccccc; }
            #miniCalendar { background-color: transparent; }
            #miniMonthNum { color: #333333; font-size: 28px; font-weight: bold; font-family: 'Segoe UI', sans-serif; }
            #miniYearLabel { color: #666666; font-size: 11px; font-family: 'Segoe UI', sans-serif; }
            #miniWeekday { color: #666666; font-size: 8px; font-family: 'Segoe UI', sans-serif; }
            #miniWeekdaySun { color: #e94560; font-size: 8px; font-family: 'Segoe UI', sans-serif; }
            #miniWeekdaySat { color: #4dabf7; font-size: 8px; font-family: 'Segoe UI', sans-serif; }
            #miniDayCell { color: #333333; font-size: 9px; font-family: 'Segoe UI', sans-serif; }
            #rightPanel { background-color: #000000; }
            #scheduleWidget { background: transparent; }
            #scheduleOverlay { background: transparent; }
            #scheduleDayNum { color: #ffffff; font-size: 72px; font-weight: 300; font-family: 'Roboto', 'SF Pro Display', 'Segoe UI Light', sans-serif; background: transparent; }
            #scheduleWeekday { color: #ffffff; font-size: 16px; font-weight: normal; font-family: 'Hiragino Sans', 'Meiryo', 'Noto Sans JP', 'Yu Gothic UI', sans-serif; background: transparent; }
            #scheduleSeparator { background-color: rgba(255, 255, 255, 0.3); max-width: 1px; }
            #scheduleScrollArea { background-color: transparent; border: none; }
            #scheduleScrollArea > QWidget > QWidget { background-color: transparent; }
            QScrollArea QWidget { background-color: transparent; }
            #scheduleNoEvents { color: rgba(255, 255, 255, 0.7); font-size: 18px; font-weight: normal; font-family: 'Hiragino Sans', 'Meiryo', 'Noto Sans JP', 'Yu Gothic UI', sans-serif; padding: 10px; background: transparent; }
            #scheduleEventItem { background: transparent; }
            #scheduleEventTime { color: rgba(255, 255, 255, 0.5); font-size: 15px; font-weight: normal; font-family: 'Roboto', 'SF Pro Display', 'Segoe UI', sans-serif; background: transparent; }
            #scheduleEventTitle { color: rgba(255, 255, 255, 0.85); font-size: 20px; font-weight: 500; font-family: 'Hiragino Sans', 'Meiryo', 'Noto Sans JP', 'Yu Gothic UI', sans-serif; background: transparent; }
            #spotifyWidget { background-color: transparent; border-radius: 12px; }
            #spotifyPlayBtn { background: transparent; border: none; font-size: 28px; color: rgba(255, 255, 255, 0.9); }
            #spotifyPlayBtn:hover { color: rgba(255, 255, 255, 1.0); }
            #spotifyControlBtn { background: transparent; border: none; font-size: 22px; color: rgba(255, 255, 255, 0.9); }
            #spotifyControlBtn:hover { color: rgba(255, 255, 255, 1.0); }
            #spotifySeekSlider::groove:horizontal { background: rgba(255, 255, 255, 0.25); height: 3px; border-radius: 1px; }
            #spotifySeekSlider::handle:horizontal { background: rgba(255, 255, 255, 0.95); width: 10px; height: 10px; margin: -4px 0; border-radius: 5px; }
            #spotifySeekSlider::sub-page:horizontal { background: rgba(255, 255, 255, 0.8); border-radius: 1px; }
            #spotifyVolumeSlider::groove:horizontal { background: rgba(255, 255, 255, 0.25); height: 3px; border-radius: 1px; margin: 13px 0; }
            #spotifyVolumeSlider::handle:horizontal { background: rgba(255, 255, 255, 0.9); width: 10px; height: 10px; margin: -4px 0; border-radius: 5px; }
            #spotifyVolumeSlider::sub-page:horizontal { background: rgba(255, 255, 255, 0.7); border-radius: 1px; margin: 13px 0; }
        """)

    def _on_calendar_date_clicked(self, year, month, day):
        """カレンダーの日付がクリックされた時の処理"""
        self.schedule_widget.select_date(year, month, day)

    def _on_events_loaded(self, event_counts):
        """スケジュールの予定取得完了時の処理"""
        self.calendar_widget.set_event_counts(event_counts)

    def keyPressEvent(self, event):
        """キーイベント処理"""
        if event.key() == Qt.Key_Escape:
            self.close()
        elif event.key() == Qt.Key_F11:
            if self.isFullScreen():
                self.showNormal()
            else:
                self.showFullScreen()


def main():
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    window = MainWindow()
    window.showFullScreen()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
