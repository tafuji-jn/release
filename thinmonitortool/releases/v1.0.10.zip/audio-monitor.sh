#!/bin/bash
# Bluetoothオーディオ接続を監視して自動切り替え

HDMI_SINK="alsa_output.platform-fef00700.hdmi.hdmi-stereo.2"
CURRENT=""

while true; do
    BT_SINK=$(pactl list sinks short 2>/dev/null | grep -i bluez | awk '{print $2}' | head -1)

    if [ -n "$BT_SINK" ] && [ "$CURRENT" != "$BT_SINK" ]; then
        pactl set-default-sink "$BT_SINK"
        CURRENT="$BT_SINK"
    elif [ -z "$BT_SINK" ] && [ "$CURRENT" != "hdmi" ]; then
        pactl set-default-sink "$HDMI_SINK"
        CURRENT="hdmi"
    fi

    sleep 3
done
