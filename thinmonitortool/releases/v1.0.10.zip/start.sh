#!/bin/bash
cd "$(dirname "$0")"

# Bluetooth HIDキーボード用の設定
sudo hciconfig hci0 class 0x002540 2>/dev/null
bluetoothctl discoverable on 2>/dev/null
bluetoothctl pairable on 2>/dev/null

./audio-switch.sh
source venv/bin/activate
python main.py
