# ThinMonitorTool

Raspberry Pi用のモニターツール。Googleカレンダーとspotify連携機能付き。

## 起動方法

```bash
./start.sh
```

## 必要な設定ファイル

- `credentials.json` - Google Calendar API認証情報
- `spotify_credentials.json` - Spotify API認証情報
