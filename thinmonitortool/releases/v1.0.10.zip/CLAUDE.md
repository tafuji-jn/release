# ThinMonitorTool プロジェクト情報

## プロジェクト概要
Raspberry Pi上で動作するモニターツール。Spotify制御、Googleカレンダー表示などの機能を持つ。

## UI構成

### 下部エリア（ahkエリア / streamdeckエリア）
- **場所**: 画面下部のアイコンエリア
- **機能**: ボタン押下で接続先PCにキーを送信
- **連携**: 接続先PCではAutoHotKey (AHK) でマクロを実行
- **別名**: 「ahkエリア」「下部エリア」「streamdeckエリア」
- スワイプでページ切り替え可能

### 設定メニュー（SlideMenu）
- **場所**: 画面左端からスワイプで表示
- **機能**: アプリの各種設定を変更
- **重要**: 「設定で変更」と言った場合はこのメニューのこと
- 現在の設定項目:
  - カレンダーテーマ（ライト/ダーク）
  - Deckエリアのページ数

## 技術スタック
- Python (main.py)
- Spotify API連携 (spotify_service.py)
- Google Calendar API連携 (google_calendar.py)
- SVGアイコン使用 (icon/)

## ファイル構成
- `main.py` - メインアプリケーション
- `spotify_service.py` - Spotify連携サービス
- `google_calendar.py` - Googleカレンダー連携
- `icon/` - SVGアイコン格納ディレクトリ
- `start.sh` - アプリ起動スクリプト
- `deck_config.json` - ahkエリアのボタン設定ファイル

## 設定ファイル

### deck_config.json（ahkエリア設定）
ページ数とボタン構成を定義:
```json
{
  "pages": [
    [
      {"icon": "⚙️", "label": "設定", "color": "#95a5a6"},
      ...
    ],
    [...]
  ]
}
```
- ページを追加/削除するとページ数が変わる
- 各ボタンは icon, label, color を指定

## 開発ワークフロー

### アプリ再起動（コード修正後は必ず実行）
プログラム修正後は以下のコマンドでアプリを再起動すること:

**重要**: `pkill`と起動コマンドは必ず**別々のコマンド**として実行する。
1行で連結すると起動に失敗することがある。

```bash
# 1. まず停止（別コマンドとして実行）
pkill -f "python.*main.py"
```

```bash
# 2. 次に起動（別コマンドとして実行）
source venv/bin/activate && python main.py &
```

### 起動確認
```bash
pgrep -f "python.*main.py"
```
